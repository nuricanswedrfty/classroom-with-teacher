import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { useGameStore } from './game-store'

export interface Badge {
  id: string
  name: string
  description: string
  icon: string
  requirement: number
  type: 'tests' | 'score' | 'streak' | 'topic' | 'perfect'
  topicId?: string
  unlocked: boolean
  unlockedAt?: Date
}

export interface TopicProgress {
  topicId: string
  lessonsCompleted: string[]
  testsCompleted: number
  totalCorrect: number
  totalQuestions: number
  bestScore: number
  lastStudied?: Date
}

interface ProgressState {
  // User stats
  totalTestsCompleted: number
  totalCorrectAnswers: number
  totalQuestionsAnswered: number
  currentStreak: number
  longestStreak: number
  lastActiveDate?: string
  perfectScores: number
  
  // Topic progress
  topicProgress: Record<string, TopicProgress>
  
  // Badges
  badges: Badge[]
  
  // Actions
  completeLesson: (topicId: string, lessonId: string) => void
  recordTestResult: (topicId: string, correct: number, total: number) => void
  checkAndUnlockBadges: () => Badge[]
  getTopicProgress: (topicId: string) => TopicProgress
  getOverallProgress: () => { completed: number; total: number; percentage: number }
  resetProgress: () => void
}

const initialBadges: Badge[] = [
  // Test rozetleri - daha kolay
  { id: 'first-test', name: 'Ilk Adim', description: 'Ilk testini tamamla', icon: '🎯', requirement: 1, type: 'tests', unlocked: false },
  { id: 'test-master-3', name: 'Hizli Baslangic', description: '3 test tamamla', icon: '🚀', requirement: 3, type: 'tests', unlocked: false },
  { id: 'test-master-5', name: 'Test Meraklisi', description: '5 test tamamla', icon: '📝', requirement: 5, type: 'tests', unlocked: false },
  { id: 'test-master-10', name: 'Test Ustasi', description: '10 test tamamla', icon: '📚', requirement: 10, type: 'tests', unlocked: false },
  { id: 'test-master-25', name: 'Test Sampiyonu', description: '25 test tamamla', icon: '🏆', requirement: 25, type: 'tests', unlocked: false },
  { id: 'test-master-50', name: 'Test Efsanesi', description: '50 test tamamla', icon: '👑', requirement: 50, type: 'tests', unlocked: false },
  
  // Skor rozetleri - daha kolay
  { id: 'score-10', name: 'Ilk Onluk', description: '10 dogru cevap ver', icon: '✅', requirement: 10, type: 'score', unlocked: false },
  { id: 'score-25', name: 'Ceyrek Yuz', description: '25 dogru cevap ver', icon: '🎯', requirement: 25, type: 'score', unlocked: false },
  { id: 'score-50', name: 'Yarim Yuz', description: '50 dogru cevap ver', icon: '💪', requirement: 50, type: 'score', unlocked: false },
  { id: 'score-100', name: 'Yuzyil', description: '100 dogru cevap ver', icon: '💯', requirement: 100, type: 'score', unlocked: false },
  { id: 'score-250', name: 'Bilgi Kuyusu', description: '250 dogru cevap ver', icon: '🧠', requirement: 250, type: 'score', unlocked: false },
  { id: 'score-500', name: 'Matematik Dehasi', description: '500 dogru cevap ver', icon: '🌟', requirement: 500, type: 'score', unlocked: false },
  
  // Streak rozetleri
  { id: 'streak-2', name: 'Iki Gun Ust Uste', description: '2 gun ust uste calis', icon: '✨', requirement: 2, type: 'streak', unlocked: false },
  { id: 'streak-3', name: 'Uc Gun Ust Uste', description: '3 gun ust uste calis', icon: '🔥', requirement: 3, type: 'streak', unlocked: false },
  { id: 'streak-5', name: 'Bes Gunluk Seri', description: '5 gun ust uste calis', icon: '⚡', requirement: 5, type: 'streak', unlocked: false },
  { id: 'streak-7', name: 'Haftalik Savasci', description: '7 gun ust uste calis', icon: '💫', requirement: 7, type: 'streak', unlocked: false },
  { id: 'streak-14', name: 'Iki Haftalik Kahraman', description: '14 gun ust uste calis', icon: '🦸', requirement: 14, type: 'streak', unlocked: false },
  { id: 'streak-30', name: 'Aylik Efsane', description: '30 gun ust uste calis', icon: '👑', requirement: 30, type: 'streak', unlocked: false },
  
  // Perfect score rozetleri - daha kolay
  { id: 'perfect-1', name: 'Mukemmel!', description: 'Bir testte tam puan al', icon: '✨', requirement: 1, type: 'perfect', unlocked: false },
  { id: 'perfect-2', name: 'Cift Mukemmel', description: '2 testte tam puan al', icon: '💎', requirement: 2, type: 'perfect', unlocked: false },
  { id: 'perfect-3', name: 'Uc Mukemmel', description: '3 testte tam puan al', icon: '🎖️', requirement: 3, type: 'perfect', unlocked: false },
  { id: 'perfect-5', name: 'Kusursuz', description: '5 testte tam puan al', icon: '🏅', requirement: 5, type: 'perfect', unlocked: false },
  { id: 'perfect-10', name: 'Hatasiz Efsane', description: '10 testte tam puan al', icon: '🌟', requirement: 10, type: 'perfect', unlocked: false },
  
  // Konu rozetleri - daha kolay (5 yerine 3)
  { id: 'topic-tam-sayilar', name: 'Tam Sayilar Meraklisi', description: 'Tam Sayilar konusunda 3 test tamamla', icon: '➕', requirement: 3, type: 'topic', topicId: 'tam-sayilar', unlocked: false },
  { id: 'topic-rasyonel-sayilar', name: 'Kesir Avcisi', description: 'Rasyonel Sayilar konusunda 3 test tamamla', icon: '➗', requirement: 3, type: 'topic', topicId: 'rasyonel-sayilar', unlocked: false },
  { id: 'topic-cebirsel-ifadeler', name: 'Cebir Sevdalisi', description: 'Cebirsel Ifadeler konusunda 3 test tamamla', icon: '🔤', requirement: 3, type: 'topic', topicId: 'cebirsel-ifadeler', unlocked: false },
  { id: 'topic-oran-oranti', name: 'Oran Ustasi', description: 'Oran-Oranti konusunda 3 test tamamla', icon: '⚖️', requirement: 3, type: 'topic', topicId: 'oran-oranti', unlocked: false },
  { id: 'topic-geometri', name: 'Geometri Aski', description: 'Geometri konusunda 3 test tamamla', icon: '📐', requirement: 3, type: 'topic', topicId: 'geometri', unlocked: false },
  { id: 'topic-veri-analizi', name: 'Veri Dedektifi', description: 'Veri Analizi konusunda 3 test tamamla', icon: '📊', requirement: 3, type: 'topic', topicId: 'veri-analizi', unlocked: false },
]

const defaultTopicProgress: TopicProgress = {
  topicId: '',
  lessonsCompleted: [],
  testsCompleted: 0,
  totalCorrect: 0,
  totalQuestions: 0,
  bestScore: 0,
}

export const useProgressStore = create<ProgressState>()(
  persist(
    (set, get) => ({
      totalTestsCompleted: 0,
      totalCorrectAnswers: 0,
      totalQuestionsAnswered: 0,
      currentStreak: 0,
      longestStreak: 0,
      lastActiveDate: undefined,
      perfectScores: 0,
      topicProgress: {},
      badges: initialBadges,

      completeLesson: (topicId: string, lessonId: string) => {
        set((state) => {
          const current = state.topicProgress[topicId] || { ...defaultTopicProgress, topicId }
          if (current.lessonsCompleted.includes(lessonId)) return state
          
          return {
            topicProgress: {
              ...state.topicProgress,
              [topicId]: {
                ...current,
                lessonsCompleted: [...current.lessonsCompleted, lessonId],
                lastStudied: new Date(),
              },
            },
          }
        })
        get().checkAndUnlockBadges()
      },

      recordTestResult: (topicId: string, correct: number, total: number) => {
        const today = new Date().toDateString()
        const score = Math.round((correct / total) * 100)
        const isPerfect = correct === total
        
        // Puan hesaplama - her dogru cevap icin 5 puan + bonus
        const baseCoins = correct * 5
        const perfectBonus = isPerfect ? 20 : 0
        const totalCoins = baseCoins + perfectBonus
        
        // Game store'a puan ekle
        try {
          useGameStore.getState().addCoins(totalCoins)
        } catch (e) {
          console.log('Game store not available')
        }
        
        set((state) => {
          const current = state.topicProgress[topicId] || { ...defaultTopicProgress, topicId }
          
          // Streak hesaplama
          let newStreak = state.currentStreak
          if (state.lastActiveDate !== today) {
            const yesterday = new Date()
            yesterday.setDate(yesterday.getDate() - 1)
            if (state.lastActiveDate === yesterday.toDateString()) {
              newStreak = state.currentStreak + 1
            } else {
              newStreak = 1
            }
          }
          
          return {
            totalTestsCompleted: state.totalTestsCompleted + 1,
            totalCorrectAnswers: state.totalCorrectAnswers + correct,
            totalQuestionsAnswered: state.totalQuestionsAnswered + total,
            currentStreak: newStreak,
            longestStreak: Math.max(state.longestStreak, newStreak),
            lastActiveDate: today,
            perfectScores: isPerfect ? state.perfectScores + 1 : state.perfectScores,
            topicProgress: {
              ...state.topicProgress,
              [topicId]: {
                ...current,
                testsCompleted: current.testsCompleted + 1,
                totalCorrect: current.totalCorrect + correct,
                totalQuestions: current.totalQuestions + total,
                bestScore: Math.max(current.bestScore, score),
                lastStudied: new Date(),
              },
            },
          }
        })
        
        return get().checkAndUnlockBadges()
      },

      checkAndUnlockBadges: () => {
        const state = get()
        const newlyUnlocked: Badge[] = []
        
        set((s) => ({
          badges: s.badges.map((badge) => {
            if (badge.unlocked) return badge
            
            let shouldUnlock = false
            
            switch (badge.type) {
              case 'tests':
                shouldUnlock = state.totalTestsCompleted >= badge.requirement
                break
              case 'score':
                shouldUnlock = state.totalCorrectAnswers >= badge.requirement
                break
              case 'streak':
                shouldUnlock = state.currentStreak >= badge.requirement
                break
              case 'perfect':
                shouldUnlock = state.perfectScores >= badge.requirement
                break
              case 'topic':
                if (badge.topicId) {
                  const topicProg = state.topicProgress[badge.topicId]
                  shouldUnlock = topicProg ? topicProg.testsCompleted >= badge.requirement : false
                }
                break
            }
            
            if (shouldUnlock) {
              const unlockedBadge = { ...badge, unlocked: true, unlockedAt: new Date() }
              newlyUnlocked.push(unlockedBadge)
              return unlockedBadge
            }
            
            return badge
          }),
        }))
        
        return newlyUnlocked
      },

      getTopicProgress: (topicId: string) => {
        return get().topicProgress[topicId] || { ...defaultTopicProgress, topicId }
      },

      getOverallProgress: () => {
        const state = get()
        const topics = Object.values(state.topicProgress)
        const totalLessons = 6 * 5 // 6 konu * yaklaşık 5 ders
        const completedLessons = topics.reduce((acc, t) => acc + t.lessonsCompleted.length, 0)
        
        return {
          completed: completedLessons,
          total: totalLessons,
          percentage: Math.round((completedLessons / totalLessons) * 100),
        }
      },

      resetProgress: () => {
        set({
          totalTestsCompleted: 0,
          totalCorrectAnswers: 0,
          totalQuestionsAnswered: 0,
          currentStreak: 0,
          longestStreak: 0,
          lastActiveDate: undefined,
          perfectScores: 0,
          topicProgress: {},
          badges: initialBadges,
        })
      },
    }),
    {
      name: 'math-progress-storage',
    }
  )
)
