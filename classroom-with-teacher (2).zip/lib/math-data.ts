// 7. Sınıf Matematik Tüm Konular ve Dersler

export interface Lesson {
  id: string
  title: string
  content: string
  examples?: string[]
}

export interface Topic {
  id: string
  name: string
  icon: string
  color: 'blue' | 'green' | 'purple' | 'orange' | 'pink' | 'cyan'
  description: string
  lessons: Lesson[]
}

export const topics: Topic[] = [
  {
    id: 'tam-sayilar',
    name: 'Tam Sayılar',
    icon: '🔢',
    color: 'blue',
    description: 'Pozitif ve negatif tam sayılar ile işlemler',
    lessons: [
      {
        id: 'tam-sayilar-giris',
        title: 'Tam Sayılara Giriş',
        content: `Tam sayılar, negatif tam sayılar, sıfır ve pozitif tam sayılardan oluşan sayı kümesidir.

Tam sayılar kümesi Z ile gösterilir:
Z = {..., -3, -2, -1, 0, 1, 2, 3, ...}

Pozitif tam sayılar: 1, 2, 3, 4, ... (Z⁺ ile gösterilir)
Negatif tam sayılar: -1, -2, -3, -4, ... (Z⁻ ile gösterilir)

Önemli: Sıfır ne pozitif ne de negatiftir.

Sayı Doğrusu
Tam sayıları sayı doğrusunda gösterebiliriz. Sıfırın sağındaki sayılar pozitif, solundaki sayılar negatiftir.`,
        examples: [
          '-5, -3, 0, 2, 7 tam sayılardır',
          '1/2, 0.5, 3.14 tam sayı değildir'
        ]
      },
      {
        id: 'mutlak-deger',
        title: 'Mutlak Değer',
        content: `Mutlak değer, bir sayının sayı doğrusunda sıfıra olan uzaklığını gösterir.

|a| sembolü ile gösterilir ve her zaman pozitif veya sıfırdır.

Kurallar:
• |a| = a, eğer a ≥ 0 ise
• |a| = -a, eğer a < 0 ise

Örnek: |-5| = 5, |3| = 3, |0| = 0

Önemli Özellikler:
• |a| ≥ 0 (Her zaman sıfır veya pozitif)
• |a| = |-a| (Zıt sayıların mutlak değeri eşittir)
• |a × b| = |a| × |b|`,
        examples: [
          '|-7| = 7',
          '|4| = 4',
          '|-3| + |5| = 3 + 5 = 8'
        ]
      },
      {
        id: 'tam-sayilarda-toplama',
        title: 'Tam Sayılarda Toplama',
        content: `Aynı işaretli sayıların toplamı:
Mutlak değerler toplanır ve ortak işaret yazılır.

Farklı işaretli sayıların toplamı:
Mutlak değerler çıkarılır ve büyük mutlak değerli sayının işareti yazılır.

Kurallar:
• (+a) + (+b) = +(a+b)
• (-a) + (-b) = -(a+b)
• (+a) + (-b) = a-b (a>b ise pozitif, a<b ise negatif)

Toplama işlemi değişme ve birleşme özelliklerine sahiptir.`,
        examples: [
          '(+5) + (+3) = +8',
          '(-4) + (-6) = -10',
          '(+7) + (-3) = +4',
          '(-8) + (+5) = -3'
        ]
      },
      {
        id: 'tam-sayilarda-cikarma',
        title: 'Tam Sayılarda Çıkarma',
        content: `Çıkarma işlemi, eksilen sayıya çıkanın zıt işaretlisini eklemektir.

a - b = a + (-b)

Yani çıkarma işlemini toplama işlemine çevirebiliriz.

Kurallar:
• a - (+b) = a + (-b) = a - b
• a - (-b) = a + (+b) = a + b

"Eksi eksi artı" kuralı: İki eksi yan yana gelirse artı olur.`,
        examples: [
          '8 - (+5) = 8 - 5 = 3',
          '8 - (-5) = 8 + 5 = 13',
          '(-6) - (+2) = -6 - 2 = -8',
          '(-6) - (-2) = -6 + 2 = -4'
        ]
      },
      {
        id: 'tam-sayilarda-carpma-bolme',
        title: 'Çarpma ve Bölme',
        content: `Çarpma Kuralları:
• (+) × (+) = (+) Pozitif
• (-) × (-) = (+) Pozitif  
• (+) × (-) = (-) Negatif
• (-) × (+) = (-) Negatif

Aynı işaretli sayıların çarpımı POZİTİF
Farklı işaretli sayıların çarpımı NEGATİF

Bölme Kuralları:
Bölme işleminde de aynı işaret kuralları geçerlidir.
• (+) ÷ (+) = (+)
• (-) ÷ (-) = (+)
• (+) ÷ (-) = (-)
• (-) ÷ (+) = (-)`,
        examples: [
          '(+4) × (+3) = +12',
          '(-4) × (-3) = +12',
          '(+4) × (-3) = -12',
          '(-12) ÷ (+4) = -3',
          '(-12) ÷ (-4) = +3'
        ]
      }
    ]
  },
  {
    id: 'rasyonel-sayilar',
    name: 'Rasyonel Sayılar',
    icon: '📊',
    color: 'green',
    description: 'Kesirler, ondalık sayılar ve işlemler',
    lessons: [
      {
        id: 'rasyonel-giris',
        title: 'Rasyonel Sayılara Giriş',
        content: `Rasyonel sayı, a/b (b ≠ 0) şeklinde yazılabilen sayılardır.

Q = {a/b : a, b ∈ Z, b ≠ 0}

Rasyonel sayılar şunları içerir:
• Tam sayılar (örneğin 5 = 5/1)
• Kesirler (örneğin 3/4)
• Sonlu ondalık sayılar (örneğin 0.5 = 1/2)
• Devirli ondalık sayılar (örneğin 0.333... = 1/3)

Her kesir bir rasyonel sayıdır.`,
        examples: [
          '3/4, -2/5, 7/1 rasyonel sayılardır',
          '√2, π rasyonel sayı değildir (irrasyonel)'
        ]
      },
      {
        id: 'kesirlerde-islemler',
        title: 'Kesirlerde Dört İşlem',
        content: `TOPLAMA ve ÇIKARMA:
Paydalar aynı ise: Paylar toplanır/çıkarılır, payda aynı kalır.
Paydalar farklı ise: Önce paydalar eşitlenir (EKOK alınır).

a/b + c/b = (a+c)/b
a/b + c/d = (ad + bc)/bd

ÇARPMA:
Pay ile pay, payda ile payda çarpılır.
a/b × c/d = (a × c)/(b × d)

BÖLME:
İkinci kesrin tersi ile çarpılır.
a/b ÷ c/d = a/b × d/c = (a × d)/(b × c)`,
        examples: [
          '2/5 + 1/5 = 3/5',
          '1/2 + 1/3 = 3/6 + 2/6 = 5/6',
          '2/3 × 4/5 = 8/15',
          '3/4 ÷ 2/5 = 3/4 × 5/2 = 15/8'
        ]
      },
      {
        id: 'ondalik-kesir',
        title: 'Ondalık Kesirler',
        content: `Ondalık kesir, paydası 10, 100, 1000, ... gibi 10'un kuvvetleri olan kesirlerdir.

Kesri ondalığa çevirme:
Pay, paydaya bölünür.

Ondalığı kesre çevirme:
Virgülden sonraki basamak sayısı kadar sıfırlı payda yazılır.

Örnek: 0.75 = 75/100 = 3/4

Devirli Ondalık Sayılar:
Bazı kesirler devirli ondalık sayı olur.
1/3 = 0.333... = 0.3̄ (3 devirli)`,
        examples: [
          '3/4 = 0.75',
          '1/8 = 0.125',
          '0.6 = 6/10 = 3/5',
          '2/3 = 0.666... = 0.6̄ (6 devirli)'
        ]
      },
      {
        id: 'sadelestirme',
        title: 'Sadeleştirme ve Genişletme',
        content: `SADELEŞTİRME:
Pay ve paydayı aynı sayıya bölerek kesri en sade haline getirme.

EBOB (En Büyük Ortak Bölen) kullanılır.

12/18 → EBOB(12,18) = 6 → 12÷6 / 18÷6 = 2/3

GENİŞLETME:
Pay ve paydayı aynı sayıyla çarpma.
Kesrin değeri değişmez.

2/3 = 4/6 = 6/9 = 8/12 ...

Paydaları eşitlemek için EKOK kullanılır.`,
        examples: [
          '24/36 = 2/3 (12\'ye bölündü)',
          '15/25 = 3/5 (5\'e bölündü)',
          '3/4 = 9/12 (3 ile genişletildi)'
        ]
      }
    ]
  },
  {
    id: 'cebirsel-ifadeler',
    name: 'Cebirsel İfadeler',
    icon: '🔤',
    color: 'purple',
    description: 'Değişkenli ifadeler ve denklemler',
    lessons: [
      {
        id: 'cebir-giris',
        title: 'Cebirsel İfadelere Giriş',
        content: `Cebirsel ifade, sayı ve değişkenlerin dört işlemle birleşmesidir.

Değişken: Değer alabilen harf (x, y, a, b...)
Katsayı: Değişkenin önündeki sayı
Sabit terim: Değişkensiz sayı

Örnek: 3x + 5y - 2
• 3x ve 5y değişkenli terimler
• 3 ve 5 katsayılar
• -2 sabit terim

Benzer Terimler:
Aynı değişkenlere sahip terimler.
3x ve 5x benzer, 3x ve 3y benzer değil.`,
        examples: [
          '2x + 3 (x değişkeni, 2 katsayı, 3 sabit)',
          '5a - 2b + 7 (iki değişkenli)',
          '4x² + 3x - 1 (ikinci dereceden)'
        ]
      },
      {
        id: 'toplama-cikarma',
        title: 'Toplama ve Çıkarma',
        content: `Cebirsel ifadeleri toplarken veya çıkarırken SADECE BENZER TERİMLER toplanır/çıkarılır.

Kural: Katsayılar toplanır, değişken aynı kalır.

3x + 5x = 8x
7a - 2a = 5a
4x + 3y + 2x + y = 6x + 4y

Dikkat: x ile y, a ile b TOPLANAMAZ!

Parantezli İşlemler:
Toplama: Parantez açılır, işaret değişmez.
Çıkarma: Parantez açılır, tüm işaretler değişir.`,
        examples: [
          '(3x + 2) + (5x - 1) = 8x + 1',
          '(7a - 3) - (2a + 5) = 7a - 3 - 2a - 5 = 5a - 8',
          '4m + 3n + 2m - n = 6m + 2n'
        ]
      },
      {
        id: 'carpma-bolme',
        title: 'Çarpma ve Bölme',
        content: `ÇARPMA:
Katsayılar çarpılır, değişkenin üsleri toplanır.

a × a = a²
2x × 3x = 6x²
3a × 4a² = 12a³

Parantezle Çarpma (Dağılma Özelliği):
a(b + c) = ab + ac

2(x + 3) = 2x + 6
x(x + 5) = x² + 5x

BÖLME:
Katsayılar bölünür, değişkenin üsleri çıkarılır.

6x² ÷ 2x = 3x
12a³ ÷ 4a = 3a²`,
        examples: [
          '5 × 3x = 15x',
          '2x × 4x = 8x²',
          '3(2a + 4) = 6a + 12',
          '10x² ÷ 5x = 2x'
        ]
      },
      {
        id: 'denklemler',
        title: 'Birinci Dereceden Denklemler',
        content: `Denklem, eşitlik içeren cebirsel ifadedir.

Amaç: Bilinmeyenin (x) değerini bulmak.

Çözüm Yöntemi:
1. Parantezleri aç
2. Benzer terimleri topla
3. x\'li terimleri bir tarafa, sayıları diğer tarafa topla
4. Her iki tarafı x\'in katsayısına böl

Önemli: Bir tarafa geçen terimin işareti değişir!

Örnek: 2x + 5 = 11
2x = 11 - 5
2x = 6
x = 3`,
        examples: [
          'x + 7 = 12 → x = 5',
          '3x - 4 = 14 → 3x = 18 → x = 6',
          '2(x + 3) = 16 → 2x + 6 = 16 → x = 5',
          '5x - 3 = 2x + 9 → 3x = 12 → x = 4'
        ]
      }
    ]
  },
  {
    id: 'oran-oranti',
    name: 'Oran ve Orantı',
    icon: '⚖️',
    color: 'orange',
    description: 'Oran, orantı ve problemler',
    lessons: [
      {
        id: 'oran-giris',
        title: 'Oran Kavramı',
        content: `Oran, aynı tür iki büyüklüğün birbirine bölünmesiyle elde edilen sayıdır.

a\'nın b\'ye oranı: a/b veya a:b

Örnek: Sınıfta 12 kız, 8 erkek var.
Kız/Erkek oranı = 12/8 = 3/2 veya 3:2

Özellikler:
• Oran birimsiz bir sayıdır
• Oran sadeleştirilebilir
• a:b ≠ b:a (sıralama önemli)

Üç Sayının Oranı:
a:b:c şeklinde yazılır.
Örnek: 2:3:5`,
        examples: [
          '15\'in 25\'e oranı = 15/25 = 3/5',
          '100 km yol, 2 saat → Hız = 50 km/saat',
          'A:B = 2:3 ve B:C = 3:4 ise A:B:C = 2:3:4'
        ]
      },
      {
        id: 'oranti',
        title: 'Orantı',
        content: `Orantı, iki oranın eşitliğidir.

a/b = c/d → a.d = b.c (İç çarpım = Dış çarpım)

Bu kurala "çapraz çarpım" da denir.

Orantı Çözümü:
x/4 = 6/8
8x = 24
x = 3

Orantı Türleri:
1. Doğru Orantı: x artarsa y de artar
2. Ters Orantı: x artarsa y azalır`,
        examples: [
          '2/5 = x/15 → 5x = 30 → x = 6',
          '3/x = 9/12 → 9x = 36 → x = 4',
          'x:4 = 12:16 → x = 3'
        ]
      },
      {
        id: 'dogrudan-oranti',
        title: 'Doğru Orantı',
        content: `İki büyüklük birlikte artıp birlikte azalıyorsa doğru orantılıdır.

y = k.x (k sabit)

Örnek: Elma fiyatı
3 kg → 45 TL
5 kg → ? TL

3/45 = 5/x
x = 75 TL

Özellik: x₁/y₁ = x₂/y₂

Grafik: Orijinden geçen doğru`,
        examples: [
          '2 kalem 10 TL ise 5 kalem 25 TL\'dir',
          '4 işçi 8 saatte yaparsa, iş miktarı iki katına çıkarsa süre de iki kat olur',
          'Hız sabitse, yol ve süre doğru orantılıdır'
        ]
      },
      {
        id: 'ters-oranti',
        title: 'Ters Orantı',
        content: `Bir büyüklük artarken diğeri azalıyorsa ters orantılıdır.

x.y = k (k sabit)

Örnek: İşçi sayısı ve süre
6 işçi → 12 gün
9 işçi → ? gün

6 × 12 = 9 × ?
72 = 9x
x = 8 gün

Özellik: x₁.y₁ = x₂.y₂

Daha fazla işçi = Daha az süre`,
        examples: [
          '4 işçi 15 günde yapar, 6 işçi 10 günde yapar',
          'Hız artarsa süre azalır',
          '60 km/s ile 2 saat, 40 km/s ile 3 saat'
        ]
      }
    ]
  },
  {
    id: 'geometri',
    name: 'Geometri',
    icon: '📐',
    color: 'pink',
    description: 'Açılar, üçgenler ve dörtgenler',
    lessons: [
      {
        id: 'acilar',
        title: 'Açılar',
        content: `Açı, aynı noktadan çıkan iki ışının oluşturduğu şekildir.

Açı Türleri:
• Dar açı: 0° < açı < 90°
• Dik açı: 90°
• Geniş açı: 90° < açı < 180°
• Doğru açı: 180°
• Tam açı: 360°

Komşu Açılar: Ortak kenarı olan açılar
Tümler Açılar: Toplamı 90°
Bütünler Açılar: Toplamı 180°`,
        examples: [
          '45° dar açıdır',
          'Bir açının tümleri: 90° - açı',
          'Bir açının bütünleri: 180° - açı'
        ]
      },
      {
        id: 'ucgenler',
        title: 'Üçgenler',
        content: `Üçgenin iç açıları toplamı = 180°

Kenar Uzunluklarına Göre:
• Eşkenar: Üç kenar eşit
• İkizkenar: İki kenar eşit
• Çeşitkenar: Üç kenar farklı

Açılarına Göre:
• Dar açılı: Tüm açılar dar
• Dik açılı: Bir açı 90°
• Geniş açılı: Bir açı geniş

Üçgen Eşitsizliği:
Herhangi iki kenar toplamı, üçüncü kenardan büyüktür.
a + b > c`,
        examples: [
          'Eşkenar üçgende her açı 60° dir',
          'İkizkenar üçgende taban açıları eşittir',
          '3, 4, 5 bir üçgen oluşturur (3+4>5, 4+5>3, 3+5>4)'
        ]
      },
      {
        id: 'ucgen-alan',
        title: 'Üçgen Alanı',
        content: `Üçgen Alanı = (Taban × Yükseklik) / 2

A = (a × h) / 2

Yükseklik, tabana dik olan uzunluktur.

Dik Üçgende:
Dik kenarların çarpımı / 2

Eşkenar Üçgende:
A = (a² × √3) / 4

Çevre = Tüm kenarların toplamı`,
        examples: [
          'Taban=8, Yükseklik=6 → Alan = 8×6/2 = 24',
          'Dik kenarlar 3,4 → Alan = 3×4/2 = 6',
          'Kenarları 5,7,8 → Çevre = 20'
        ]
      },
      {
        id: 'dortgenler',
        title: 'Dörtgenler',
        content: `Dörtgenin iç açıları toplamı = 360°

KARE:
• 4 kenar eşit, 4 açı dik
• Alan = a²
• Çevre = 4a

DİKDÖRTGEN:
• Karşı kenarlar eşit, 4 açı dik
• Alan = a × b
• Çevre = 2(a+b)

PARALELKENAR:
• Karşı kenarlar paralel ve eşit
• Alan = taban × yükseklik

YAMUK:
• Bir çift karşı kenar paralel
• Alan = (a+b) × h / 2`,
        examples: [
          'Kare: a=5 → Alan=25, Çevre=20',
          'Dikdörtgen: 6×4 → Alan=24, Çevre=20',
          'Paralelkenar: taban=8, h=5 → Alan=40'
        ]
      }
    ]
  },
  {
    id: 'veri-analizi',
    name: 'Veri Analizi',
    icon: '📈',
    color: 'cyan',
    description: 'Ortalama, ortanca, grafik okuma',
    lessons: [
      {
        id: 'merkezi-egilim',
        title: 'Merkezi Eğilim Ölçüleri',
        content: `ARİTMETİK ORTALAMA:
Verilerin toplamının veri sayısına bölünmesi.
Ortalama = Toplam / Adet

ORTANCA (MEDYAN):
Veriler sıralandığında ortadaki değer.
Çift sayıda veri varsa ortadaki ikisinin ortalaması.

MOD (TEPE DEĞER):
En çok tekrar eden değer.
Birden fazla mod olabilir.`,
        examples: [
          '5,8,3,9,5 → Ortalama = 30/5 = 6',
          '3,5,5,8,9 → Ortanca = 5',
          '3,5,5,5,8,9 → Mod = 5'
        ]
      },
      {
        id: 'yayilim',
        title: 'Yayılım Ölçüleri',
        content: `AÇIKLIK (DEĞİŞİM ARALIĞI):
En büyük değer - En küçük değer

Açıklık = Max - Min

Açıklık büyükse veriler geniş bir aralığa yayılmış demektir.

KARTİLLER:
Verileri dört eşit parçaya bölen noktalar.
Q1: 1. çeyrek
Q2: Ortanca
Q3: 3. çeyrek

Çeyrekler Arası Açıklık = Q3 - Q1`,
        examples: [
          '2,5,7,12,15 → Açıklık = 15-2 = 13',
          'Küçük açıklık = Veriler birbirine yakın'
        ]
      },
      {
        id: 'grafikler',
        title: 'Grafik Türleri',
        content: `SÜTUN GRAFİK:
Kategorik verileri kar��ılaştırmak için.
Her kategori bir sütunla gösterilir.

ÇİZGİ GRAFİK:
Zaman içindeki değişimi göstermek için.
Noktalar çizgiyle birleştirilir.

DAİRE GRAFİK (PASTA):
Bütünün parçalara dağılımını gösterir.
Açıların toplamı 360°.

HİSTOGRAM:
Aralıklı sayısal veriler için.
Sütunlar yan yana, boşluk yok.`,
        examples: [
          'Aylık sıcaklık → Çizgi grafik',
          'Sınıftaki öğrenci sayısı → Sütun grafik',
          'Bütçe dağılımı → Daire grafik'
        ]
      },
      {
        id: 'olasilik',
        title: 'Olasılık',
        content: `Olasılık, bir olayın gerçekleşme ihtimalidir.

P(A) = İstenen sonuç sayısı / Tüm sonuç sayısı

0 ≤ P(A) ≤ 1

P(A) = 0 → Olay kesinlikle gerçekleşmez
P(A) = 1 → Olay kesinlikle gerçekleşir

Örnek: Zar atma
P(6 gelme) = 1/6
P(çift gelme) = 3/6 = 1/2`,
        examples: [
          'Yazı-tura: P(yazı) = 1/2',
          'Zar: P(3 gelme) = 1/6',
          '52 karttan as çekme: P(as) = 4/52 = 1/13'
        ]
      }
    ]
  },
  {
    id: 'yuzde-problemleri',
    name: 'Yüzde Problemleri',
    icon: '💯',
    color: 'blue',
    description: 'Yüzde hesaplama, artış ve azalış',
    lessons: [
      {
        id: 'yuzde-giris',
        title: 'Yüzde Kavramı',
        content: `Yüzde, bir bütünün 100 eşit parçaya bölünmesiyle elde edilen oranlardır.

% sembolü ile gösterilir.

%25 = 25/100 = 1/4 = 0.25

Kesirden Yüzdeye:
Kesri 100 ile çarp.
3/4 = 3/4 × 100 = %75

Yüzdeden Kesire:
Yüzdeyi 100'e böl.
%60 = 60/100 = 3/5`,
        examples: [
          '%50 = 1/2 = 0.5',
          '%25 = 1/4 = 0.25',
          '%10 = 1/10 = 0.1'
        ]
      },
      {
        id: 'yuzde-hesaplama',
        title: 'Yüzde Hesaplama',
        content: `Bir sayının yüzdesini bulma:
Sayı × (Yüzde/100)

200'ün %30'u = 200 × 30/100 = 60

Yüzde bulma:
(Parça/Bütün) × 100

60, 200'ün yüzde kaçıdır?
(60/200) × 100 = %30

Bütünü bulma:
Parça ÷ (Yüzde/100)

Bir sayının %40'ı 80 ise sayı kaçtır?
80 ÷ 0.40 = 200`,
        examples: [
          '150\'nin %20\'si = 30',
          '45, 90\'ın %50\'sidir',
          '%25\'i 50 olan sayı = 200'
        ]
      },
      {
        id: 'yuzde-artis-azalis',
        title: 'Yüzde Artış ve Azalış',
        content: `YÜZDE ARTIŞ:
Yeni Değer = Eski × (1 + Yüzde/100)

100 TL, %20 artış → 100 × 1.20 = 120 TL

YÜZDE AZALIŞ:
Yeni Değer = Eski × (1 - Yüzde/100)

100 TL, %20 azalış → 100 × 0.80 = 80 TL

Artış oranı = (Fark/Eski) × 100`,
        examples: [
          '500 TL, %10 artış → 550 TL',
          '200 TL, %25 indirim → 150 TL',
          '80\'den 100\'e artış = %25 artış'
        ]
      },
      {
        id: 'kar-zarar',
        title: 'Kâr ve Zarar Problemleri',
        content: `KÂR HESABI:
Kâr = Satış Fiyatı - Maliyet
Kâr Yüzdesi = (Kâr / Maliyet) × 100

ZARAR HESABI:
Zarar = Maliyet - Satış Fiyatı
Zarar Yüzdesi = (Zarar / Maliyet) × 100

ÖNEMLİ: Kâr/Zarar yüzdesi her zaman maliyet üzerinden hesaplanır.`,
        examples: [
          '100 TL ye alınan ürün 130 TL ye satılırsa: %30 kâr',
          '200 TL ye alınan ürün 150 TL ye satılırsa: %25 zarar',
          'Maliyet 80 TL, %25 kâr ile satış: 80 × 1.25 = 100 TL'
        ]
      },
      {
        id: 'ardisik-yuzde',
        title: 'Ardışık Yüzde Değişimleri',
        content: `Bir miktar önce %a artıp sonra %b azalırsa:
Son Değer = Başlangıç × (1 + a/100) × (1 - b/100)

DİKKAT: %20 artış sonra %20 azalış başlangıca eşit DEĞİLDİR!

Örnek: 100 TL önce %20 artar sonra %20 azalır
100 × 1.20 = 120 TL
120 × 0.80 = 96 TL (Başlangıçtan 4 TL az!)`,
        examples: [
          '100 → %50 artış → %50 azalış = 75 (25 eksik!)',
          '200 → %10 artış → %10 artış = 242',
          '500 → %20 azalış → %25 artış = 500'
        ]
      }
    ]
  },
  {
    id: 'cember-daire',
    name: 'Çember ve Daire',
    icon: '⭕',
    color: 'green',
    description: 'Çember, daire, alan ve çevre',
    lessons: [
      {
        id: 'cember-giris',
        title: 'Çember ve Daire Kavramları',
        content: `ÇEMBER:
Bir noktaya eşit uzaklıktaki noktaların oluşturduğu kapalı eğri.

DAİRE:
Çemberin iç bölgesi ile birlikte.

Terimler:
• Merkez (O): Çemberin ortası
• Yarıçap (r): Merkezden çembere uzaklık
• Çap (d): Çemberden geçen en uzun doğru (d = 2r)
• π (pi) ≈ 3.14 veya 22/7`,
        examples: [
          'r = 5 cm ise d = 10 cm',
          'd = 14 cm ise r = 7 cm'
        ]
      },
      {
        id: 'cevre-alan',
        title: 'Çevre ve Alan Formülleri',
        content: `ÇEMBER ÇEVRESİ:
Ç = 2πr veya Ç = πd

DAİRE ALANI:
A = πr²

Örnek: r = 7 cm (π = 22/7)
Çevre = 2 × 22/7 × 7 = 44 cm
Alan = 22/7 × 7 × 7 = 154 cm²`,
        examples: [
          'r=10 → Çevre = 62.8 cm',
          'r=10 → Alan = 314 cm²',
          'd=14 → Çevre = 44 cm'
        ]
      },
      {
        id: 'daire-dilimi',
        title: 'Daire Dilimi ve Yay',
        content: `DAİRE DİLİMİ ALANI:
A = (α/360) × πr²

YAY UZUNLUĞU:
L = (α/360) × 2πr

Burada α merkez açısıdır (derece cinsinden).

90°'lik dilim = Dairenin 1/4'ü
180°'lik dilim = Dairenin 1/2'si`,
        examples: [
          'r=6, α=60° → Dilim Alanı = (60/360) × π × 36 = 6π cm²',
          'r=10, α=90° → Yay = (90/360) × 2π × 10 = 5π cm',
          'r=7, α=180° → Yarım daire alanı = 77 cm²'
        ]
      },
      {
        id: 'silindir',
        title: 'Silindir',
        content: `SİLİNDİR:
Taban çemberi üzerinde düzgün bir şekilde yükselen geometrik cisim.

TAM YÜZEY ALANI:
A = 2πr² + 2πrh = 2πr(r + h)

HACİM:
V = πr²h

r = taban yarıçapı
h = yükseklik`,
        examples: [
          'r=3, h=5 → Hacim = π × 9 × 5 = 45π cm³',
          'r=7, h=10 → Yüzey = 2π × 7 × (7+10) = 238π cm²',
          'Taban alanı 25π, h=8 → V = 200π cm³'
        ]
      }
    ]
  }
]
