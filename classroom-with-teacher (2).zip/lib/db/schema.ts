import { pgTable, serial, text, varchar, integer, boolean, timestamp, char } from 'drizzle-orm/pg-core'

// Siniflar tablosu
export const classrooms = pgTable('classrooms', {
  id: serial('id').primaryKey(),
  code: varchar('code', { length: 5 }).unique().notNull(),
  name: varchar('name', { length: 100 }).notNull(),
  teacherId: text('teacher_id').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
})

// Sinifa katilan ogrenciler
export const classroomStudents = pgTable('classroom_students', {
  id: serial('id').primaryKey(),
  classroomId: integer('classroom_id').notNull(),
  studentName: varchar('student_name', { length: 100 }).notNull(),
  studentId: text('student_id'),
  points: integer('points').default(0),
  joinedAt: timestamp('joined_at').defaultNow(),
})

// Sinavlar
export const exams = pgTable('exams', {
  id: serial('id').primaryKey(),
  classroomId: integer('classroom_id').notNull(),
  title: varchar('title', { length: 200 }).notNull(),
  description: text('description'),
  createdAt: timestamp('created_at').defaultNow(),
  isActive: boolean('is_active').default(true),
})

// Sinav sorulari
export const examQuestions = pgTable('exam_questions', {
  id: serial('id').primaryKey(),
  examId: integer('exam_id').notNull(),
  question: text('question').notNull(),
  optionA: text('option_a').notNull(),
  optionB: text('option_b').notNull(),
  optionC: text('option_c').notNull(),
  optionD: text('option_d').notNull(),
  correctAnswer: char('correct_answer', { length: 1 }).notNull(),
  points: integer('points').default(10),
})

// Ogrenci cevaplari
export const studentAnswers = pgTable('student_answers', {
  id: serial('id').primaryKey(),
  examId: integer('exam_id').notNull(),
  studentId: integer('student_id').notNull(),
  questionId: integer('question_id').notNull(),
  answer: char('answer', { length: 1 }),
  isCorrect: boolean('is_correct'),
  answeredAt: timestamp('answered_at').defaultNow(),
})

// Kullanici envanteri
export const userInventory = pgTable('user_inventory', {
  id: serial('id').primaryKey(),
  userIdentifier: text('user_identifier').notNull(),
  itemId: text('item_id').notNull(),
  itemType: varchar('item_type', { length: 50 }).notNull(),
  quantity: integer('quantity').default(1),
  acquiredAt: timestamp('acquired_at').defaultNow(),
})
