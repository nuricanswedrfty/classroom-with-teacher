// Sonsuz soru üretici - Her konu için dinamik sorular

export interface Question {
  id: string
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
  difficulty: 'kolay' | 'orta' | 'zor'
}

// Rastgele sayı üretici
function randomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array]
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]]
  }
  return shuffled
}

// Tam Sayılar Soruları
function generateIntegerQuestions(): Question[] {
  const questions: Question[] = []
  
  // Toplama
  for (let i = 0; i < 5; i++) {
    const a = randomInt(-50, 50)
    const b = randomInt(-50, 50)
    const result = a + b
    const wrongAnswers = [result + randomInt(1, 10), result - randomInt(1, 10), result * -1].filter(x => x !== result)
    
    questions.push({
      id: `int-add-${Date.now()}-${i}`,
      question: `(${a}) + (${b}) isleminin sonucu kactir?`,
      options: shuffleArray([result.toString(), ...wrongAnswers.slice(0, 3).map(String)]),
      correctAnswer: 0,
      explanation: `(${a}) + (${b}) = ${result}. ${a < 0 && b < 0 ? 'Iki negatif sayinin toplami negatiftir.' : a < 0 || b < 0 ? 'Farkli isaretli sayilarda buyuk mutlak degerin isareti alinir.' : 'Iki pozitif sayinin toplami pozitiftir.'}`,
      difficulty: Math.abs(a) > 30 || Math.abs(b) > 30 ? 'zor' : Math.abs(a) > 15 ? 'orta' : 'kolay'
    })
  }
  
  // Çıkarma
  for (let i = 0; i < 5; i++) {
    const a = randomInt(-40, 40)
    const b = randomInt(-40, 40)
    const result = a - b
    const wrongAnswers = [result + randomInt(1, 10), result - randomInt(1, 10), a + b]
    
    questions.push({
      id: `int-sub-${Date.now()}-${i}`,
      question: `(${a}) - (${b}) isleminin sonucu kactir?`,
      options: shuffleArray([result.toString(), ...wrongAnswers.filter(x => x !== result).slice(0, 3).map(String)]),
      correctAnswer: 0,
      explanation: `(${a}) - (${b}) = (${a}) + (${-b}) = ${result}. Cikarma islemi, cikarilani eksi ile carpip toplama donusturulur.`,
      difficulty: 'orta'
    })
  }
  
  // Çarpma
  for (let i = 0; i < 5; i++) {
    const a = randomInt(-12, 12)
    const b = randomInt(-12, 12)
    const result = a * b
    const wrongAnswers = [result + randomInt(1, 20), -result, a + b]
    
    questions.push({
      id: `int-mul-${Date.now()}-${i}`,
      question: `(${a}) x (${b}) isleminin sonucu kactir?`,
      options: shuffleArray([result.toString(), ...wrongAnswers.filter(x => x !== result).slice(0, 3).map(String)]),
      correctAnswer: 0,
      explanation: `(${a}) x (${b}) = ${result}. ${(a < 0 && b < 0) || (a > 0 && b > 0) ? 'Ayni isaretli sayilarin carpimi pozitiftir.' : 'Farkli isaretli sayilarin carpimi negatiftir.'}`,
      difficulty: Math.abs(a) > 8 || Math.abs(b) > 8 ? 'zor' : 'orta'
    })
  }
  
  // Bölme
  for (let i = 0; i < 5; i++) {
    const b = randomInt(1, 10) * (Math.random() > 0.5 ? 1 : -1)
    const result = randomInt(-10, 10)
    const a = b * result
    const wrongAnswers = [result + randomInt(1, 5), -result, result * 2]
    
    questions.push({
      id: `int-div-${Date.now()}-${i}`,
      question: `(${a}) / (${b}) isleminin sonucu kactir?`,
      options: shuffleArray([result.toString(), ...wrongAnswers.filter(x => x !== result).slice(0, 3).map(String)]),
      correctAnswer: 0,
      explanation: `(${a}) / (${b}) = ${result}. ${(a < 0 && b < 0) || (a > 0 && b > 0) ? 'Ayni isaretli sayilarin bolumu pozitiftir.' : 'Farkli isaretli sayilarin bolumu negatiftir.'}`,
      difficulty: 'orta'
    })
  }
  
  // Mutlak Değer
  for (let i = 0; i < 5; i++) {
    const a = randomInt(-50, 50)
    const result = Math.abs(a)
    const wrongAnswers = [-result, a, result + randomInt(1, 10)]
    
    questions.push({
      id: `int-abs-${Date.now()}-${i}`,
      question: `|${a}| mutlak degerinin sonucu kactir?`,
      options: shuffleArray([result.toString(), ...wrongAnswers.filter(x => x !== result).slice(0, 3).map(String)]),
      correctAnswer: 0,
      explanation: `|${a}| = ${result}. Mutlak deger her zaman pozitif veya sifirdir. Sayinin sifira olan uzakligini gosterir.`,
      difficulty: 'kolay'
    })
  }

  // İşlem önceliği
  for (let i = 0; i < 5; i++) {
    const a = randomInt(2, 8)
    const b = randomInt(2, 6)
    const c = randomInt(1, 5)
    const result = a + b * c
    const wrongAnswer1 = (a + b) * c
    const wrongAnswers = [wrongAnswer1, result + randomInt(1, 10), result - randomInt(1, 5)]
    
    questions.push({
      id: `int-order-${Date.now()}-${i}`,
      question: `${a} + ${b} x ${c} isleminin sonucu kactir?`,
      options: shuffleArray([result.toString(), ...wrongAnswers.filter(x => x !== result).slice(0, 3).map(String)]),
      correctAnswer: 0,
      explanation: `Islem onceligi: Once carpma yapilir. ${b} x ${c} = ${b * c}, sonra ${a} + ${b * c} = ${result}`,
      difficulty: 'orta'
    })
  }

  return questions.map(q => ({
    ...q,
    correctAnswer: q.options.indexOf(q.options.find((_, idx) => idx === 0) || q.options[0])
  }))
}

// Rasyonel Sayılar Soruları
function generateRationalQuestions(): Question[] {
  const questions: Question[] = []
  
  // Kesir toplama
  for (let i = 0; i < 5; i++) {
    const denom = randomInt(2, 8)
    const num1 = randomInt(1, denom - 1)
    const num2 = randomInt(1, denom - 1)
    const resultNum = num1 + num2
    
    questions.push({
      id: `rat-add-${Date.now()}-${i}`,
      question: `${num1}/${denom} + ${num2}/${denom} isleminin sonucu kactir?`,
      options: shuffleArray([`${resultNum}/${denom}`, `${num1 + num2}/${denom * 2}`, `${num1 * num2}/${denom}`, `${resultNum}/${denom + 1}`]),
      correctAnswer: 0,
      explanation: `Paydalar esit oldugunda paylar toplanir: ${num1}/${denom} + ${num2}/${denom} = ${resultNum}/${denom}`,
      difficulty: 'kolay'
    })
  }
  
  // Farklı paydalı kesir toplama
  for (let i = 0; i < 5; i++) {
    const d1 = randomInt(2, 5)
    const d2 = d1 * 2
    const n1 = randomInt(1, d1 - 1)
    const n2 = randomInt(1, d2 - 1)
    const commonDenom = d2
    const resultNum = n1 * 2 + n2
    
    questions.push({
      id: `rat-add2-${Date.now()}-${i}`,
      question: `${n1}/${d1} + ${n2}/${d2} isleminin sonucu kactir?`,
      options: shuffleArray([`${resultNum}/${commonDenom}`, `${n1 + n2}/${d1 + d2}`, `${n1 + n2}/${d1}`, `${resultNum}/${d1}`]),
      correctAnswer: 0,
      explanation: `Paydalari esitliyoruz: ${n1}/${d1} = ${n1 * 2}/${d2}. Sonra ${n1 * 2}/${d2} + ${n2}/${d2} = ${resultNum}/${commonDenom}`,
      difficulty: 'orta'
    })
  }
  
  // Kesir çarpma
  for (let i = 0; i < 5; i++) {
    const n1 = randomInt(1, 5)
    const d1 = randomInt(2, 6)
    const n2 = randomInt(1, 5)
    const d2 = randomInt(2, 6)
    const resultN = n1 * n2
    const resultD = d1 * d2
    
    questions.push({
      id: `rat-mul-${Date.now()}-${i}`,
      question: `${n1}/${d1} x ${n2}/${d2} isleminin sonucu kactir?`,
      options: shuffleArray([`${resultN}/${resultD}`, `${n1 + n2}/${d1 + d2}`, `${n1 * d2}/${d1 * n2}`, `${resultN}/${d1 + d2}`]),
      correctAnswer: 0,
      explanation: `Kesir carpiminda paylar carpilir, paydalar carpilir: ${n1}x${n2}/${d1}x${d2} = ${resultN}/${resultD}`,
      difficulty: 'orta'
    })
  }
  
  // Kesir bölme
  for (let i = 0; i < 5; i++) {
    const n1 = randomInt(1, 5)
    const d1 = randomInt(2, 6)
    const n2 = randomInt(1, 5)
    const d2 = randomInt(2, 6)
    const resultN = n1 * d2
    const resultD = d1 * n2
    
    questions.push({
      id: `rat-div-${Date.now()}-${i}`,
      question: `${n1}/${d1} / ${n2}/${d2} isleminin sonucu kactir?`,
      options: shuffleArray([`${resultN}/${resultD}`, `${n1 * n2}/${d1 * d2}`, `${n1 + n2}/${d1 + d2}`, `${d1 * d2}/${n1 * n2}`]),
      correctAnswer: 0,
      explanation: `Kesir bolmede ikinci kesirin tersi ile carpilir: ${n1}/${d1} x ${d2}/${n2} = ${resultN}/${resultD}`,
      difficulty: 'zor'
    })
  }
  
  // Ondalık kesir
  for (let i = 0; i < 5; i++) {
    const a = (randomInt(1, 99) / 10).toFixed(1)
    const b = (randomInt(1, 99) / 10).toFixed(1)
    const result = (parseFloat(a) + parseFloat(b)).toFixed(1)
    
    questions.push({
      id: `rat-dec-${Date.now()}-${i}`,
      question: `${a} + ${b} isleminin sonucu kactir?`,
      options: shuffleArray([result, (parseFloat(a) - parseFloat(b)).toFixed(1), (parseFloat(a) * parseFloat(b)).toFixed(1), (parseFloat(result) + 1).toFixed(1)]),
      correctAnswer: 0,
      explanation: `Ondalik sayilarda virgul alt alta gelecek sekilde toplanir: ${a} + ${b} = ${result}`,
      difficulty: 'kolay'
    })
  }

  return questions.map(q => ({
    ...q,
    correctAnswer: q.options.indexOf(q.options[0])
  }))
}

// Cebirsel İfadeler Soruları
function generateAlgebraQuestions(): Question[] {
  const questions: Question[] = []
  
  // Basit denklem çözme
  for (let i = 0; i < 5; i++) {
    const a = randomInt(2, 10)
    const b = randomInt(1, 20)
    const x = randomInt(1, 10)
    const result = a * x + b
    
    questions.push({
      id: `alg-eq1-${Date.now()}-${i}`,
      question: `${a}x + ${b} = ${result} denkleminde x kactir?`,
      options: shuffleArray([x.toString(), (x + 1).toString(), (x - 1).toString(), (x * 2).toString()]),
      correctAnswer: 0,
      explanation: `${a}x + ${b} = ${result} => ${a}x = ${result} - ${b} => ${a}x = ${result - b} => x = ${(result - b) / a}`,
      difficulty: 'orta'
    })
  }
  
  // İki taraflı denklem
  for (let i = 0; i < 5; i++) {
    const a = randomInt(2, 6)
    const b = randomInt(1, 10)
    const c = randomInt(1, a - 1)
    const x = randomInt(2, 8)
    const rightSide = a * x + b - c * x
    
    questions.push({
      id: `alg-eq2-${Date.now()}-${i}`,
      question: `${a}x + ${b} = ${c}x + ${rightSide + c * x - a * x + a * x} denkleminde x kactir?`,
      options: shuffleArray([x.toString(), (x + 2).toString(), (x - 1).toString(), (x + 1).toString()]),
      correctAnswer: 0,
      explanation: `x'li terimleri bir tarafa, sabit terimleri diger tarafa toplayarak cozulur.`,
      difficulty: 'zor'
    })
  }
  
  // Cebirsel ifade sadeleştirme
  for (let i = 0; i < 5; i++) {
    const a = randomInt(2, 8)
    const b = randomInt(1, 6)
    const result = a + b
    
    questions.push({
      id: `alg-simp-${Date.now()}-${i}`,
      question: `${a}x + ${b}x ifadesinin sadelesmis hali nedir?`,
      options: shuffleArray([`${result}x`, `${a * b}x`, `${a}x${b}`, `${result}x²`]),
      correctAnswer: 0,
      explanation: `Benzer terimlerin katsayilari toplanir: ${a}x + ${b}x = (${a} + ${b})x = ${result}x`,
      difficulty: 'kolay'
    })
  }
  
  // Parantez açma
  for (let i = 0; i < 5; i++) {
    const a = randomInt(2, 5)
    const b = randomInt(1, 6)
    const c = randomInt(1, 8)
    
    questions.push({
      id: `alg-dist-${Date.now()}-${i}`,
      question: `${a}(x + ${b}) ifadesinin acilmis hali nedir?`,
      options: shuffleArray([`${a}x + ${a * b}`, `${a}x + ${b}`, `x + ${a * b}`, `${a + b}x`]),
      correctAnswer: 0,
      explanation: `Dagitma ozelligi: ${a}(x + ${b}) = ${a}·x + ${a}·${b} = ${a}x + ${a * b}`,
      difficulty: 'orta'
    })
  }
  
  // Değer bulma
  for (let i = 0; i < 5; i++) {
    const a = randomInt(2, 6)
    const b = randomInt(1, 10)
    const x = randomInt(1, 5)
    const result = a * x + b
    
    questions.push({
      id: `alg-val-${Date.now()}-${i}`,
      question: `x = ${x} icin ${a}x + ${b} ifadesinin degeri kactir?`,
      options: shuffleArray([result.toString(), (a * x - b).toString(), (a + x + b).toString(), ((a + b) * x).toString()]),
      correctAnswer: 0,
      explanation: `x = ${x} yerine yazilir: ${a}·${x} + ${b} = ${a * x} + ${b} = ${result}`,
      difficulty: 'kolay'
    })
  }

  return questions.map(q => ({
    ...q,
    correctAnswer: q.options.indexOf(q.options[0])
  }))
}

// Oran Orantı Soruları
function generateRatioQuestions(): Question[] {
  const questions: Question[] = []
  
  // Basit oran
  for (let i = 0; i < 5; i++) {
    const a = randomInt(2, 10)
    const b = randomInt(2, 10)
    const gcd = (x: number, y: number): number => y === 0 ? x : gcd(y, x % y)
    const g = gcd(a, b)
    
    questions.push({
      id: `ratio-simp-${Date.now()}-${i}`,
      question: `${a} ile ${b}'nin orani en sade haliyle nasil yazilir?`,
      options: shuffleArray([`${a / g}/${b / g}`, `${a}/${b}`, `${b / g}/${a / g}`, `${a + b}/${a}`]),
      correctAnswer: 0,
      explanation: `${a}/${b} oranini sadelestirmek icin OBEB'e boleriz: ${a}÷${g} / ${b}÷${g} = ${a / g}/${b / g}`,
      difficulty: 'kolay'
    })
  }
  
  // Doğru orantı
  for (let i = 0; i < 5; i++) {
    const x1 = randomInt(2, 8)
    const y1 = randomInt(2, 10)
    const x2 = x1 * randomInt(2, 4)
    const y2 = y1 * (x2 / x1)
    
    questions.push({
      id: `ratio-direct-${Date.now()}-${i}`,
      question: `x ile y dogru orantilidir. x=${x1} iken y=${y1} ise, x=${x2} iken y kactir?`,
      options: shuffleArray([y2.toString(), (y1 + x2 - x1).toString(), (y1 * 2).toString(), (y2 + randomInt(1, 5)).toString()]),
      correctAnswer: 0,
      explanation: `Dogru orantida x artarsa y de artar. ${x1}/${y1} = ${x2}/y => y = ${x2}·${y1}/${x1} = ${y2}`,
      difficulty: 'orta'
    })
  }
  
  // Ters orantı
  for (let i = 0; i < 5; i++) {
    const x1 = randomInt(2, 6)
    const y1 = randomInt(4, 12)
    const x2 = x1 * 2
    const y2 = y1 / 2
    
    questions.push({
      id: `ratio-inverse-${Date.now()}-${i}`,
      question: `x ile y ters orantilidir. x=${x1} iken y=${y1} ise, x=${x2} iken y kactir?`,
      options: shuffleArray([y2.toString(), (y1 * 2).toString(), y1.toString(), (y2 + 2).toString()]),
      correctAnswer: 0,
      explanation: `Ters orantida x artarsa y azalir. ${x1}·${y1} = ${x2}·y => y = ${x1 * y1}/${x2} = ${y2}`,
      difficulty: 'zor'
    })
  }
  
  // Yüzde hesaplama
  for (let i = 0; i < 5; i++) {
    const total = randomInt(5, 20) * 10
    const percent = randomInt(1, 9) * 10
    const result = total * percent / 100
    
    questions.push({
      id: `ratio-percent-${Date.now()}-${i}`,
      question: `${total}'in %${percent}'i kactir?`,
      options: shuffleArray([result.toString(), (total - result).toString(), (total / percent).toString(), (result + 10).toString()]),
      correctAnswer: 0,
      explanation: `${total} x ${percent}/100 = ${total} x ${percent / 100} = ${result}`,
      difficulty: 'kolay'
    })
  }
  
  // Yüzde artış/azalış
  for (let i = 0; i < 5; i++) {
    const original = randomInt(5, 20) * 10
    const percent = randomInt(1, 5) * 10
    const increase = original * percent / 100
    const result = original + increase
    
    questions.push({
      id: `ratio-pchange-${Date.now()}-${i}`,
      question: `${original} TL'lik bir urunun fiyati %${percent} artarsa yeni fiyat kac TL olur?`,
      options: shuffleArray([result.toString(), (original - increase).toString(), increase.toString(), (original + percent).toString()]),
      correctAnswer: 0,
      explanation: `Artis miktari: ${original} x ${percent}/100 = ${increase} TL. Yeni fiyat: ${original} + ${increase} = ${result} TL`,
      difficulty: 'orta'
    })
  }

  return questions.map(q => ({
    ...q,
    correctAnswer: q.options.indexOf(q.options[0])
  }))
}

// Geometri Soruları
function generateGeometryQuestions(): Question[] {
  const questions: Question[] = []
  
  // Dörtgen alan
  for (let i = 0; i < 5; i++) {
    const a = randomInt(3, 12)
    const b = randomInt(3, 12)
    const area = a * b
    
    questions.push({
      id: `geo-rect-${Date.now()}-${i}`,
      question: `Bir kenar uzunluklari ${a} cm ve ${b} cm olan dikdortgenin alani kac cm²'dir?`,
      options: shuffleArray([area.toString(), ((a + b) * 2).toString(), (a + b).toString(), (area + randomInt(1, 10)).toString()]),
      correctAnswer: 0,
      explanation: `Dikdortgen alani = uzun kenar x kisa kenar = ${a} x ${b} = ${area} cm²`,
      difficulty: 'kolay'
    })
  }
  
  // Üçgen alan
  for (let i = 0; i < 5; i++) {
    const base = randomInt(4, 14)
    const height = randomInt(3, 10)
    const area = (base * height) / 2
    
    questions.push({
      id: `geo-tri-${Date.now()}-${i}`,
      question: `Tabani ${base} cm, yuksekligi ${height} cm olan ucgenin alani kac cm²'dir?`,
      options: shuffleArray([area.toString(), (base * height).toString(), (base + height).toString(), (area * 2).toString()]),
      correctAnswer: 0,
      explanation: `Ucgen alani = (taban x yukseklik) / 2 = (${base} x ${height}) / 2 = ${area} cm²`,
      difficulty: 'orta'
    })
  }
  
  // Çember çevresi
  for (let i = 0; i < 3; i++) {
    const r = randomInt(2, 10)
    const circumference = 2 * r
    
    questions.push({
      id: `geo-circ-${Date.now()}-${i}`,
      question: `Yaricapi ${r} cm olan cemberin cevresi kac π cm'dir?`,
      options: shuffleArray([`${circumference}π`, `${r}π`, `${r * r}π`, `${circumference + 2}π`]),
      correctAnswer: 0,
      explanation: `Cember cevresi = 2πr = 2 x π x ${r} = ${circumference}π cm`,
      difficulty: 'orta'
    })
  }
  
  // Daire alanı
  for (let i = 0; i < 3; i++) {
    const r = randomInt(2, 8)
    const area = r * r
    
    questions.push({
      id: `geo-circle-${Date.now()}-${i}`,
      question: `Yaricapi ${r} cm olan dairenin alani kac π cm²'dir?`,
      options: shuffleArray([`${area}π`, `${2 * r}π`, `${r}π`, `${area + r}π`]),
      correctAnswer: 0,
      explanation: `Daire alani = πr² = π x ${r}² = ${area}π cm²`,
      difficulty: 'orta'
    })
  }
  
  // Açı hesaplama
  for (let i = 0; i < 5; i++) {
    const angle1 = randomInt(30, 80)
    const angle2 = randomInt(30, 80)
    const angle3 = 180 - angle1 - angle2
    
    questions.push({
      id: `geo-angle-${Date.now()}-${i}`,
      question: `Bir ucgenin iki acisi ${angle1}° ve ${angle2}° ise ucuncu aci kac derecedir?`,
      options: shuffleArray([angle3.toString(), (180 - angle1).toString(), (angle1 + angle2).toString(), (90 - angle1).toString()]),
      correctAnswer: 0,
      explanation: `Ucgenin ic acilari toplami 180°'dir. Ucuncu aci = 180° - ${angle1}° - ${angle2}° = ${angle3}°`,
      difficulty: 'kolay'
    })
  }
  
  // Pisagor teoremi
  for (let i = 0; i < 4; i++) {
    const a = randomInt(3, 8)
    const b = randomInt(3, 8)
    const cSquared = a * a + b * b
    const c = Math.sqrt(cSquared)
    
    if (Number.isInteger(c)) {
      questions.push({
        id: `geo-pyth-${Date.now()}-${i}`,
        question: `Dik ucgende dik kenarlari ${a} cm ve ${b} cm ise hipotenüs kac cm'dir?`,
        options: shuffleArray([c.toString(), (a + b).toString(), Math.sqrt(a * b).toFixed(0), (c + 1).toString()]),
        correctAnswer: 0,
        explanation: `Pisagor teoremi: c² = a² + b² = ${a}² + ${b}² = ${cSquared}, c = √${cSquared} = ${c} cm`,
        difficulty: 'zor'
      })
    }
  }

  return questions.map(q => ({
    ...q,
    correctAnswer: q.options.indexOf(q.options[0])
  }))
}

// Veri Analizi Soruları
function generateDataQuestions(): Question[] {
  const questions: Question[] = []
  
  // Aritmetik ortalama
  for (let i = 0; i < 5; i++) {
    const count = randomInt(3, 5)
    const numbers = Array.from({ length: count }, () => randomInt(5, 20))
    const sum = numbers.reduce((a, b) => a + b, 0)
    const avg = sum / count
    
    if (Number.isInteger(avg)) {
      questions.push({
        id: `data-avg-${Date.now()}-${i}`,
        question: `${numbers.join(', ')} sayilarinin aritmetik ortalamasi kactir?`,
        options: shuffleArray([avg.toString(), (avg + 2).toString(), (avg - 1).toString(), Math.max(...numbers).toString()]),
        correctAnswer: 0,
        explanation: `Aritmetik ortalama = Toplam / Sayi adedi = ${sum} / ${count} = ${avg}`,
        difficulty: 'kolay'
      })
    }
  }
  
  // Medyan (ortanca)
  for (let i = 0; i < 5; i++) {
    const numbers = Array.from({ length: 5 }, () => randomInt(1, 20)).sort((a, b) => a - b)
    const median = numbers[2]
    
    questions.push({
      id: `data-med-${Date.now()}-${i}`,
      question: `${numbers.join(', ')} sayilarinin medyani (ortancasi) kactir?`,
      options: shuffleArray([median.toString(), numbers[0].toString(), numbers[4].toString(), ((numbers[0] + numbers[4]) / 2).toString()]),
      correctAnswer: 0,
      explanation: `Medyan icin sayilar siralanir ve ortadaki deger alinir. Siralama: ${numbers.join(', ')}, medyan = ${median}`,
      difficulty: 'orta'
    })
  }
  
  // Mod (tepe değer)
  for (let i = 0; i < 5; i++) {
    const mode = randomInt(3, 15)
    const numbers = [mode, mode, mode, randomInt(1, 20), randomInt(1, 20)]
    const shuffledNums = shuffleArray(numbers)
    
    questions.push({
      id: `data-mode-${Date.now()}-${i}`,
      question: `${shuffledNums.join(', ')} sayilarinin modu (tepe degeri) kactir?`,
      options: shuffleArray([mode.toString(), Math.min(...numbers).toString(), Math.max(...numbers).toString(), ((mode + 1)).toString()]),
      correctAnswer: 0,
      explanation: `Mod, en cok tekrar eden sayidir. ${mode} sayisi 3 kez tekrar etmistir.`,
      difficulty: 'kolay'
    })
  }
  
  // Açıklık
  for (let i = 0; i < 5; i++) {
    const numbers = Array.from({ length: 5 }, () => randomInt(5, 50))
    const range = Math.max(...numbers) - Math.min(...numbers)
    
    questions.push({
      id: `data-range-${Date.now()}-${i}`,
      question: `${numbers.join(', ')} veri setinin acikligi (degisim araligi) kactir?`,
      options: shuffleArray([range.toString(), Math.max(...numbers).toString(), Math.min(...numbers).toString(), (range + 5).toString()]),
      correctAnswer: 0,
      explanation: `Aciklik = En buyuk deger - En kucuk deger = ${Math.max(...numbers)} - ${Math.min(...numbers)} = ${range}`,
      difficulty: 'kolay'
    })
  }
  
  // Olasılık
  for (let i = 0; i < 5; i++) {
    const total = randomInt(2, 5) * 2
    const favorable = randomInt(1, total / 2)
    
    questions.push({
      id: `data-prob-${Date.now()}-${i}`,
      question: `Bir torbada ${total} top vardir ve ${favorable} tanesi kirmizidir. Rastgele bir top cekildiginde kirmizi gelme olasiligi kactir?`,
      options: shuffleArray([`${favorable}/${total}`, `${total - favorable}/${total}`, `${favorable}/${total - favorable}`, `1/${total}`]),
      correctAnswer: 0,
      explanation: `Olasilik = Istenen sonuc sayisi / Tum sonuc sayisi = ${favorable}/${total}`,
      difficulty: 'orta'
    })
  }

  return questions.map(q => ({
    ...q,
    correctAnswer: q.options.indexOf(q.options[0])
  }))
}

// Ana soru üretici fonksiyon
export function generateQuestions(topicId: string, count: number = 10): Question[] {
  let allQuestions: Question[] = []
  
  switch (topicId) {
    case 'tam-sayilar':
      allQuestions = generateIntegerQuestions()
      break
    case 'rasyonel-sayilar':
      allQuestions = generateRationalQuestions()
      break
    case 'cebirsel-ifadeler':
      allQuestions = generateAlgebraQuestions()
      break
    case 'oran-oranti':
      allQuestions = generateRatioQuestions()
      break
    case 'geometri':
      allQuestions = generateGeometryQuestions()
      break
    case 'veri-analizi':
      allQuestions = generateDataQuestions()
      break
    default:
      allQuestions = generateIntegerQuestions()
  }
  
  // Soruları karıştır ve doğru cevabı güncelle
  return shuffleArray(allQuestions).slice(0, count).map(q => {
    const correctOption = q.options[0]
    const shuffledOptions = shuffleArray([...q.options])
    return {
      ...q,
      options: shuffledOptions,
      correctAnswer: shuffledOptions.indexOf(correctOption)
    }
  })
}
