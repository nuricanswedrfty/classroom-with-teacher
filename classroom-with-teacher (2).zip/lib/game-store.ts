import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// Avatar kıyafetleri
export interface ClothingItem {
  id: string
  name: string
  type: 'head' | 'body' | 'accessory'
  icon: string
  price: number
  forGender: 'all' | 'male' | 'female'
}

// Fidan türleri
export interface PlantType {
  id: string
  name: string
  icon: string
  stages: string[] // Her aşama için farklı emoji
  growthDays: number // Büyümesi için gereken gün
  price: number
}

// Kullanıcı fidanı
export interface UserPlant {
  id: string
  plantTypeId: string
  name: string
  stage: number // 0-4 arası aşama
  waterLevel: number // 0-100
  lastWatered?: string // ISO date
  isDead: boolean
  plantedAt: string // ISO date
  growthProgress: number // 0-100
}

// Market ürünleri
export interface MarketItem {
  id: string
  name: string
  description: string
  icon: string
  price: number
  type: 'hint' | 'plant' | 'booster' | 'clothing'
  itemId?: string // clothing veya plant için referans
  quantity?: number // hint gibi sayılabilir ürünler için
}

// Kullanıcı profili
export interface UserProfile {
  name: string
  gender: 'male' | 'female'
  role: 'student' | 'teacher'
  avatar: {
    skinTone: string
    head?: string
    body?: string
    accessory?: string
  }
  createdAt: string
  isVIP: boolean
  vipActivatedAt?: string
}

interface GameState {
  // Profil
  profile: UserProfile | null
  isProfileSetup: boolean
  hasEnteredLobby: boolean
  
  // Puan sistemi
  coins: number
  totalCoinsEarned: number
  
  // Fidan sistemi
  plants: UserPlant[]
  
  // Market envanteri
  ownedClothing: string[]
  hintCount: number
  growthBoosters: number
  
  // Actions
  setupProfile: (name: string, gender: 'male' | 'female', role: 'student' | 'teacher') => void
  enterLobby: () => void
  addCoins: (amount: number) => void
  spendCoins: (amount: number) => boolean
  activateVIP: (code: string) => boolean
  
  // Fidan actions
  buyPlant: (plantType: PlantType) => boolean
  waterPlant: (plantId: string) => void
  checkPlantHealth: () => void
  removePlant: (plantId: string) => void
  useGrowthBooster: (plantId: string) => boolean
  
  // Market actions
  buyClothing: (item: ClothingItem) => boolean
  buyHints: (count: number, price: number) => boolean
  buyGrowthBooster: (price: number) => boolean
  useHint: () => boolean
  
  // Avatar actions
  equipClothing: (type: 'head' | 'body' | 'accessory', itemId: string | undefined) => void
  
  // Reset
  resetGame: () => void
}

// Fidan türleri
export const plantTypes: PlantType[] = [
  {
    id: 'sunflower',
    name: 'Ayçiçeği',
    icon: '🌻',
    stages: ['🌱', '🌿', '🌾', '🌻', '🌻'],
    growthDays: 5,
    price: 50
  },
  {
    id: 'tulip',
    name: 'Lale',
    icon: '🌷',
    stages: ['🌱', '🌿', '🌸', '🌷', '🌷'],
    growthDays: 4,
    price: 40
  },
  {
    id: 'tree',
    name: 'Ağaç',
    icon: '🌳',
    stages: ['🌱', '🌿', '🌴', '🌲', '🌳'],
    growthDays: 7,
    price: 100
  },
  {
    id: 'rose',
    name: 'Gül',
    icon: '🌹',
    stages: ['🌱', '🌿', '🌸', '🥀', '🌹'],
    growthDays: 6,
    price: 75
  },
  {
    id: 'cactus',
    name: 'Kaktüs',
    icon: '🌵',
    stages: ['🌱', '🌿', '🌵', '🌵', '🌵'],
    growthDays: 3,
    price: 30
  }
]

// Kıyafetler
export const clothingItems: ClothingItem[] = [
  // Şapkalar
  { id: 'cap', name: 'Şapka', type: 'head', icon: '🧢', price: 100, forGender: 'all' },
  { id: 'crown', name: 'Taç', type: 'head', icon: '👑', price: 500, forGender: 'all' },
  { id: 'wizard-hat', name: 'Büyücü Şapkası', type: 'head', icon: '🎩', price: 300, forGender: 'all' },
  { id: 'bow', name: 'Fiyonk', type: 'head', icon: '🎀', price: 150, forGender: 'female' },
  { id: 'headphones', name: 'Kulaklık', type: 'head', icon: '🎧', price: 200, forGender: 'all' },
  
  // Kıyafetler
  { id: 'superhero', name: 'Süper Kahraman', type: 'body', icon: '🦸', price: 400, forGender: 'all' },
  { id: 'princess', name: 'Prenses', type: 'body', icon: '👸', price: 400, forGender: 'female' },
  { id: 'prince', name: 'Prens', type: 'body', icon: '🤴', price: 400, forGender: 'male' },
  { id: 'astronaut', name: 'Astronot', type: 'body', icon: '👨‍🚀', price: 600, forGender: 'all' },
  { id: 'scientist', name: 'Bilim İnsanı', type: 'body', icon: '🥼', price: 350, forGender: 'all' },
  { id: 'ninja', name: 'Ninja', type: 'body', icon: '🥷', price: 450, forGender: 'all' },
  
  // Aksesuarlar
  { id: 'glasses', name: 'Gözlük', type: 'accessory', icon: '👓', price: 100, forGender: 'all' },
  { id: 'sunglasses', name: 'Güneş Gözlüğü', type: 'accessory', icon: '🕶️', price: 150, forGender: 'all' },
  { id: 'medal', name: 'Madalya', type: 'accessory', icon: '🏅', price: 250, forGender: 'all' },
  { id: 'star', name: 'Yıldız', type: 'accessory', icon: '⭐', price: 200, forGender: 'all' },
  { id: 'heart', name: 'Kalp', type: 'accessory', icon: '❤️', price: 175, forGender: 'all' },
]

// Market ürünleri
export const marketItems: MarketItem[] = [
  { id: 'hint-5', name: '5 İpucu', description: 'Testlerde yardım al', icon: '💡', price: 50, type: 'hint', quantity: 5 },
  { id: 'hint-10', name: '10 İpucu', description: 'Testlerde yardım al', icon: '💡', price: 90, type: 'hint', quantity: 10 },
  { id: 'hint-25', name: '25 İpucu', description: 'Testlerde yardım al', icon: '💡', price: 200, type: 'hint', quantity: 25 },
  { id: 'booster-1', name: 'Büyüme Hızlandırıcı', description: 'Fidanı 1 gün hızlandır', icon: '⚡', price: 75, type: 'booster', quantity: 1 },
  { id: 'booster-3', name: '3x Büyüme Hızlandırıcı', description: 'Fidanı 3 gün hızlandır', icon: '⚡', price: 200, type: 'booster', quantity: 3 },
]

const defaultProfile: UserProfile = {
  name: '',
  gender: 'male',
  role: 'student',
  avatar: {
    skinTone: '👦',
  },
  createdAt: new Date().toISOString(),
  isVIP: false
}

// VIP kodu
const VIP_CODE = 'baristazecan'

export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      profile: null,
      isProfileSetup: false,
      hasEnteredLobby: false,
      coins: 0,
      totalCoinsEarned: 0,
      plants: [],
      ownedClothing: [],
      hintCount: 3, // Baslangicta 3 ipucu
      growthBoosters: 0,

      setupProfile: (name: string, gender: 'male' | 'female', role: 'student' | 'teacher') => {
        set({
          profile: {
            name,
            gender,
            role,
            avatar: {
              skinTone: gender === 'male' ? '👦' : '👧',
            },
            createdAt: new Date().toISOString(),
            isVIP: false
          },
          isProfileSetup: true,
          coins: 100, // Baslangic bonusu
          totalCoinsEarned: 100
        })
      },

      enterLobby: () => {
        set({ hasEnteredLobby: true })
      },

      activateVIP: (code: string) => {
        if (code.toLowerCase() === VIP_CODE) {
          set((state) => ({
            profile: state.profile ? {
              ...state.profile,
              isVIP: true,
              vipActivatedAt: new Date().toISOString()
            } : null,
            coins: 999999,
            totalCoinsEarned: 999999,
            hintCount: 9999,
            growthBoosters: 99,
            ownedClothing: clothingItems.map(c => c.id) // Tum kiyafetler acik
          }))
          return true
        }
        return false
      },

      addCoins: (amount: number) => {
        set((state) => ({
          coins: state.coins + amount,
          totalCoinsEarned: state.totalCoinsEarned + amount
        }))
      },

      spendCoins: (amount: number) => {
        const state = get()
        if (state.coins >= amount) {
          set({ coins: state.coins - amount })
          return true
        }
        return false
      },

      buyPlant: (plantType: PlantType) => {
        const state = get()
        if (state.coins >= plantType.price) {
          const newPlant: UserPlant = {
            id: `plant-${Date.now()}`,
            plantTypeId: plantType.id,
            name: plantType.name,
            stage: 0,
            waterLevel: 100,
            lastWatered: new Date().toISOString(),
            isDead: false,
            plantedAt: new Date().toISOString(),
            growthProgress: 0
          }
          set({
            coins: state.coins - plantType.price,
            plants: [...state.plants, newPlant]
          })
          return true
        }
        return false
      },

      waterPlant: (plantId: string) => {
        set((state) => ({
          plants: state.plants.map((plant) =>
            plant.id === plantId
              ? {
                  ...plant,
                  waterLevel: 100,
                  lastWatered: new Date().toISOString(),
                  isDead: false
                }
              : plant
          )
        }))
      },

      checkPlantHealth: () => {
        const now = new Date()
        set((state) => ({
          plants: state.plants.map((plant) => {
            if (plant.isDead) return plant
            
            const lastWatered = plant.lastWatered ? new Date(plant.lastWatered) : new Date(plant.plantedAt)
            const hoursSinceWater = (now.getTime() - lastWatered.getTime()) / (1000 * 60 * 60)
            
            // Her 12 saatte %25 su kaybı
            const waterLoss = Math.floor(hoursSinceWater / 12) * 25
            const newWaterLevel = Math.max(0, 100 - waterLoss)
            
            // 48 saat (2 gün) sulanmazsa ölür
            const isDead = hoursSinceWater >= 48
            
            // Büyüme hesaplama
            const plantType = plantTypes.find(p => p.id === plant.plantTypeId)
            if (!plantType) return plant
            
            const daysSincePlanted = (now.getTime() - new Date(plant.plantedAt).getTime()) / (1000 * 60 * 60 * 24)
            const growthProgress = Math.min(100, (daysSincePlanted / plantType.growthDays) * 100)
            const stage = Math.min(4, Math.floor(growthProgress / 25))
            
            return {
              ...plant,
              waterLevel: newWaterLevel,
              isDead,
              growthProgress,
              stage: isDead ? plant.stage : stage
            }
          })
        }))
      },

      removePlant: (plantId: string) => {
        set((state) => ({
          plants: state.plants.filter((plant) => plant.id !== plantId)
        }))
      },

      useGrowthBooster: (plantId: string) => {
        const state = get()
        if (state.growthBoosters <= 0) return false
        
        set((s) => ({
          growthBoosters: s.growthBoosters - 1,
          plants: s.plants.map((plant) => {
            if (plant.id !== plantId) return plant
            
            const plantType = plantTypes.find(p => p.id === plant.plantTypeId)
            if (!plantType) return plant
            
            const boostAmount = 100 / plantType.growthDays // 1 günlük ilerleme
            const newProgress = Math.min(100, plant.growthProgress + boostAmount)
            const newStage = Math.min(4, Math.floor(newProgress / 25))
            
            return {
              ...plant,
              growthProgress: newProgress,
              stage: newStage
            }
          })
        }))
        return true
      },

      buyClothing: (item: ClothingItem) => {
        const state = get()
        if (state.coins >= item.price && !state.ownedClothing.includes(item.id)) {
          set({
            coins: state.coins - item.price,
            ownedClothing: [...state.ownedClothing, item.id]
          })
          return true
        }
        return false
      },

      buyHints: (count: number, price: number) => {
        const state = get()
        if (state.coins >= price) {
          set({
            coins: state.coins - price,
            hintCount: state.hintCount + count
          })
          return true
        }
        return false
      },

      buyGrowthBooster: (price: number) => {
        const state = get()
        if (state.coins >= price) {
          set({
            coins: state.coins - price,
            growthBoosters: state.growthBoosters + 1
          })
          return true
        }
        return false
      },

      useHint: () => {
        const state = get()
        if (state.hintCount > 0) {
          set({ hintCount: state.hintCount - 1 })
          return true
        }
        return false
      },

      equipClothing: (type: 'head' | 'body' | 'accessory', itemId: string | undefined) => {
        set((state) => {
          if (!state.profile) return state
          return {
            profile: {
              ...state.profile,
              avatar: {
                ...state.profile.avatar,
                [type]: itemId
              }
            }
          }
        })
      },

      resetGame: () => {
        set({
          profile: null,
          isProfileSetup: false,
          hasEnteredLobby: false,
          coins: 0,
          totalCoinsEarned: 0,
          plants: [],
          ownedClothing: [],
          hintCount: 3,
          growthBoosters: 0
        })
      }
    }),
    {
      name: 'math-game-storage'
    }
  )
)
