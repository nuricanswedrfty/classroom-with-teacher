'use client'

import { useState, useEffect, useCallback } from 'react'
import { generateQuestions, type Question } from '@/lib/question-generator'
import { useProgressStore } from '@/lib/progress-store'
import { useGameStore } from '@/lib/game-store'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { BadgeNotification, NotificationManager } from '@/components/badge-notification'
import { Badge } from '@/lib/progress-store'
import { CheckCircle, XCircle, ArrowRight, RotateCcw, Trophy, Lightbulb, Coins } from 'lucide-react'

interface QuizProps {
  topicId: string
  topicName: string
  questionCount?: number
  difficulty?: 'kolay' | 'orta' | 'zor' | 'karisik'
}

export function Quiz({ topicId, topicName, questionCount = 15, difficulty = 'karisik' }: QuizProps) {
  const [questions, setQuestions] = useState<Question[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState(false)
  const [score, setScore] = useState(0)
  const [answers, setAnswers] = useState<boolean[]>([])
  const [quizComplete, setQuizComplete] = useState(false)
  const [newBadges, setNewBadges] = useState<{ name: string; icon: string }[]>([])
  const [showHint, setShowHint] = useState(false)
  const [usedHintOnQuestion, setUsedHintOnQuestion] = useState(false)
  
  const { recordTestResult } = useProgressStore()
  const { hintCount, useHint, coins } = useGameStore()

  const loadQuestions = useCallback(() => {
    let qs = generateQuestions(topicId, questionCount)
    if (difficulty !== 'karisik') {
      qs = qs.filter(q => q.difficulty === difficulty)
      if (qs.length < questionCount) {
        qs = [...qs, ...generateQuestions(topicId, questionCount - qs.length)]
      }
    }
    setQuestions(qs.slice(0, questionCount))
    setCurrentIndex(0)
    setSelectedAnswer(null)
    setShowResult(false)
    setScore(0)
    setAnswers([])
    setQuizComplete(false)
    setNewBadges([])
    setShowHint(false)
    setUsedHintOnQuestion(false)
  }, [topicId, questionCount, difficulty])

  useEffect(() => {
    loadQuestions()
  }, [loadQuestions])

  const currentQuestion = questions[currentIndex]

  const handleSelectAnswer = (index: number) => {
    if (showResult) return
    setSelectedAnswer(index)
  }

  const handleUseHint = () => {
    if (hintCount > 0 && !usedHintOnQuestion && !showResult) {
      if (useHint()) {
        setShowHint(true)
        setUsedHintOnQuestion(true)
      }
    }
  }

  const handleCheckAnswer = () => {
    if (selectedAnswer === null) return
    
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer
    if (isCorrect) {
      setScore(score + 1)
    }
    setAnswers([...answers, isCorrect])
    setShowResult(true)
  }

  const handleNextQuestion = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1)
      setSelectedAnswer(null)
      setShowResult(false)
      setShowHint(false)
      setUsedHintOnQuestion(false)
    } else {
      // Quiz bitti
      const finalScore = score + (selectedAnswer === currentQuestion.correctAnswer ? 1 : 0)
      const unlockedBadges = recordTestResult(topicId, finalScore, questions.length)
      setNewBadges(unlockedBadges)
      setQuizComplete(true)
    }
  }

  if (questions.length === 0) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    )
  }

  if (quizComplete) {
    const finalScore = answers.filter(Boolean).length
    const percentage = Math.round((finalScore / questions.length) * 100)
    const isPerfect = finalScore === questions.length
    const earnedCoins = finalScore * 5 + (isPerfect ? 20 : 0)
    
    return (
      <div className="space-y-6">
        {newBadges.map((badge, i) => (
          <BadgeNotification key={i} badge={badge} />
        ))}
        
        <div className="text-center py-8">
          <div className={cn(
            "inline-flex items-center justify-center w-24 h-24 rounded-full mb-4",
            percentage >= 80 ? "bg-green-100 text-green-600" : 
            percentage >= 50 ? "bg-yellow-100 text-yellow-600" : 
            "bg-red-100 text-red-600"
          )}>
            {isPerfect ? (
              <Trophy className="w-12 h-12" />
            ) : (
              <span className="text-3xl font-bold">%{percentage}</span>
            )}
          </div>
          
          <h2 className="text-2xl font-bold mb-2">
            {isPerfect ? 'Mukemmel!' : percentage >= 80 ? 'Harika!' : percentage >= 50 ? 'Iyi!' : 'Tekrar Dene'}
          </h2>
          <p className="text-muted-foreground mb-2">
            {questions.length} sorudan {finalScore} tanesini dogru cevapladin
          </p>
          
          {/* Kazanılan puan */}
          <div className="inline-flex items-center gap-2 bg-yellow-100 dark:bg-yellow-950 text-yellow-700 dark:text-yellow-300 px-4 py-2 rounded-full mb-6">
            <Coins className="w-5 h-5" />
            <span className="font-bold">+{earnedCoins} puan kazandin!</span>
            {isPerfect && <span className="text-xs">(+20 bonus)</span>}
          </div>

          {/* Sonuç özeti */}
          <div className="flex justify-center gap-2 flex-wrap mb-6">
            {answers.map((correct, i) => (
              <div
                key={i}
                className={cn(
                  "w-8 h-8 rounded-lg flex items-center justify-center text-sm font-medium",
                  correct ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                )}
              >
                {i + 1}
              </div>
            ))}
          </div>

          <div className="flex gap-3 justify-center">
            <Button onClick={loadQuestions} variant="outline" className="gap-2">
              <RotateCcw className="w-4 h-4" />
              Tekrar Coz
            </Button>
            <Button onClick={() => window.history.back()} className="gap-2">
              Konuya Don
            </Button>
          </div>
        </div>
      </div>
    )
  }

  // İpucu: yanlış cevaplardan birini kaldır
  const getHintOptions = () => {
    if (!showHint) return currentQuestion.options
    
    const correctIndex = currentQuestion.correctAnswer
    const wrongIndices = currentQuestion.options
      .map((_, i) => i)
      .filter(i => i !== correctIndex)
    
    // 2 yanlış şıkkı gizle
    const hiddenIndices = wrongIndices.slice(0, 2)
    
    return currentQuestion.options.map((opt, i) => 
      hiddenIndices.includes(i) ? null : opt
    )
  }

  const hintOptions = getHintOptions()

  return (
    <div className="space-y-6">
      {/* Progress */}
      <div className="flex items-center justify-between text-sm">
        <span className="text-muted-foreground">
          Soru {currentIndex + 1} / {questions.length}
        </span>
        <div className="flex items-center gap-4">
          <span className="font-medium text-primary">
            {score} dogru
          </span>
          {/* İpucu butonu */}
          <button
            onClick={handleUseHint}
            disabled={hintCount === 0 || usedHintOnQuestion || showResult}
            className={cn(
              "flex items-center gap-1 px-2 py-1 rounded-full text-xs transition-all",
              hintCount > 0 && !usedHintOnQuestion && !showResult
                ? "bg-yellow-100 text-yellow-700 hover:bg-yellow-200 cursor-pointer"
                : "bg-gray-100 text-gray-400 cursor-not-allowed"
            )}
          >
            <Lightbulb className="w-3 h-3" />
            {hintCount} ipucu
          </button>
        </div>
      </div>
      <div className="h-2 w-full rounded-full bg-accent">
        <div
          className="h-2 rounded-full bg-primary transition-all"
          style={{ width: `${((currentIndex + 1) / questions.length) * 100}%` }}
        />
      </div>

      {/* Question */}
      <div className="rounded-xl border border-border bg-card p-6">
        <div className="flex items-center gap-2 mb-4">
          <span className={cn(
            "px-2 py-0.5 rounded text-xs font-medium",
            currentQuestion.difficulty === 'kolay' && "bg-green-100 text-green-700",
            currentQuestion.difficulty === 'orta' && "bg-yellow-100 text-yellow-700",
            currentQuestion.difficulty === 'zor' && "bg-red-100 text-red-700",
          )}>
            {currentQuestion.difficulty.charAt(0).toUpperCase() + currentQuestion.difficulty.slice(1)}
          </span>
          <span className="text-xs text-muted-foreground">{topicName}</span>
          {showHint && (
            <span className="px-2 py-0.5 rounded text-xs font-medium bg-yellow-100 text-yellow-700">
              Ipucu kullanildi
            </span>
          )}
        </div>
        
        <h3 className="text-lg font-medium mb-6">
          {currentQuestion.question}
        </h3>

        {/* Options */}
        <div className="space-y-3">
          {currentQuestion.options.map((option, index) => {
            const isHidden = showHint && hintOptions[index] === null
            const isSelected = selectedAnswer === index
            const isCorrect = index === currentQuestion.correctAnswer
            const showCorrect = showResult && isCorrect
            const showWrong = showResult && isSelected && !isCorrect

            if (isHidden && !showResult) {
              return (
                <div
                  key={index}
                  className="w-full flex items-center gap-3 rounded-lg border p-4 border-dashed border-gray-300 bg-gray-50 dark:bg-gray-900 opacity-50"
                >
                  <span className="flex h-8 w-8 items-center justify-center rounded-full border border-dashed text-sm font-medium shrink-0 text-gray-400">
                    {String.fromCharCode(65 + index)}
                  </span>
                  <span className="text-gray-400 italic">Elendi</span>
                </div>
              )
            }

            return (
              <button
                key={index}
                onClick={() => handleSelectAnswer(index)}
                disabled={showResult || isHidden}
                className={cn(
                  "w-full flex items-center gap-3 rounded-lg border p-4 text-left transition-all",
                  !showResult && isSelected && "border-primary bg-primary/5",
                  !showResult && !isSelected && "border-border hover:border-primary/50 hover:bg-accent",
                  showCorrect && "border-green-500 bg-green-50 dark:bg-green-950",
                  showWrong && "border-red-500 bg-red-50 dark:bg-red-950",
                )}
              >
                <span className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full border text-sm font-medium shrink-0",
                  !showResult && isSelected && "border-primary bg-primary text-primary-foreground",
                  !showResult && !isSelected && "border-border",
                  showCorrect && "border-green-500 bg-green-500 text-white",
                  showWrong && "border-red-500 bg-red-500 text-white",
                )}>
                  {showCorrect ? <CheckCircle className="w-4 h-4" /> :
                   showWrong ? <XCircle className="w-4 h-4" /> :
                   String.fromCharCode(65 + index)}
                </span>
                <span className={cn(
                  showCorrect && "text-green-700 dark:text-green-300 font-medium",
                  showWrong && "text-red-700 dark:text-red-300",
                )}>
                  {option}
                </span>
              </button>
            )
          })}
        </div>

        {/* Explanation */}
        {showResult && (
          <div className={cn(
            "mt-4 p-4 rounded-lg",
            selectedAnswer === currentQuestion.correctAnswer 
              ? "bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800"
              : "bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800"
          )}>
            <p className="text-sm font-medium mb-1">
              {selectedAnswer === currentQuestion.correctAnswer ? 'Dogru! +5 puan' : 'Aciklama:'}
            </p>
            <p className="text-sm text-muted-foreground">
              {currentQuestion.explanation}
            </p>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3">
        {!showResult ? (
          <Button 
            onClick={handleCheckAnswer} 
            disabled={selectedAnswer === null}
            className="gap-2"
          >
            Kontrol Et
          </Button>
        ) : (
          <Button onClick={handleNextQuestion} className="gap-2">
            {currentIndex < questions.length - 1 ? (
              <>
                Sonraki Soru
                <ArrowRight className="w-4 h-4" />
              </>
            ) : (
              <>
                Sonuclari Gor
                <Trophy className="w-4 h-4" />
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  )
}
