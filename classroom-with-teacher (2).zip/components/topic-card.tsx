'use client'

import Link from 'next/link'
import { cn } from '@/lib/utils'
import { useProgressStore } from '@/lib/progress-store'
import type { Topic } from '@/lib/math-data'
import { CheckCircle, ChevronRight } from 'lucide-react'

interface TopicCardProps {
  topic: Topic
}

export function TopicCard({ topic }: TopicCardProps) {
  const { getTopicProgress } = useProgressStore()
  const progress = getTopicProgress(topic.id)
  const completedLessons = progress.lessonsCompleted.length
  const totalLessons = topic.lessons?.length || 0
  const progressPercent = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0

  const colorClass = {
    blue: { bg: 'bg-blue-100 dark:bg-blue-950', bar: 'bg-blue-500' },
    green: { bg: 'bg-green-100 dark:bg-green-950', bar: 'bg-green-500' },
    purple: { bg: 'bg-purple-100 dark:bg-purple-950', bar: 'bg-purple-500' },
    orange: { bg: 'bg-orange-100 dark:bg-orange-950', bar: 'bg-orange-500' },
    pink: { bg: 'bg-pink-100 dark:bg-pink-950', bar: 'bg-pink-500' },
    cyan: { bg: 'bg-cyan-100 dark:bg-cyan-950', bar: 'bg-cyan-500' },
  }[topic.color] || { bg: 'bg-gray-100 dark:bg-gray-950', bar: 'bg-gray-500' }

  return (
    <Link
      href={`/konular/${topic.id}`}
      className="group relative overflow-hidden rounded-xl border border-border bg-card p-6 transition-all hover:border-primary/50 hover:shadow-lg"
    >
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <div className={cn("flex h-14 w-14 items-center justify-center rounded-xl text-2xl", colorClass.bg)}>
            {topic.icon}
          </div>
          <div>
            <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">
              {topic.name}
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              {topic.description}
            </p>
          </div>
        </div>
        <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
      </div>

      {/* Progress bar */}
      <div className="mt-4">
        <div className="flex items-center justify-between text-sm mb-2">
          <span className="text-muted-foreground">
            {completedLessons} / {totalLessons} ders tamamlandi
          </span>
          <span className="font-medium text-primary">{progressPercent}%</span>
        </div>
        <div className="h-2 w-full rounded-full bg-accent">
          <div
            className={cn("h-2 rounded-full transition-all", colorClass.bar)}
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Stats */}
      <div className="mt-4 flex items-center gap-4 text-sm">
        <div className="flex items-center gap-1.5 text-muted-foreground">
          <span>🎯</span>
          <span>{progress.testsCompleted} test</span>
        </div>
        {progress.bestScore > 0 && (
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <span>⭐</span>
            <span>En iyi: %{progress.bestScore}</span>
          </div>
        )}
        {progressPercent === 100 && (
          <div className="flex items-center gap-1.5 text-green-600">
            <CheckCircle className="h-4 w-4" />
            <span>Tamamlandi</span>
          </div>
        )}
      </div>
    </Link>
  )
}
