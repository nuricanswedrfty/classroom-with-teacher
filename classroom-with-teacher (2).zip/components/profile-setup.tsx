'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useGameStore } from '@/lib/game-store'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { GraduationCap, Users } from 'lucide-react'

export function ProfileSetup({ onComplete }: { onComplete: () => void }) {
  const [name, setName] = useState('')
  const [gender, setGender] = useState<'male' | 'female'>('male')
  const [role, setRole] = useState<'student' | 'teacher'>('student')
  const { setupProfile } = useGameStore()
  const router = useRouter()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (name.trim()) {
      setupProfile(name.trim(), gender, role)
      onComplete()
      
      // Role gore yonlendirme
      if (role === 'teacher') {
        router.push('/ogretmen')
      } else {
        router.push('/ogrenci')
      }
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/20 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <div className="text-6xl mb-4">
            {gender === 'male' ? '👦' : '👧'}
          </div>
          <CardTitle className="text-2xl">Merhaba!</CardTitle>
          <CardDescription>
            Matematik maceraina baslamadan once seni taniyalim
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="name">Adin ne?</Label>
              <Input
                id="name"
                placeholder="Adini yaz..."
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="text-lg"
                required
              />
            </div>

            {/* Cinsiyet Secimi */}
            <div className="space-y-2">
              <Label>Cinsiyetini sec</Label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setGender('male')}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    gender === 'male'
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-950'
                      : 'border-border hover:border-blue-300'
                  }`}
                >
                  <div className="text-4xl mb-2">👦</div>
                  <div className="font-medium">Erkek</div>
                </button>
                <button
                  type="button"
                  onClick={() => setGender('female')}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    gender === 'female'
                      ? 'border-pink-500 bg-pink-50 dark:bg-pink-950'
                      : 'border-border hover:border-pink-300'
                  }`}
                >
                  <div className="text-4xl mb-2">👧</div>
                  <div className="font-medium">Kiz</div>
                </button>
              </div>
            </div>

            {/* Rol Secimi */}
            <div className="space-y-2">
              <Label>Sen kimsin?</Label>
              <div className="grid grid-cols-2 gap-4">
                <button
                  type="button"
                  onClick={() => setRole('student')}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    role === 'student'
                      ? 'border-green-500 bg-green-50 dark:bg-green-950'
                      : 'border-border hover:border-green-300'
                  }`}
                >
                  <div className="flex justify-center mb-2">
                    <Users className="w-10 h-10 text-green-600" />
                  </div>
                  <div className="font-medium">Ogrenci</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Sinifa katil ve sinav coz
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => setRole('teacher')}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    role === 'teacher'
                      ? 'border-purple-500 bg-purple-50 dark:bg-purple-950'
                      : 'border-border hover:border-purple-300'
                  }`}
                >
                  <div className="flex justify-center mb-2">
                    <GraduationCap className="w-10 h-10 text-purple-600" />
                  </div>
                  <div className="font-medium">Ogretmen</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Sinif olustur ve sinav yap
                  </div>
                </button>
              </div>
            </div>

            <Button type="submit" className="w-full h-12 text-lg" disabled={!name.trim()}>
              {role === 'teacher' ? 'Ogretmen Paneline Git' : 'Ogrenci Paneline Git'}
            </Button>

            <p className="text-center text-sm text-muted-foreground">
              {role === 'student' ? 'Baslarken 100 altin puan hediye!' : 'Sinifini olustur ve ogrencilerini davet et!'}
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
