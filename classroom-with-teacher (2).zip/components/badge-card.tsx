'use client'

import { useProgressStore } from '@/lib/progress-store'
import { cn } from '@/lib/utils'

export function BadgeCard({ 
  badge, 
  showProgress = true 
}: { 
  badge: { 
    id: string
    name: string
    description: string
    icon: string
    requirement: number
    type: string
    unlocked: boolean
  }
  showProgress?: boolean 
}) {
  const { totalTestsCompleted, totalCorrectAnswers, currentStreak, perfectScores, topicProgress } = useProgressStore()
  
  let current = 0
  switch (badge.type) {
    case 'tests':
      current = totalTestsCompleted
      break
    case 'score':
      current = totalCorrectAnswers
      break
    case 'streak':
      current = currentStreak
      break
    case 'perfect':
      current = perfectScores
      break
    case 'topic':
      const tp = topicProgress[(badge as { topicId?: string }).topicId || '']
      current = tp?.testsCompleted || 0
      break
  }
  
  const progress = Math.min(100, Math.round((current / badge.requirement) * 100))

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl border p-4 transition-all",
        badge.unlocked
          ? "border-primary/50 bg-primary/5"
          : "border-border bg-card opacity-75"
      )}
    >
      <div className="flex items-start gap-3">
        <div
          className={cn(
            "flex h-12 w-12 items-center justify-center rounded-lg text-2xl",
            badge.unlocked ? "bg-primary/10" : "bg-muted grayscale"
          )}
        >
          {badge.icon}
        </div>
        <div className="flex-1">
          <h4 className={cn("font-semibold", !badge.unlocked && "text-muted-foreground")}>
            {badge.name}
          </h4>
          <p className="text-sm text-muted-foreground mt-0.5">
            {badge.description}
          </p>
          
          {showProgress && !badge.unlocked && (
            <div className="mt-2">
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-muted-foreground">
                  {current} / {badge.requirement}
                </span>
                <span className="text-muted-foreground">{progress}%</span>
              </div>
              <div className="h-1.5 w-full rounded-full bg-muted">
                <div
                  className="h-1.5 rounded-full bg-primary/50 transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </div>
      
      {badge.unlocked && (
        <div className="absolute top-2 right-2">
          <span className="text-green-500 text-lg">✓</span>
        </div>
      )}
    </div>
  )
}

export function BadgeNotification({ badge }: { badge: { name: string; icon: string } }) {
  return (
    <div className="fixed top-20 right-4 z-50 animate-in slide-in-from-right duration-300">
      <div className="flex items-center gap-3 rounded-lg border border-primary/50 bg-primary/10 px-4 py-3 shadow-lg">
        <div className="text-2xl">{badge.icon}</div>
        <div>
          <p className="text-sm font-medium text-primary">Yeni Rozet Kazandin!</p>
          <p className="text-sm font-semibold">{badge.name}</p>
        </div>
      </div>
    </div>
  )
}
