'use client'

import { useEffect, useState } from 'react'
import { Badge } from '@/lib/progress-store'
import { X } from 'lucide-react'

interface BadgeNotificationProps {
  badge: Badge
  onClose: () => void
}

export function BadgeNotification({ badge, onClose }: BadgeNotificationProps) {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Animasyon icin
    setTimeout(() => setIsVisible(true), 100)
    
    // 5 saniye sonra otomatik kapat
    const timer = setTimeout(() => {
      setIsVisible(false)
      setTimeout(onClose, 300)
    }, 5000)

    return () => clearTimeout(timer)
  }, [onClose])

  return (
    <div
      className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 transition-all duration-300 ${
        isVisible ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'
      }`}
    >
      <div className="bg-gradient-to-r from-yellow-400 via-amber-400 to-orange-400 rounded-2xl p-1 shadow-2xl animate-pulse">
        <div className="bg-white rounded-xl p-4 flex items-center gap-4">
          <div className="text-5xl animate-bounce">{badge.icon}</div>
          <div>
            <div className="text-sm text-amber-600 font-medium">Yeni Rozet!</div>
            <div className="text-xl font-bold text-gray-900">{badge.name}</div>
            <div className="text-sm text-gray-600">{badge.description}</div>
          </div>
          <button
            onClick={() => {
              setIsVisible(false)
              setTimeout(onClose, 300)
            }}
            className="ml-2 p-1 hover:bg-gray-100 rounded-full"
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>
      </div>
    </div>
  )
}

interface NotificationManagerProps {
  newBadges: Badge[]
  onClear: () => void
}

export function NotificationManager({ newBadges, onClear }: NotificationManagerProps) {
  const [currentBadge, setCurrentBadge] = useState<Badge | null>(null)
  const [queue, setQueue] = useState<Badge[]>([])

  useEffect(() => {
    if (newBadges.length > 0) {
      setQueue(prev => [...prev, ...newBadges])
      onClear()
    }
  }, [newBadges, onClear])

  useEffect(() => {
    if (!currentBadge && queue.length > 0) {
      setCurrentBadge(queue[0])
      setQueue(prev => prev.slice(1))
    }
  }, [currentBadge, queue])

  if (!currentBadge) return null

  return (
    <BadgeNotification
      badge={currentBadge}
      onClose={() => setCurrentBadge(null)}
    />
  )
}
