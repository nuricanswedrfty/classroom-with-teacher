'use client'

import { useEffect } from 'react'
import { useGameStore, plantTypes } from '@/lib/game-store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Droplet, Zap, Trash2, AlertTriangle } from 'lucide-react'
import { cn } from '@/lib/utils'

export function PlantGarden() {
  const { plants, waterPlant, checkPlantHealth, removePlant, useGrowthBooster, growthBoosters } = useGameStore()

  // Fidan sağlığını kontrol et
  useEffect(() => {
    checkPlantHealth()
    const interval = setInterval(checkPlantHealth, 60000) // Her dakika kontrol
    return () => clearInterval(interval)
  }, [checkPlantHealth])

  if (plants.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-8 text-center">
          <div className="text-4xl mb-3">🌱</div>
          <p className="text-muted-foreground">
            Henuz fidanin yok!
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            Marketten fidan satin alabilirsin
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Bahcem</h3>
        {growthBoosters > 0 && (
          <div className="flex items-center gap-1 text-sm bg-yellow-100 dark:bg-yellow-950 text-yellow-700 dark:text-yellow-300 px-2 py-1 rounded-full">
            <Zap className="w-3 h-3" />
            {growthBoosters} hizlandirici
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {plants.map((plant) => {
          const plantType = plantTypes.find(p => p.id === plant.plantTypeId)
          if (!plantType) return null

          const currentEmoji = plant.isDead ? '🥀' : plantType.stages[plant.stage]
          const isLowWater = plant.waterLevel < 30 && !plant.isDead

          return (
            <Card 
              key={plant.id} 
              className={cn(
                "relative overflow-hidden",
                plant.isDead && "opacity-75 bg-red-50 dark:bg-red-950",
                isLowWater && !plant.isDead && "border-orange-300"
              )}
            >
              {plant.isDead && (
                <div className="absolute top-2 right-2 flex items-center gap-1 bg-red-500 text-white px-2 py-0.5 rounded text-xs">
                  <AlertTriangle className="w-3 h-3" />
                  Kurudu!
                </div>
              )}
              
              {isLowWater && (
                <div className="absolute top-2 right-2 flex items-center gap-1 bg-orange-500 text-white px-2 py-0.5 rounded text-xs animate-pulse">
                  <Droplet className="w-3 h-3" />
                  Susadi!
                </div>
              )}

              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <span className="text-2xl">{currentEmoji}</span>
                    {plant.name}
                  </CardTitle>
                </div>
              </CardHeader>

              <CardContent className="space-y-3">
                {/* Su seviyesi */}
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1">
                      <Droplet className="w-3 h-3 text-blue-500" />
                      Su
                    </span>
                    <span>%{plant.waterLevel}</span>
                  </div>
                  <Progress 
                    value={plant.waterLevel} 
                    className={cn(
                      "h-2",
                      plant.waterLevel < 30 && "bg-orange-100 [&>div]:bg-orange-500"
                    )}
                  />
                </div>

                {/* Büyüme */}
                {!plant.isDead && (
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span>Buyume</span>
                      <span>%{Math.round(plant.growthProgress)}</span>
                    </div>
                    <Progress value={plant.growthProgress} className="h-2" />
                    <div className="flex justify-between mt-1">
                      {plantType.stages.map((stage, i) => (
                        <span 
                          key={i} 
                          className={cn(
                            "text-xs",
                            i <= plant.stage ? "opacity-100" : "opacity-30"
                          )}
                        >
                          {stage}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Aksiyonlar */}
                <div className="flex gap-2 pt-2">
                  {!plant.isDead && (
                    <>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1 gap-1"
                        onClick={() => waterPlant(plant.id)}
                        disabled={plant.waterLevel >= 100}
                      >
                        <Droplet className="w-3 h-3" />
                        Sula
                      </Button>
                      {growthBoosters > 0 && plant.growthProgress < 100 && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="gap-1"
                          onClick={() => useGrowthBooster(plant.id)}
                        >
                          <Zap className="w-3 h-3" />
                        </Button>
                      )}
                    </>
                  )}
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    className="text-red-500 hover:text-red-600 hover:bg-red-50"
                    onClick={() => removePlant(plant.id)}
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
