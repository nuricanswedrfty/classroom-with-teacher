'use client'

import { cn } from '@/lib/utils'
import { useProgressStore } from '@/lib/progress-store'
import type { Lesson } from '@/lib/math-data'
import { CheckCircle, ChevronRight, BookOpen, Clock } from 'lucide-react'
import Link from 'next/link'

interface LessonCardProps {
  lesson: Lesson
  topicId: string
  index: number
}

export function LessonCard({ lesson, topicId, index }: LessonCardProps) {
  const { getTopicProgress } = useProgressStore()
  const progress = getTopicProgress(topicId)
  const isCompleted = progress.lessonsCompleted.includes(lesson.id)

  return (
    <Link
      href={`/konular/${topicId}/ders/${lesson.id}`}
      className={cn(
        "group flex items-center gap-4 rounded-xl border p-4 transition-all hover:shadow-md",
        isCompleted 
          ? "border-green-200 bg-green-50/50 dark:border-green-800 dark:bg-green-950/30" 
          : "border-border bg-card hover:border-primary/50"
      )}
    >
      <div className={cn(
        "flex h-10 w-10 items-center justify-center rounded-lg text-sm font-bold shrink-0",
        isCompleted 
          ? "bg-green-500 text-white" 
          : "bg-accent text-muted-foreground group-hover:bg-primary group-hover:text-primary-foreground"
      )}>
        {isCompleted ? <CheckCircle className="w-5 h-5" /> : index + 1}
      </div>
      
      <div className="flex-1 min-w-0">
        <h4 className={cn(
          "font-medium truncate",
          isCompleted && "text-green-700 dark:text-green-300"
        )}>
          {lesson.title}
        </h4>
        <div className="flex items-center gap-3 mt-1 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <BookOpen className="w-3 h-3" />
            {lesson.content.split(' ').length > 100 ? 'Detayli' : 'Kisa'} ders
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            ~5 dk
          </span>
        </div>
      </div>
      
      <ChevronRight className={cn(
        "w-5 h-5 shrink-0 transition-transform group-hover:translate-x-1",
        isCompleted ? "text-green-500" : "text-muted-foreground"
      )} />
    </Link>
  )
}
