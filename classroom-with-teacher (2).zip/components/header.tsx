'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { useProgressStore } from '@/lib/progress-store'
import { useGameStore, clothingItems } from '@/lib/game-store'
import { 
  BookOpen, 
  Trophy, 
  Home, 
  Calculator,
  Menu,
  X,
  FileText,
  ShoppingBag,
  Package,
  Coins,
  Key,
  Sparkles,
  GraduationCap,
  Users
} from 'lucide-react'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'

const baseNavItems = [
  { href: '/lobi', label: 'Lobi', icon: Home, roles: ['student', 'teacher'] },
  { href: '/konular', label: 'Konular', icon: BookOpen, roles: ['student', 'teacher'] },
  { href: '/sinav-olustur', label: 'Sinav Olustur', icon: FileText, roles: ['student', 'teacher'] },
  { href: '/ogretmen', label: 'Ogretmen Paneli', icon: GraduationCap, roles: ['teacher'] },
  { href: '/ogrenci', label: 'Ogrenci Paneli', icon: Users, roles: ['student'] },
  { href: '/market', label: 'Market', icon: ShoppingBag, roles: ['student', 'teacher'] },
  { href: '/envanter', label: 'Envanter', icon: Package, roles: ['student', 'teacher'] },
  { href: '/rozetler', label: 'Rozetler', icon: Trophy, roles: ['student', 'teacher'] },
]

export function Header() {
  const pathname = usePathname()
  const { currentStreak } = useProgressStore()
  const { profile, coins, activateVIP } = useGameStore()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [vipCode, setVipCode] = useState('')
  const [vipDialogOpen, setVipDialogOpen] = useState(false)
  const [vipError, setVipError] = useState(false)
  const [vipSuccess, setVipSuccess] = useState(false)

  // Role gore nav items filtrele
  const navItems = baseNavItems.filter(item => 
    !profile?.role || item.roles.includes(profile.role)
  )

  // Avatar emoji
  const getAvatarDisplay = () => {
    if (!profile) return '👤'
    
    const equippedHead = clothingItems.find(i => i.id === profile.avatar.head)
    if (equippedHead) return equippedHead.icon
    
    return profile.avatar.skinTone
  }

  const handleVIPActivation = () => {
    const success = activateVIP(vipCode)
    if (success) {
      setVipSuccess(true)
      setVipError(false)
      setTimeout(() => {
        setVipDialogOpen(false)
        setVipSuccess(false)
        setVipCode('')
      }, 2000)
    } else {
      setVipError(true)
      setVipSuccess(false)
    }
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        <Link href="/lobi" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Calculator className="h-5 w-5" />
          </div>
          <span className="hidden font-bold text-lg sm:inline-block">
            7. Sinif Matematik
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-4">
          {navItems.map((item) => {
            const Icon = item.icon
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'flex items-center gap-1.5 text-sm font-medium transition-colors hover:text-primary px-2 py-1 rounded-md',
                  pathname === item.href
                    ? 'text-primary bg-primary/10'
                    : 'text-muted-foreground'
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            )
          })}
        </nav>

        {/* Stats */}
        <div className="hidden sm:flex items-center gap-3">
          {/* VIP Badge */}
          {profile?.isVIP && (
            <div className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-gradient-to-r from-yellow-400 to-amber-500 text-white font-bold text-sm animate-pulse">
              <Sparkles className="w-4 h-4" />
              VIP
            </div>
          )}
          
          {/* Puan */}
          <div className="flex items-center gap-1.5 rounded-full bg-yellow-100 dark:bg-yellow-950 text-yellow-700 dark:text-yellow-300 px-3 py-1.5">
            <Coins className="w-4 h-4" />
            <span className="text-sm font-bold">{profile?.isVIP ? '999999' : coins}</span>
          </div>
          
          {/* Streak */}
          <div className="flex items-center gap-1.5 rounded-full bg-orange-100 dark:bg-orange-950 text-orange-600 px-3 py-1.5">
            <span>🔥</span>
            <span className="text-sm font-medium">{currentStreak}</span>
          </div>

          {/* VIP Code Button */}
          <Dialog open={vipDialogOpen} onOpenChange={setVipDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" className="gap-1">
                <Key className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Key className="w-5 h-5" />
                  Ozel Kod Gir
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Ozel kodunuz varsa asagiya girin ve VIP ayricaliklarina kavusun!
                </p>
                <Input
                  placeholder="Ozel kodu girin..."
                  value={vipCode}
                  onChange={(e) => {
                    setVipCode(e.target.value)
                    setVipError(false)
                  }}
                  onKeyDown={(e) => e.key === 'Enter' && handleVIPActivation()}
                />
                {vipError && (
                  <p className="text-sm text-red-500">Gecersiz kod! Tekrar deneyin.</p>
                )}
                {vipSuccess && (
                  <div className="text-center py-4">
                    <div className="text-4xl mb-2">🎉</div>
                    <p className="text-lg font-bold text-green-600">VIP Aktif Edildi!</p>
                    <p className="text-sm text-muted-foreground">Sinirsiz erisimin kutlu olsun!</p>
                  </div>
                )}
                {!vipSuccess && (
                  <Button onClick={handleVIPActivation} className="w-full">
                    Kodu Onayla
                  </Button>
                )}
              </div>
            </DialogContent>
          </Dialog>
          
          {/* Avatar */}
          {profile && (
            <Link href="/envanter" className="flex items-center gap-2">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center text-lg",
                profile.isVIP 
                  ? "bg-gradient-to-r from-yellow-400 to-amber-500 ring-2 ring-yellow-300" 
                  : "bg-accent"
              )}>
                {getAvatarDisplay()}
              </div>
              {profile.isVIP && (
                <span className="font-bold bg-gradient-to-r from-yellow-500 via-amber-500 to-orange-500 bg-clip-text text-transparent">
                  {profile.name}
                </span>
              )}
            </Link>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button
          className="lg:hidden p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-border/40 bg-background">
          <nav className="container flex flex-col gap-2 p-4">
            {/* Mobile VIP Badge */}
            {profile?.isVIP && (
              <div className="flex items-center gap-2 pb-3 border-b mb-2">
                <span className="px-3 py-1 bg-gradient-to-r from-yellow-400 to-amber-500 text-white text-sm font-bold rounded-full animate-pulse">
                  VIP
                </span>
                <span className="font-bold bg-gradient-to-r from-yellow-500 via-amber-500 to-orange-500 bg-clip-text text-transparent">
                  {profile.name}
                </span>
              </div>
            )}
            
            {/* Mobile Stats */}
            <div className="flex items-center gap-3 pb-3 border-b mb-2">
              <div className="flex items-center gap-1.5 bg-yellow-100 dark:bg-yellow-950 text-yellow-700 dark:text-yellow-300 px-3 py-1.5 rounded-full">
                <Coins className="w-4 h-4" />
                <span className="text-sm font-bold">{profile?.isVIP ? '999999' : coins} puan</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span>🔥</span>
                <span className="text-sm">{currentStreak} gun seri</span>
              </div>
            </div>
            
            {navItems.map((item) => {
              const Icon = item.icon
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={cn(
                    'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                    pathname === item.href
                      ? 'bg-primary text-primary-foreground'
                      : 'hover:bg-accent'
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </Link>
              )
            })}

            {/* Mobile VIP Code */}
            <div className="mt-2 pt-2 border-t">
              <Dialog open={vipDialogOpen} onOpenChange={setVipDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" className="w-full gap-2">
                    <Key className="w-4 h-4" />
                    Ozel Kod Gir
                  </Button>
                </DialogTrigger>
              </Dialog>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
