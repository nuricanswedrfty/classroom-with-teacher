'use client'

import { useState } from 'react'
import { Header } from '@/components/header'
import { useGameStore, clothingItems, plantTypes, marketItems } from '@/lib/game-store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Coins, ShoppingBag, Shirt, Leaf, Lightbulb, Zap, Check } from 'lucide-react'
import { cn } from '@/lib/utils'

export default function MarketPage() {
  const { 
    coins, 
    ownedClothing, 
    profile,
    buyClothing, 
    buyPlant, 
    buyHints, 
    buyGrowthBooster,
    hintCount,
    growthBoosters
  } = useGameStore()
  
  const [purchaseMessage, setPurchaseMessage] = useState<string | null>(null)

  const showMessage = (msg: string) => {
    setPurchaseMessage(msg)
    setTimeout(() => setPurchaseMessage(null), 2000)
  }

  const handleBuyClothing = (item: typeof clothingItems[0]) => {
    if (ownedClothing.includes(item.id)) {
      showMessage('Bu kiyafet sende zaten var!')
      return
    }
    if (buyClothing(item)) {
      showMessage(`${item.name} satin alindi!`)
    } else {
      showMessage('Yeterli puan yok!')
    }
  }

  const handleBuyPlant = (plant: typeof plantTypes[0]) => {
    if (buyPlant(plant)) {
      showMessage(`${plant.name} fidani satin alindi!`)
    } else {
      showMessage('Yeterli puan yok!')
    }
  }

  const handleBuyMarketItem = (item: typeof marketItems[0]) => {
    if (item.type === 'hint' && item.quantity) {
      if (buyHints(item.quantity, item.price)) {
        showMessage(`${item.quantity} ipucu satin alindi!`)
      } else {
        showMessage('Yeterli puan yok!')
      }
    } else if (item.type === 'booster') {
      if (buyGrowthBooster(item.price)) {
        showMessage('Buyume hizlandirici satin alindi!')
      } else {
        showMessage('Yeterli puan yok!')
      }
    }
  }

  // Cinsiyete göre kıyafetleri filtrele
  const filteredClothing = clothingItems.filter(
    item => item.forGender === 'all' || item.forGender === profile?.gender
  )

  const headItems = filteredClothing.filter(i => i.type === 'head')
  const bodyItems = filteredClothing.filter(i => i.type === 'body')
  const accessoryItems = filteredClothing.filter(i => i.type === 'accessory')

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-3">
                <ShoppingBag className="w-8 h-8 text-primary" />
                Market
              </h1>
              <p className="text-muted-foreground">Puanlarini harca, oduller kazan!</p>
            </div>
            <div className="flex items-center gap-2 bg-yellow-100 dark:bg-yellow-950 text-yellow-700 dark:text-yellow-300 px-4 py-2 rounded-full">
              <Coins className="w-5 h-5" />
              <span className="font-bold text-lg">{coins}</span>
            </div>
          </div>

          {/* Purchase Message */}
          {purchaseMessage && (
            <div className="fixed top-20 left-1/2 transform -translate-x-1/2 bg-primary text-primary-foreground px-6 py-3 rounded-full shadow-lg z-50 animate-bounce">
              {purchaseMessage}
            </div>
          )}

          {/* İstatistikler */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            <Card>
              <CardContent className="py-4 text-center">
                <div className="text-2xl mb-1">💡</div>
                <div className="text-2xl font-bold">{hintCount}</div>
                <div className="text-xs text-muted-foreground">Ipucu Hakki</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="py-4 text-center">
                <div className="text-2xl mb-1">⚡</div>
                <div className="text-2xl font-bold">{growthBoosters}</div>
                <div className="text-xs text-muted-foreground">Hizlandirici</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="py-4 text-center">
                <div className="text-2xl mb-1">👕</div>
                <div className="text-2xl font-bold">{ownedClothing.length}</div>
                <div className="text-xs text-muted-foreground">Kiyafet</div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="items" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="items" className="gap-2">
                <Lightbulb className="w-4 h-4" />
                Urunler
              </TabsTrigger>
              <TabsTrigger value="plants" className="gap-2">
                <Leaf className="w-4 h-4" />
                Fidanlar
              </TabsTrigger>
              <TabsTrigger value="clothing" className="gap-2">
                <Shirt className="w-4 h-4" />
                Kiyafetler
              </TabsTrigger>
            </TabsList>

            {/* Ürünler */}
            <TabsContent value="items">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {marketItems.map((item) => (
                  <Card key={item.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="text-4xl text-center mb-2">{item.icon}</div>
                      <CardTitle className="text-center text-lg">{item.name}</CardTitle>
                      <CardDescription className="text-center">{item.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Button 
                        className="w-full gap-2" 
                        onClick={() => handleBuyMarketItem(item)}
                        disabled={coins < item.price}
                      >
                        <Coins className="w-4 h-4" />
                        {item.price} Puan
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Fidanlar */}
            <TabsContent value="plants">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {plantTypes.map((plant) => (
                  <Card key={plant.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="text-5xl text-center mb-2">{plant.icon}</div>
                      <CardTitle className="text-center text-lg">{plant.name}</CardTitle>
                      <CardDescription className="text-center">
                        {plant.growthDays} gunde buyur
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="flex justify-center gap-1">
                        {plant.stages.map((stage, i) => (
                          <span key={i} className="text-lg">{stage}</span>
                        ))}
                      </div>
                      <Button 
                        className="w-full gap-2" 
                        onClick={() => handleBuyPlant(plant)}
                        disabled={coins < plant.price}
                      >
                        <Coins className="w-4 h-4" />
                        {plant.price} Puan
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Kıyafetler */}
            <TabsContent value="clothing" className="space-y-6">
              {/* Şapkalar */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  🧢 Sapkalar
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                  {headItems.map((item) => {
                    const owned = ownedClothing.includes(item.id)
                    return (
                      <Card 
                        key={item.id} 
                        className={cn(
                          "hover:shadow-md transition-shadow",
                          owned && "border-green-500 bg-green-50 dark:bg-green-950"
                        )}
                      >
                        <CardContent className="py-4 text-center">
                          <div className="text-4xl mb-2">{item.icon}</div>
                          <div className="font-medium text-sm mb-2">{item.name}</div>
                          {owned ? (
                            <Badge variant="secondary" className="gap-1">
                              <Check className="w-3 h-3" />
                              Sahipsin
                            </Badge>
                          ) : (
                            <Button 
                              size="sm" 
                              className="gap-1"
                              onClick={() => handleBuyClothing(item)}
                              disabled={coins < item.price}
                            >
                              <Coins className="w-3 h-3" />
                              {item.price}
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </div>

              {/* Kıyafetler */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  👕 Kiyafetler
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                  {bodyItems.map((item) => {
                    const owned = ownedClothing.includes(item.id)
                    return (
                      <Card 
                        key={item.id} 
                        className={cn(
                          "hover:shadow-md transition-shadow",
                          owned && "border-green-500 bg-green-50 dark:bg-green-950"
                        )}
                      >
                        <CardContent className="py-4 text-center">
                          <div className="text-4xl mb-2">{item.icon}</div>
                          <div className="font-medium text-sm mb-2">{item.name}</div>
                          {owned ? (
                            <Badge variant="secondary" className="gap-1">
                              <Check className="w-3 h-3" />
                              Sahipsin
                            </Badge>
                          ) : (
                            <Button 
                              size="sm" 
                              className="gap-1"
                              onClick={() => handleBuyClothing(item)}
                              disabled={coins < item.price}
                            >
                              <Coins className="w-3 h-3" />
                              {item.price}
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </div>

              {/* Aksesuarlar */}
              <div>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  ✨ Aksesuarlar
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                  {accessoryItems.map((item) => {
                    const owned = ownedClothing.includes(item.id)
                    return (
                      <Card 
                        key={item.id} 
                        className={cn(
                          "hover:shadow-md transition-shadow",
                          owned && "border-green-500 bg-green-50 dark:bg-green-950"
                        )}
                      >
                        <CardContent className="py-4 text-center">
                          <div className="text-4xl mb-2">{item.icon}</div>
                          <div className="font-medium text-sm mb-2">{item.name}</div>
                          {owned ? (
                            <Badge variant="secondary" className="gap-1">
                              <Check className="w-3 h-3" />
                              Sahipsin
                            </Badge>
                          ) : (
                            <Button 
                              size="sm" 
                              className="gap-1"
                              onClick={() => handleBuyClothing(item)}
                              disabled={coins < item.price}
                            >
                              <Coins className="w-3 h-3" />
                              {item.price}
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
