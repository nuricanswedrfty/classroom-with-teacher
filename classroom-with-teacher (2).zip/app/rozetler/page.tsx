'use client'

import { Header } from '@/components/header'
import { BadgeCard } from '@/components/badge-card'
import { useProgressStore } from '@/lib/progress-store'
import { Trophy, Target, Zap, Calendar, Star } from 'lucide-react'

export default function BadgesPage() {
  const { 
    badges, 
    totalTestsCompleted, 
    totalCorrectAnswers, 
    totalQuestionsAnswered,
    currentStreak,
    longestStreak,
    perfectScores
  } = useProgressStore()

  const unlockedBadges = badges.filter(b => b.unlocked)
  const lockedBadges = badges.filter(b => !b.unlocked)
  const accuracy = totalQuestionsAnswered > 0 
    ? Math.round((totalCorrectAnswers / totalQuestionsAnswered) * 100) 
    : 0

  // Group badges by type
  const testBadges = badges.filter(b => b.type === 'tests')
  const scoreBadges = badges.filter(b => b.type === 'score')
  const streakBadges = badges.filter(b => b.type === 'streak')
  const perfectBadges = badges.filter(b => b.type === 'perfect')
  const topicBadges = badges.filter(b => b.type === 'topic')

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Rozetler ve Basarilar</h1>
          <p className="text-muted-foreground">
            Test cozerek ve dersler tamamlayarak rozetler kazan
          </p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <div className="rounded-xl border border-border bg-card p-4 text-center">
            <Trophy className="w-6 h-6 mx-auto mb-2 text-yellow-500" />
            <div className="text-2xl font-bold">{unlockedBadges.length}</div>
            <div className="text-xs text-muted-foreground">Kazanilan Rozet</div>
          </div>
          <div className="rounded-xl border border-border bg-card p-4 text-center">
            <Target className="w-6 h-6 mx-auto mb-2 text-blue-500" />
            <div className="text-2xl font-bold">{totalTestsCompleted}</div>
            <div className="text-xs text-muted-foreground">Toplam Test</div>
          </div>
          <div className="rounded-xl border border-border bg-card p-4 text-center">
            <Zap className="w-6 h-6 mx-auto mb-2 text-green-500" />
            <div className="text-2xl font-bold">%{accuracy}</div>
            <div className="text-xs text-muted-foreground">Basari Orani</div>
          </div>
          <div className="rounded-xl border border-border bg-card p-4 text-center">
            <Calendar className="w-6 h-6 mx-auto mb-2 text-orange-500" />
            <div className="text-2xl font-bold">{longestStreak}</div>
            <div className="text-xs text-muted-foreground">En Uzun Seri</div>
          </div>
          <div className="rounded-xl border border-border bg-card p-4 text-center">
            <Star className="w-6 h-6 mx-auto mb-2 text-purple-500" />
            <div className="text-2xl font-bold">{perfectScores}</div>
            <div className="text-xs text-muted-foreground">Tam Puan</div>
          </div>
        </div>

        {/* Progress Summary */}
        <div className="rounded-xl border border-primary/20 bg-primary/5 p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Rozet Ilerlemeniz</h2>
            <span className="text-sm text-muted-foreground">
              {unlockedBadges.length} / {badges.length} rozet
            </span>
          </div>
          <div className="h-3 w-full rounded-full bg-background">
            <div
              className="h-3 rounded-full bg-primary transition-all"
              style={{ width: `${(unlockedBadges.length / badges.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Unlocked Badges */}
        {unlockedBadges.length > 0 && (
          <section className="mb-10">
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span className="text-yellow-500">🏆</span>
              Kazanilan Rozetler ({unlockedBadges.length})
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {unlockedBadges.map((badge) => (
                <BadgeCard key={badge.id} badge={badge} showProgress={false} />
              ))}
            </div>
          </section>
        )}

        {/* Badge Categories */}
        <div className="space-y-10">
          {/* Test Badges */}
          <section>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span>📝</span>
              Test Rozetleri
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {testBadges.map((badge) => (
                <BadgeCard key={badge.id} badge={badge} />
              ))}
            </div>
          </section>

          {/* Score Badges */}
          <section>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span>🎯</span>
              Dogru Cevap Rozetleri
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {scoreBadges.map((badge) => (
                <BadgeCard key={badge.id} badge={badge} />
              ))}
            </div>
          </section>

          {/* Streak Badges */}
          <section>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span>🔥</span>
              Seri Rozetleri
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {streakBadges.map((badge) => (
                <BadgeCard key={badge.id} badge={badge} />
              ))}
            </div>
          </section>

          {/* Perfect Score Badges */}
          <section>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span>💎</span>
              Mukemmellik Rozetleri
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {perfectBadges.map((badge) => (
                <BadgeCard key={badge.id} badge={badge} />
              ))}
            </div>
          </section>

          {/* Topic Badges */}
          <section>
            <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
              <span>📚</span>
              Konu Rozetleri
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {topicBadges.map((badge) => (
                <BadgeCard key={badge.id} badge={badge} />
              ))}
            </div>
          </section>
        </div>

        {/* Encouragement */}
        {lockedBadges.length > 0 && (
          <div className="mt-10 text-center p-6 rounded-xl border border-border bg-card">
            <p className="text-muted-foreground">
              Daha fazla test cozerek ve dersler tamamlayarak{' '}
              <span className="font-semibold text-foreground">{lockedBadges.length}</span>{' '}
              rozet daha kazanabilirsin!
            </p>
          </div>
        )}
      </main>
    </div>
  )
}
