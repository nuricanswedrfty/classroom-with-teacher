'use client'

import { Header } from '@/components/header'
import { TopicCard } from '@/components/topic-card'
import { ProfileSetup } from '@/components/profile-setup'
import { PlantGarden } from '@/components/plant-garden'
import { useProgressStore } from '@/lib/progress-store'
import { useGameStore } from '@/lib/game-store'
import { topics } from '@/lib/math-data'
import Link from 'next/link'
import { ArrowRight, BookOpen, Trophy, Target, Zap, Coins, Package, Leaf } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useEffect, useState } from 'react'

export default function HomePage() {
  const { 
    totalTestsCompleted, 
    totalCorrectAnswers, 
    totalQuestionsAnswered,
    currentStreak,
    badges,
    getOverallProgress 
  } = useProgressStore()
  
  const { profile, isProfileSetup, coins, plants, checkPlantHealth } = useGameStore()
  const [showSetup, setShowSetup] = useState(false)
  
  const overallProgress = getOverallProgress()
  const unlockedBadges = badges.filter(b => b.unlocked).length
  const accuracy = totalQuestionsAnswered > 0 
    ? Math.round((totalCorrectAnswers / totalQuestionsAnswered) * 100) 
    : 0

  // Fidan sağlığını kontrol et
  useEffect(() => {
    if (isProfileSetup) {
      checkPlantHealth()
    }
  }, [isProfileSetup, checkPlantHealth])

  // Profil kurulumu gerekiyorsa
  useEffect(() => {
    if (!isProfileSetup) {
      setShowSetup(true)
    }
  }, [isProfileSetup])

  if (showSetup && !isProfileSetup) {
    return <ProfileSetup onComplete={() => setShowSetup(false)} />
  }

  // Susayan veya ölen fidan var mı kontrol et
  const dyingPlants = plants.filter(p => p.waterLevel < 30 && !p.isDead)
  const deadPlants = plants.filter(p => p.isDead)

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8">
        {/* Hero Section */}
        <section className="mb-8">
          <div className="rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-background border border-primary/20 p-6 md:p-8">
            <div className="max-w-2xl">
              <div className="flex items-center gap-3 mb-3">
                {profile && (
                  <span className="text-4xl">{profile.avatar.skinTone}</span>
                )}
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold">
                    Merhaba{profile ? `, ${profile.name}` : ''}!
                  </h1>
                  <p className="text-muted-foreground">
                    Bugün matematik öğrenmeye hazır mısın?
                  </p>
                </div>
              </div>
              <div className="flex flex-wrap gap-3 mt-4">
                <Link href="/konular">
                  <Button size="lg" className="gap-2">
                    <BookOpen className="w-4 h-4" />
                    Konulara Basla
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link href="/envanter">
                  <Button size="lg" variant="outline" className="gap-2">
                    <Package className="w-4 h-4" />
                    Envanter
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Fidan Uyarısı */}
        {(dyingPlants.length > 0 || deadPlants.length > 0) && (
          <section className="mb-6">
            <Card className="border-orange-300 bg-orange-50 dark:bg-orange-950">
              <CardContent className="py-4">
                <div className="flex items-center gap-3">
                  <span className="text-3xl">🌱</span>
                  <div className="flex-1">
                    {dyingPlants.length > 0 && (
                      <p className="text-orange-700 dark:text-orange-300">
                        {dyingPlants.length} fidanin susamis! Sulamayi unutma!
                      </p>
                    )}
                    {deadPlants.length > 0 && (
                      <p className="text-red-600 dark:text-red-400">
                        {deadPlants.length} fidanin kurumus! Yeni fidan almak icin markete git.
                      </p>
                    )}
                  </div>
                  <Link href="/envanter">
                    <Button size="sm" variant="outline">Bahceye Git</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* Stats Cards */}
        <section className="mb-8">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <Card className="bg-yellow-50 dark:bg-yellow-950 border-yellow-200">
              <CardContent className="py-4">
                <div className="flex items-center gap-2 mb-1">
                  <Coins className="w-5 h-5 text-yellow-600" />
                  <span className="text-2xl font-bold text-yellow-700 dark:text-yellow-300">{coins}</span>
                </div>
                <p className="text-xs text-yellow-600 dark:text-yellow-400">Altin Puan</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="py-4">
                <div className="flex items-center gap-2 mb-1">
                  <Target className="w-5 h-5 text-blue-600" />
                  <span className="text-2xl font-bold">{totalTestsCompleted}</span>
                </div>
                <p className="text-xs text-muted-foreground">Test</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="py-4">
                <div className="flex items-center gap-2 mb-1">
                  <Zap className="w-5 h-5 text-green-600" />
                  <span className="text-2xl font-bold">%{accuracy}</span>
                </div>
                <p className="text-xs text-muted-foreground">Basari</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="py-4">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xl">🔥</span>
                  <span className="text-2xl font-bold">{currentStreak}</span>
                </div>
                <p className="text-xs text-muted-foreground">Gun Seri</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="py-4">
                <div className="flex items-center gap-2 mb-1">
                  <Trophy className="w-5 h-5 text-purple-600" />
                  <span className="text-2xl font-bold">{unlockedBadges}</span>
                </div>
                <p className="text-xs text-muted-foreground">Rozet</p>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Overall Progress */}
        <section className="mb-8">
          <Card>
            <CardContent className="py-4">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-semibold">Genel Ilerleme</h2>
                <span className="text-xl font-bold text-primary">%{overallProgress.percentage}</span>
              </div>
              <div className="h-3 w-full rounded-full bg-accent">
                <div
                  className="h-3 rounded-full bg-primary transition-all"
                  style={{ width: `${overallProgress.percentage}%` }}
                />
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                {overallProgress.completed} / {overallProgress.total} ders tamamlandi
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Fidan Bahçesi Mini */}
        {plants.length > 0 && (
          <section className="mb-8">
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Leaf className="w-5 h-5 text-green-600" />
                    Fidan Bahcem
                  </CardTitle>
                  <Link href="/envanter">
                    <Button variant="ghost" size="sm">Tum Bahce</Button>
                  </Link>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4 overflow-x-auto pb-2">
                  {plants.slice(0, 4).map(plant => {
                    const plantType = useGameStore.getState().plants.find(p => p.id === plant.id)
                    return (
                      <div key={plant.id} className="text-center flex-shrink-0">
                        <div className={`text-3xl ${plant.isDead ? 'grayscale' : ''}`}>
                          {plant.isDead ? '🥀' : plant.stage >= 4 ? '🌻' : '🌱'}
                        </div>
                        <div className="text-xs text-muted-foreground mt-1">{plant.name}</div>
                        <div className={`text-xs ${plant.waterLevel < 30 ? 'text-orange-500' : 'text-blue-500'}`}>
                          💧 {plant.waterLevel}%
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* Topics */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">Konular</h2>
            <Link href="/konular" className="text-sm text-primary hover:underline flex items-center gap-1">
              Tumunu Gor
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {topics.map((topic) => (
              <TopicCard key={topic.id} topic={topic} />
            ))}
          </div>
        </section>

        {/* Puan Kazanma Bilgisi */}
        <section className="mt-8">
          <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-950 dark:to-orange-950">
            <CardContent className="py-6">
              <div className="flex items-start gap-4">
                <div className="text-4xl">💰</div>
                <div>
                  <h3 className="font-bold text-lg mb-2">Puan Nasil Kazanilir?</h3>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Her dogru cevap: <span className="text-yellow-600 font-medium">5 puan</span></li>
                    <li>• Tam puan bonusu: <span className="text-yellow-600 font-medium">+20 puan</span></li>
                    <li>• Gunluk test coz: <span className="text-yellow-600 font-medium">Fidan sulama</span></li>
                  </ul>
                  <Link href="/market" className="inline-block mt-3">
                    <Button size="sm" variant="outline" className="gap-2">
                      <ShoppingBag className="w-4 h-4" />
                      Markete Git
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
    </div>
  )
}

function ShoppingBag(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z" />
      <path d="M3 6h18" />
      <path d="M16 10a4 4 0 0 1-8 0" />
    </svg>
  )
}
