'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { useGameStore } from '@/lib/game-store'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { BookOpen, FileText, ShoppingBag, Trophy, Sparkles, GraduationCap, Users, Package } from 'lucide-react'
import Link from 'next/link'

export default function LobiPage() {
  const router = useRouter()
  const { profile, isProfileSetup, hasEnteredLobby, enterLobby } = useGameStore()
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    setIsLoading(false)
  }, [])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500">
        <div className="text-white text-2xl animate-pulse">Yukleniyor...</div>
      </div>
    )
  }

  // Profil kurulmamissa profil kurulumuna yonlendir
  if (!isProfileSetup) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex flex-col items-center justify-center p-4">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 drop-shadow-lg">
            Matematik Dunyasi
          </h1>
          <p className="text-xl text-white/90">Eglenceli ogrenme yolculuguna basla!</p>
        </div>
        
        <Card className="w-full max-w-md bg-white/95 backdrop-blur">
          <CardContent className="p-6">
            <h2 className="text-2xl font-bold text-center mb-6">Hosgeldin!</h2>
            <p className="text-center text-muted-foreground mb-6">
              Matematik ogrenmeye baslamak icin profilini olustur
            </p>
            <Link href="/" className="block">
              <Button className="w-full text-lg py-6 gap-2">
                <Sparkles className="w-5 h-5" />
                Hadi Baslayalim!
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  const studentMenuItems = [
    {
      title: 'Ana Sayfa',
      description: 'Istatistikler ve genel bakis',
      icon: <Trophy className="w-8 h-8" />,
      href: '/',
      color: 'from-yellow-400 to-orange-500'
    },
    {
      title: 'Konular',
      description: 'Matematik konularini ogren',
      icon: <BookOpen className="w-8 h-8" />,
      href: '/konular',
      color: 'from-blue-400 to-indigo-500'
    },
    {
      title: 'Sinav Olustur',
      description: 'Kendi sinavini hazirla',
      icon: <FileText className="w-8 h-8" />,
      href: '/sinav-olustur',
      color: 'from-green-400 to-emerald-500'
    },
    {
      title: 'Envanter',
      description: 'Esyalarin ve fidanlar',
      icon: <Package className="w-8 h-8" />,
      href: '/envanter',
      color: 'from-purple-400 to-pink-500'
    },
    {
      title: 'Market',
      description: 'Puan ile alisveris yap',
      icon: <ShoppingBag className="w-8 h-8" />,
      href: '/market',
      color: 'from-red-400 to-rose-500'
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-4">
      {/* Header */}
      <div className="text-center py-8">
        <div className="flex items-center justify-center gap-3 mb-2">
          <span className="text-5xl">{profile?.avatar.skinTone}</span>
          <div>
            <h1 className="text-3xl md:text-4xl font-bold text-white drop-shadow-lg">
              Merhaba, {profile?.isVIP && (
                <span className="bg-gradient-to-r from-yellow-300 via-yellow-100 to-yellow-300 bg-clip-text text-transparent animate-pulse">
                  {profile.name}
                </span>
              )}
              {!profile?.isVIP && profile?.name}!
            </h1>
            {profile?.isVIP && (
              <div className="flex items-center justify-center gap-2 mt-1">
                <span className="px-3 py-1 bg-gradient-to-r from-yellow-400 to-amber-500 text-white text-sm font-bold rounded-full shadow-lg animate-pulse">
                  VIP
                </span>
                <span className="text-yellow-200 text-sm">Sinirsiz Erisim</span>
              </div>
            )}
          </div>
        </div>
        <p className="text-white/80 text-lg">Ne yapmak istersin?</p>
      </div>

      {/* Sinif Sistemi - Role gore */}
      <div className="max-w-4xl mx-auto mb-6">
        <div className="bg-white/10 backdrop-blur rounded-xl p-4 mb-4">
          <h2 className="text-white font-bold text-lg mb-3 flex items-center gap-2">
            <GraduationCap className="w-5 h-5" />
            {profile?.role === 'teacher' ? 'Ogretmen Paneli' : 'Ogrenci Paneli'}
          </h2>
          <div className="grid grid-cols-1 gap-4">
            {profile?.role === 'teacher' ? (
              <Link href="/ogretmen">
                <Card className="group cursor-pointer hover:scale-105 transition-all duration-300 overflow-hidden h-full">
                  <CardContent className="p-0">
                    <div className="bg-gradient-to-br from-teal-400 to-cyan-500 p-6 text-white">
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-white/20 rounded-xl group-hover:scale-110 transition-transform">
                          <GraduationCap className="w-8 h-8" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold">Ogretmen Paneli</h3>
                          <p className="text-white/80 text-sm">Sinif olustur, ogrencileri yonet, sinav hazirla</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ) : (
              <Link href="/ogrenci">
                <Card className="group cursor-pointer hover:scale-105 transition-all duration-300 overflow-hidden h-full">
                  <CardContent className="p-0">
                    <div className="bg-gradient-to-br from-amber-400 to-orange-500 p-6 text-white">
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-white/20 rounded-xl group-hover:scale-110 transition-transform">
                          <Users className="w-8 h-8" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold">Ogrenci Paneli</h3>
                          <p className="text-white/80 text-sm">Sinifa katil, sinav coz, puan kazan</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            )}
          </div>
        </div>
      </div>

      {/* Ana Menu */}
      <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {studentMenuItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <Card className="group cursor-pointer hover:scale-105 transition-all duration-300 overflow-hidden h-full">
              <CardContent className="p-0">
                <div className={`bg-gradient-to-br ${item.color} p-6 text-white`}>
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-white/20 rounded-xl group-hover:scale-110 transition-transform">
                      {item.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold">{item.title}</h3>
                      <p className="text-white/80 text-sm">{item.description}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Fun Stats */}
      <div className="max-w-4xl mx-auto mt-8">
        <Card className="bg-white/10 backdrop-blur border-white/20">
          <CardContent className="p-6">
            <div className="flex flex-wrap justify-center gap-8 text-white text-center">
              <div>
                <div className="text-3xl font-bold">8</div>
                <div className="text-white/70 text-sm">Konu</div>
              </div>
              <div>
                <div className="text-3xl font-bold">100+</div>
                <div className="text-white/70 text-sm">Soru</div>
              </div>
              <div>
                <div className="text-3xl font-bold">20+</div>
                <div className="text-white/70 text-sm">Rozet</div>
              </div>
              <div>
                <div className="text-3xl font-bold">15+</div>
                <div className="text-white/70 text-sm">Kiyafet</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <div className="text-center py-8 text-white/60 text-sm">
        Matematik Dunyasi - Eglenerek Ogren
      </div>
    </div>
  )
}
