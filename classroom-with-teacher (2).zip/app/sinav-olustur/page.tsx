'use client'

import { useState, useRef } from 'react'
import { Header } from '@/components/header'
import { topics } from '@/lib/math-data'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Checkbox } from '@/components/ui/checkbox'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { FileText, Printer, Download, CheckCircle2 } from 'lucide-react'

interface ExamQuestion {
  id: number
  question: string
  options?: string[]
  correctAnswer?: string
  topic: string
  isOpenEnded: boolean
}

// Soru ureteci - daha fazla soru icin genisletilmis
function generateExamQuestions(
  selectedTopics: string[],
  questionCount: number,
  questionType: 'test' | 'open' | 'mixed'
): ExamQuestion[] {
  const questions: ExamQuestion[] = []
  let id = 1

  const questionBank: Record<string, { test: any[], open: any[] }> = {
    'tam-sayilar': {
      test: [
        { q: '(-15) + (+8) işleminin sonucu kaçtır?', opts: ['-7', '-23', '7', '23'], ans: '-7' },
        { q: '(-4) × (-6) işleminin sonucu kaçtır?', opts: ['24', '-24', '10', '-10'], ans: '24' },
        { q: '|−12| + |5| işleminin sonucu kaçtır?', opts: ['17', '7', '-7', '-17'], ans: '17' },
        { q: '(-20) ÷ (+5) işleminin sonucu kaçtır?', opts: ['-4', '4', '-25', '25'], ans: '-4' },
        { q: '(+9) - (-3) işleminin sonucu kaçtır?', opts: ['12', '6', '-6', '-12'], ans: '12' },
        { q: '(-7) + (-8) - (+5) işleminin sonucu kaçtır?', opts: ['-20', '-10', '20', '10'], ans: '-20' },
        { q: '3 × (-4) + 2 işleminin sonucu kaçtır?', opts: ['-10', '-14', '14', '10'], ans: '-10' },
        { q: '(-2)³ işleminin sonucu kaçtır?', opts: ['-8', '8', '-6', '6'], ans: '-8' },
        { q: '(-36) ÷ (-6) işleminin sonucu kaçtır?', opts: ['6', '-6', '30', '-30'], ans: '6' },
        { q: '|-25| - |15| işleminin sonucu kaçtır?', opts: ['10', '-10', '40', '-40'], ans: '10' },
        { q: '(-5) × (+3) × (-2) işleminin sonucu kaçtır?', opts: ['30', '-30', '25', '-25'], ans: '30' },
        { q: '(+18) + (-25) işleminin sonucu kaçtır?', opts: ['-7', '7', '43', '-43'], ans: '-7' },
        { q: '(-8) - (-15) işleminin sonucu kaçtır?', opts: ['7', '-7', '23', '-23'], ans: '7' },
        { q: '2 × |−6| işleminin sonucu kaçtır?', opts: ['12', '-12', '8', '-8'], ans: '12' },
        { q: '(-100) ÷ (+25) işleminin sonucu kaçtır?', opts: ['-4', '4', '-75', '75'], ans: '-4' },
      ],
      open: [
        { q: 'Sayı doğrusunda -5 ile +3 arasındaki tam sayıları yazınız.' },
        { q: '(-8) + (+12) - (-5) işlemini yapınız ve sonucu bulunuz.' },
        { q: 'Mutlak değer kavramını açıklayıp bir örnek veriniz.' },
        { q: '(-3)² ve -3² ifadelerinin sonuçlarını bulup farkını açıklayınız.' },
        { q: 'Tam sayılarda çarpma işleminin işaret kurallarını yazınız.' },
        { q: '|a - 5| = 3 denklemini çözünüz.' },
        { q: 'Bir asansör 5. kattan 12 kat aşağı inerse kaçıncı katta olur? Açıklayınız.' },
        { q: '(-4) × (-2) × (-3) işlemini yapıp işaret kuralını açıklayınız.' },
      ]
    },
    'rasyonel-sayilar': {
      test: [
        { q: '2/3 + 1/4 işleminin sonucu kaçtır?', opts: ['11/12', '3/7', '5/7', '8/12'], ans: '11/12' },
        { q: '5/6 - 1/3 işleminin sonucu kaçtır?', opts: ['1/2', '4/6', '2/3', '4/3'], ans: '1/2' },
        { q: '3/4 × 2/5 işleminin sonucu kaçtır?', opts: ['3/10', '6/9', '5/9', '6/20'], ans: '3/10' },
        { q: '2/3 ÷ 4/5 işleminin sonucu kaçtır?', opts: ['5/6', '8/15', '10/12', '6/5'], ans: '5/6' },
        { q: '0.75 kesir olarak nasıl yazılır?', opts: ['3/4', '7/5', '75/10', '4/3'], ans: '3/4' },
        { q: '12/18 kesrinin sadeleştirilmiş hali nedir?', opts: ['2/3', '3/4', '4/6', '6/9'], ans: '2/3' },
        { q: '1/2 + 2/3 + 1/6 işleminin sonucu kaçtır?', opts: ['4/3', '3/4', '7/6', '5/6'], ans: '4/3' },
        { q: '5/8 ondalık sayı olarak kaçtır?', opts: ['0.625', '0.58', '0.85', '0.525'], ans: '0.625' },
        { q: '2 1/4 kesri bileşik kesir olarak kaçtır?', opts: ['9/4', '8/4', '7/4', '6/4'], ans: '9/4' },
        { q: '15/20 kesrinin en sade hali nedir?', opts: ['3/4', '5/6', '4/5', '2/3'], ans: '3/4' },
        { q: '3/5 × 10/9 işleminin sonucu kaçtır?', opts: ['2/3', '3/2', '30/45', '5/6'], ans: '2/3' },
        { q: '7/8 - 3/8 işleminin sonucu kaçtır?', opts: ['1/2', '4/8', '4/16', '2/4'], ans: '1/2' },
        { q: '0.4 kesir olarak nasıl yazılır?', opts: ['2/5', '4/5', '1/4', '4/10'], ans: '2/5' },
      ],
      open: [
        { q: '3/4 + 2/5 - 1/2 işlemini yapınız.' },
        { q: 'Bir pizzanın 3/8\'i yendi. Kalan kısmı kesir olarak yazınız.' },
        { q: '18/24 kesrini sadeleştiriniz ve adımları gösteriniz.' },
        { q: 'Devirli ondalık sayı nedir? Örnek vererek açıklayınız.' },
        { q: '2/3 ÷ 5/6 işlemini yapıp sonucu bulunuz.' },
        { q: 'EBOB ve EKOK kavramlarını kesir işlemlerinde nasıl kullanırız?' },
        { q: '0.125 sayısını kesir olarak yazınız.' },
      ]
    },
    'cebirsel-ifadeler': {
      test: [
        { q: '3x + 5x işleminin sonucu nedir?', opts: ['8x', '15x', '8x²', '15x²'], ans: '8x' },
        { q: '2(x + 4) ifadesinin açılımı nedir?', opts: ['2x + 8', '2x + 4', 'x + 8', '4x + 8'], ans: '2x + 8' },
        { q: 'x + 5 = 12 denkleminde x kaçtır?', opts: ['7', '17', '5', '12'], ans: '7' },
        { q: '3x - 4 = 11 denkleminde x kaçtır?', opts: ['5', '7', '15', '3'], ans: '5' },
        { q: '4a + 3b - 2a + b işleminin sonucu nedir?', opts: ['2a + 4b', '6a + 4b', '2a + 2b', '6a + 2b'], ans: '2a + 4b' },
        { q: '2x × 3x işleminin sonucu nedir?', opts: ['6x²', '5x²', '6x', '5x'], ans: '6x²' },
        { q: '(5x + 3) - (2x - 1) işleminin sonucu nedir?', opts: ['3x + 4', '3x + 2', '7x + 4', '7x + 2'], ans: '3x + 4' },
        { q: '2x + 3 = x + 7 denkleminde x kaçtır?', opts: ['4', '10', '5', '2'], ans: '4' },
        { q: 'x(x + 3) ifadesinin açılımı nedir?', opts: ['x² + 3x', 'x² + 3', '2x + 3', 'x + 3x'], ans: 'x² + 3x' },
        { q: '12x ÷ 4 işleminin sonucu nedir?', opts: ['3x', '8x', '48x', '3'], ans: '3x' },
        { q: '5(2a - 3) ifadesinin açılımı nedir?', opts: ['10a - 15', '10a - 3', '7a - 8', '10a + 15'], ans: '10a - 15' },
        { q: '4x - 8 = 0 denkleminde x kaçtır?', opts: ['2', '-2', '4', '8'], ans: '2' },
      ],
      open: [
        { q: '3(2x + 4) - 2(x - 1) ifadesini sadeleştiriniz.' },
        { q: '5x + 3 = 2x + 15 denklemini çözünüz.' },
        { q: 'Bir sayının 3 katının 5 fazlası 23\'tür. Bu sayıyı bulunuz.' },
        { q: 'Cebirsel ifade nedir? Terimleri ve katsayıları açıklayınız.' },
        { q: '(4x² + 3x) ÷ x işlemini yapınız.' },
        { q: 'Ardışık iki tek sayının toplamı 32 ise bu sayıları bulunuz.' },
      ]
    },
    'oran-oranti': {
      test: [
        { q: '12 nin 18 e oranı kaçtır?', opts: ['2/3', '3/2', '6/9', '9/6'], ans: '2/3' },
        { q: 'x/4 = 6/8 orantısında x kaçtır?', opts: ['3', '12', '2', '6'], ans: '3' },
        { q: '3 işçi bir işi 12 günde yaparsa, 6 işçi kaç günde yapar?', opts: ['6', '24', '4', '18'], ans: '6' },
        { q: '5 kg elma 40 TL ise 8 kg elma kaç TL dir?', opts: ['64', '50', '72', '56'], ans: '64' },
        { q: 'A:B = 2:3 ve A = 10 ise B kaçtır?', opts: ['15', '6', '20', '12'], ans: '15' },
        { q: 'Bir araç 3 saatte 180 km yol giderse, 5 saatte kaç km yol gider?', opts: ['300', '270', '360', '240'], ans: '300' },
        { q: '2/5 = x/20 orantısında x kaçtır?', opts: ['8', '10', '4', '6'], ans: '8' },
        { q: '6 musluk bir havuzu 4 saatte doldurur. 8 musluk kaç saatte doldurur?', opts: ['3', '5', '6', '2'], ans: '3' },
        { q: 'A:B:C = 2:3:5 ve toplamları 40 ise C kaçtır?', opts: ['20', '16', '12', '8'], ans: '20' },
        { q: '15/x = 5/4 orantısında x kaçtır?', opts: ['12', '20', '10', '8'], ans: '12' },
      ],
      open: [
        { q: 'Doğru orantı ve ters orantı arasındaki farkı örneklerle açıklayınız.' },
        { q: 'Bir işi 8 işçi 15 günde bitiriyor. Aynı işi 12 işçi kaç günde bitirir?' },
        { q: 'A:B = 3:4 ve B:C = 2:5 ise A:B:C oranını bulunuz.' },
        { q: '60 km/saat hızla giden bir araç 4 saatte hedefe varıyor. 80 km/saat hızla giderse kaç saatte varır?' },
        { q: 'Bir sınıfta kız öğrenci sayısının erkek öğrenci sayısına oranı 3/5 tir. Toplam 40 öğrenci varsa kaç kız öğrenci vardır?' },
      ]
    },
    'geometri': {
      test: [
        { q: 'Bir üçgenin iç açıları toplamı kaç derecedir?', opts: ['180°', '360°', '90°', '270°'], ans: '180°' },
        { q: 'Bir karenin alanı 49 cm² ise bir kenarı kaç cm dir?', opts: ['7', '14', '24.5', '12'], ans: '7' },
        { q: 'Tabanı 8 cm, yüksekliği 5 cm olan üçgenin alanı kaç cm² dir?', opts: ['20', '40', '13', '26'], ans: '20' },
        { q: 'Bir dikdörtgenin boyutları 6 cm ve 4 cm ise çevresi kaç cm dir?', opts: ['20', '24', '10', '48'], ans: '20' },
        { q: 'Eşkenar üçgende bir açı kaç derecedir?', opts: ['60°', '90°', '45°', '120°'], ans: '60°' },
        { q: 'Bir dörtgenin iç açıları toplamı kaç derecedir?', opts: ['360°', '180°', '540°', '270°'], ans: '360°' },
        { q: 'Paralelkenarın tabanı 10 cm, yüksekliği 6 cm ise alanı kaç cm² dir?', opts: ['60', '32', '80', '16'], ans: '60' },
        { q: 'Bir açının bütünleri 120° ise bu açı kaç derecedir?', opts: ['60°', '30°', '150°', '240°'], ans: '60°' },
        { q: 'Kenarları 3, 4, 5 cm olan üçgen hangi tür üçgendir?', opts: ['Dik açılı', 'Eşkenar', 'Geniş açılı', 'Dar açılı'], ans: 'Dik açılı' },
        { q: 'Bir karenin çevresi 36 cm ise alanı kaç cm² dir?', opts: ['81', '72', '36', '18'], ans: '81' },
        { q: 'Yamukta paralel kenarlar 6 cm ve 10 cm, yükseklik 4 cm ise alan kaç cm² dir?', opts: ['32', '40', '24', '60'], ans: '32' },
        { q: 'Bir açının tümleri 35° ise bu açı kaç derecedir?', opts: ['55°', '145°', '35°', '125°'], ans: '55°' },
      ],
      open: [
        { q: 'Üçgen eşitsizliğini açıklayıp bir örnek veriniz.' },
        { q: 'Bir dikdörtgenin alanı 48 cm², bir kenarı 6 cm ise diğer kenarını ve çevresini bulunuz.' },
        { q: 'Eşkenar, ikizkenar ve çeşitkenar üçgenlerin özelliklerini yazınız.' },
        { q: 'Tümler ve bütünler açıları açıklayınız. Örnekler veriniz.' },
        { q: 'Bir paralelkenarın özelliklerini yazınız ve alan formülünü çıkarınız.' },
        { q: 'Açıları 50°, 60° olan bir üçgenin üçüncü açısını bulunuz ve üçgeni sınıflandırınız.' },
      ]
    },
    'veri-analizi': {
      test: [
        { q: '3, 5, 7, 9, 11 verilerinin aritmetik ortalaması kaçtır?', opts: ['7', '35', '5', '9'], ans: '7' },
        { q: '2, 4, 4, 6, 8 verilerinin modu kaçtır?', opts: ['4', '6', '5', '2'], ans: '4' },
        { q: '1, 3, 5, 7, 9 verilerinin ortancası kaçtır?', opts: ['5', '3', '7', '25'], ans: '5' },
        { q: '10, 15, 20, 25, 30 verilerinin açıklığı kaçtır?', opts: ['20', '30', '10', '15'], ans: '20' },
        { q: 'Bir zar atıldığında 4 gelme olasılığı kaçtır?', opts: ['1/6', '1/3', '1/4', '4/6'], ans: '1/6' },
        { q: '5, 5, 10, 15, 15 verilerinin kaç modu vardır?', opts: ['2', '1', '3', '0'], ans: '2' },
        { q: '2, 4, 6, 8, 10, 12 verilerinin ortancası kaçtır?', opts: ['7', '6', '8', '42'], ans: '7' },
        { q: 'Yazı-tura atıldığında yazı gelme olasılığı kaçtır?', opts: ['1/2', '1/4', '1/3', '2/3'], ans: '1/2' },
        { q: '4, 8, 12, 16, 20 verilerinin ortalaması kaçtır?', opts: ['12', '60', '8', '16'], ans: '12' },
        { q: 'Bir torbada 3 kırmızı, 2 mavi top var. Kırmızı çekme olasılığı kaçtır?', opts: ['3/5', '2/5', '1/5', '2/3'], ans: '3/5' },
      ],
      open: [
        { q: 'Aritmetik ortalama, ortanca ve mod kavramlarını açıklayınız.' },
        { q: '4, 7, 2, 9, 8, 6, 5 verilerinin ortalama, ortanca ve açıklığını bulunuz.' },
        { q: 'Sütun grafik ve çizgi grafik ne zaman kullanılır? Örnekler veriniz.' },
        { q: 'Bir zarın 6 kez atılmasında en az bir kez 6 gelme olasılığını bulunuz.' },
        { q: '12, 15, 18, x, 24 verilerinin ortalaması 17 ise x kaçtır? Adımları gösteriniz.' },
      ]
    },
    'yuzde-problemleri': {
      test: [
        { q: '200 ün %25 i kaçtır?', opts: ['50', '25', '75', '150'], ans: '50' },
        { q: '60 sayısı 80 in yüzde kaçıdır?', opts: ['75', '80', '60', '133'], ans: '75' },
        { q: 'Bir ürün %20 indirimle 160 TL ye satılıyor. İndirimsiz fiyatı kaç TL dir?', opts: ['200', '192', '180', '128'], ans: '200' },
        { q: '500 TL ye %10 zam yapılırsa yeni fiyat kaç TL olur?', opts: ['550', '510', '450', '600'], ans: '550' },
        { q: '%30 u 45 olan sayı kaçtır?', opts: ['150', '135', '13.5', '15'], ans: '150' },
        { q: '80 den 100 e artış yüzde kaçtır?', opts: ['25', '20', '80', '125'], ans: '25' },
        { q: '300 TL nin %15 i kaç TL dir?', opts: ['45', '15', '285', '315'], ans: '45' },
        { q: 'Bir ürünün fiyatı 120 TL den 90 TL ye düştü. Yüzde kaç indirim yapılmıştır?', opts: ['25', '30', '33', '75'], ans: '25' },
        { q: '250 nin %40 ı kaçtır?', opts: ['100', '150', '40', '210'], ans: '100' },
        { q: '%60 ı 180 olan sayı kaçtır?', opts: ['300', '108', '240', '120'], ans: '300' },
      ],
      open: [
        { q: 'Bir mağaza tüm ürünlerde %30 indirim yapıyor. 350 TL lik bir ürün kaç TL ye satılır?' },
        { q: 'Yüzde artış ve yüzde azalış formüllerini yazıp birer örnek veriniz.' },
        { q: 'Bir ürünün fiyatı önce %20 arttı, sonra %20 azaldı. Son fiyat başlangıç fiyatından yüzde kaç farklıdır?' },
        { q: 'Bir sınıfta 40 öğrenci var. Bunların %60 ı kız ise kaç erkek öğrenci vardır?' },
      ]
    },
    'cember-daire': {
      test: [
        { q: 'Yarıçapı 7 cm olan çemberin çevresi kaç cm dir? (π=22/7)', opts: ['44', '154', '22', '88'], ans: '44' },
        { q: 'Yarıçapı 10 cm olan dairenin alanı kaç cm² dir? (π=3.14)', opts: ['314', '62.8', '31.4', '628'], ans: '314' },
        { q: 'Çapı 14 cm olan çemberin yarıçapı kaç cm dir?', opts: ['7', '28', '14', '3.5'], ans: '7' },
        { q: 'Çevresi 44 cm olan çemberin yarıçapı kaç cm dir? (π=22/7)', opts: ['7', '14', '22', '11'], ans: '7' },
        { q: 'Yarıçapı 5 cm olan dairenin alanı kaç cm² dir? (π=3.14)', opts: ['78.5', '31.4', '15.7', '157'], ans: '78.5' },
        { q: 'Çapı 20 cm olan çemberin çevresi kaç cm dir? (π=3.14)', opts: ['62.8', '314', '31.4', '125.6'], ans: '62.8' },
      ],
      open: [
        { q: 'Çember ve daire arasındaki farkı açıklayınız.' },
        { q: 'Yarıçapı 14 cm olan bir dairenin çevre ve alanını bulunuz. (π=22/7)' },
        { q: 'Alanı 154 cm² olan bir dairenin yarıçapını bulunuz. (π=22/7)' },
        { q: 'Çevresi 88 cm olan çemberin çapını ve alanını bulunuz. (π=22/7)' },
      ]
    }
  }

  // Secilen konulara gore sorulari topla
  for (const topicId of selectedTopics) {
    const bank = questionBank[topicId]
    if (!bank) continue

    const topic = topics.find(t => t.id === topicId)
    const topicName = topic?.name || topicId

    // Soru tipine gore secim
    let availableQuestions: any[] = []
    
    if (questionType === 'test') {
      availableQuestions = bank.test.map(q => ({ ...q, isOpenEnded: false }))
    } else if (questionType === 'open') {
      availableQuestions = bank.open.map(q => ({ ...q, isOpenEnded: true }))
    } else {
      // Karisik - yarisini test, yarisini acik uclu
      const halfTest = bank.test.slice(0, Math.ceil(bank.test.length / 2)).map(q => ({ ...q, isOpenEnded: false }))
      const halfOpen = bank.open.slice(0, Math.ceil(bank.open.length / 2)).map(q => ({ ...q, isOpenEnded: true }))
      availableQuestions = [...halfTest, ...halfOpen]
    }

    // Karistir
    availableQuestions = availableQuestions.sort(() => Math.random() - 0.5)

    for (const q of availableQuestions) {
      if (questions.length >= questionCount) break
      
      questions.push({
        id: id++,
        question: q.q,
        options: q.opts,
        correctAnswer: q.ans,
        topic: topicName,
        isOpenEnded: q.isOpenEnded
      })
    }
  }

  // Yeterli soru yoksa tekrar et
  while (questions.length < questionCount) {
    const randomTopic = selectedTopics[Math.floor(Math.random() * selectedTopics.length)]
    const bank = questionBank[randomTopic]
    if (!bank) break
    
    const topic = topics.find(t => t.id === randomTopic)
    const topicName = topic?.name || randomTopic
    
    const source = questionType === 'open' ? bank.open : bank.test
    const randomQ = source[Math.floor(Math.random() * source.length)]
    
    if (randomQ) {
      questions.push({
        id: id++,
        question: randomQ.q + ' (Varyant ' + id + ')',
        options: randomQ.opts,
        correctAnswer: randomQ.ans,
        topic: topicName,
        isOpenEnded: questionType === 'open'
      })
    } else {
      break
    }
  }

  return questions.slice(0, questionCount)
}

export default function SinavOlusturPage() {
  const [selectedTopics, setSelectedTopics] = useState<string[]>([])
  const [questionCount, setQuestionCount] = useState(10)
  const [questionType, setQuestionType] = useState<'test' | 'open' | 'mixed'>('test')
  const [examTitle, setExamTitle] = useState('7. Sınıf Matematik Sınavı')
  const [generatedExam, setGeneratedExam] = useState<ExamQuestion[] | null>(null)
  const [showAnswerKey, setShowAnswerKey] = useState(false)
  const printRef = useRef<HTMLDivElement>(null)

  const toggleTopic = (topicId: string) => {
    setSelectedTopics(prev => 
      prev.includes(topicId)
        ? prev.filter(t => t !== topicId)
        : [...prev, topicId]
    )
  }

  const selectAllTopics = () => {
    setSelectedTopics(topics.map(t => t.id))
  }

  const clearAllTopics = () => {
    setSelectedTopics([])
  }

  const handleGenerateExam = () => {
    if (selectedTopics.length === 0) {
      alert('Lütfen en az bir konu seçiniz!')
      return
    }
    const questions = generateExamQuestions(selectedTopics, questionCount, questionType)
    setGeneratedExam(questions)
    setShowAnswerKey(false)
  }

  const handlePrint = () => {
    window.print()
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Sınav Oluştur</h1>
            <p className="text-muted-foreground">
              Öğretmenler için özel sınav oluşturma paneli. Konuları seçin, soru sayısını belirleyin ve yazdırılabilir sınav oluşturun.
            </p>
          </div>

          {!generatedExam ? (
            <div className="space-y-6">
              {/* Sinav Basligi */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Sınav Bilgileri
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="examTitle">Sınav Başlığı</Label>
                    <Input
                      id="examTitle"
                      value={examTitle}
                      onChange={(e) => setExamTitle(e.target.value)}
                      placeholder="Örn: 1. Dönem 2. Yazılı Sınavı"
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="questionCount">Soru Sayısı: {questionCount}</Label>
                    <Input
                      id="questionCount"
                      type="range"
                      min={5}
                      max={50}
                      value={questionCount}
                      onChange={(e) => setQuestionCount(parseInt(e.target.value))}
                      className="mt-1"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>5</span>
                      <span>50</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Soru Tipi */}
              <Card>
                <CardHeader>
                  <CardTitle>Soru Tipi</CardTitle>
                  <CardDescription>Sınavda hangi tip sorular olsun?</CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={questionType}
                    onValueChange={(value) => setQuestionType(value as 'test' | 'open' | 'mixed')}
                    className="grid grid-cols-1 sm:grid-cols-3 gap-4"
                  >
                    <Label
                      htmlFor="test"
                      className={`flex items-center gap-3 rounded-lg border-2 p-4 cursor-pointer transition-colors ${
                        questionType === 'test' ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <RadioGroupItem value="test" id="test" />
                      <div>
                        <div className="font-medium">Çoktan Seçmeli</div>
                        <div className="text-sm text-muted-foreground">4 şıklı test soruları</div>
                      </div>
                    </Label>
                    
                    <Label
                      htmlFor="open"
                      className={`flex items-center gap-3 rounded-lg border-2 p-4 cursor-pointer transition-colors ${
                        questionType === 'open' ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <RadioGroupItem value="open" id="open" />
                      <div>
                        <div className="font-medium">Açık Uçlu</div>
                        <div className="text-sm text-muted-foreground">Klasik yazılı soruları</div>
                      </div>
                    </Label>
                    
                    <Label
                      htmlFor="mixed"
                      className={`flex items-center gap-3 rounded-lg border-2 p-4 cursor-pointer transition-colors ${
                        questionType === 'mixed' ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <RadioGroupItem value="mixed" id="mixed" />
                      <div>
                        <div className="font-medium">Karışık</div>
                        <div className="text-sm text-muted-foreground">Test + Açık uçlu</div>
                      </div>
                    </Label>
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* Konu Secimi */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Konu Seçimi</CardTitle>
                      <CardDescription>{selectedTopics.length} konu seçildi</CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={selectAllTopics}>
                        Tümünü Seç
                      </Button>
                      <Button variant="outline" size="sm" onClick={clearAllTopics}>
                        Temizle
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {topics.map((topic) => (
                      <Label
                        key={topic.id}
                        htmlFor={topic.id}
                        className={`flex items-center gap-3 rounded-lg border-2 p-4 cursor-pointer transition-colors ${
                          selectedTopics.includes(topic.id)
                            ? 'border-primary bg-primary/5'
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Checkbox
                          id={topic.id}
                          checked={selectedTopics.includes(topic.id)}
                          onCheckedChange={() => toggleTopic(topic.id)}
                        />
                        <span className="text-xl">{topic.icon}</span>
                        <div>
                          <div className="font-medium">{topic.name}</div>
                          <div className="text-xs text-muted-foreground">{topic.lessons.length} ders</div>
                        </div>
                      </Label>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Olustur Butonu */}
              <Button 
                onClick={handleGenerateExam} 
                className="w-full h-12 text-lg"
                disabled={selectedTopics.length === 0}
              >
                <FileText className="mr-2 h-5 w-5" />
                Sınavı Oluştur
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Kontrol Butonlari */}
              <div className="flex flex-wrap gap-3 no-print">
                <Button onClick={() => setGeneratedExam(null)} variant="outline">
                  Yeni Sınav Oluştur
                </Button>
                <Button onClick={handlePrint}>
                  <Printer className="mr-2 h-4 w-4" />
                  Yazdır
                </Button>
                <Button 
                  variant={showAnswerKey ? "default" : "outline"}
                  onClick={() => setShowAnswerKey(!showAnswerKey)}
                >
                  <CheckCircle2 className="mr-2 h-4 w-4" />
                  {showAnswerKey ? 'Cevap Anahtarını Gizle' : 'Cevap Anahtarını Göster'}
                </Button>
              </div>

              {/* Sinav Ciktisi */}
              <div ref={printRef} className="print-area bg-background p-8 rounded-lg border">
                {/* Sinav Basligi */}
                <div className="text-center mb-8 border-b pb-6">
                  <h1 className="text-2xl font-bold mb-2">{examTitle}</h1>
                  <div className="flex justify-center gap-8 text-sm text-muted-foreground">
                    <span>Tarih: _______________</span>
                    <span>Ad Soyad: _______________</span>
                    <span>Numara: _______</span>
                  </div>
                  <div className="mt-4 text-sm">
                    <span className="font-medium">Toplam Soru: </span>{generatedExam.length} | 
                    <span className="font-medium ml-2">Süre: </span>_______ dk
                  </div>
                </div>

                {/* Sorular */}
                <div className="space-y-6">
                  {generatedExam.map((q, index) => (
                    <div key={q.id} className="border-b pb-4 last:border-b-0">
                      <div className="flex gap-2 mb-2">
                        <span className="font-bold">{index + 1}.</span>
                        <div className="flex-1">
                          <span className="text-xs text-muted-foreground">({q.topic})</span>
                          <p className="font-medium">{q.question}</p>
                        </div>
                      </div>
                      
                      {!q.isOpenEnded && q.options && (
                        <div className="ml-6 grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
                          {q.options.map((opt, i) => (
                            <div key={i} className="flex items-center gap-2">
                              <span className="font-medium">{String.fromCharCode(65 + i)})</span>
                              <span>{opt}</span>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      {q.isOpenEnded && (
                        <div className="ml-6 mt-4">
                          <div className="border-b border-dashed border-muted-foreground/30 h-8" />
                          <div className="border-b border-dashed border-muted-foreground/30 h-8" />
                          <div className="border-b border-dashed border-muted-foreground/30 h-8" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Cevap Anahtari */}
                {showAnswerKey && (
                  <div className="mt-8 pt-6 border-t-2 border-dashed">
                    <h2 className="text-lg font-bold mb-4">Cevap Anahtarı</h2>
                    <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
                      {generatedExam.map((q, index) => (
                        <div key={q.id} className="text-center p-2 bg-muted rounded">
                          <div className="text-xs text-muted-foreground">{index + 1}</div>
                          <div className="font-bold">
                            {q.isOpenEnded ? '—' : 
                              q.options && q.correctAnswer ? 
                                String.fromCharCode(65 + q.options.indexOf(q.correctAnswer)) : 
                                '—'
                            }
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          .no-print {
            display: none !important;
          }
          header {
            display: none !important;
          }
          .print-area {
            border: none !important;
            box-shadow: none !important;
          }
          body {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }
        }
      `}</style>
    </div>
  )
}
