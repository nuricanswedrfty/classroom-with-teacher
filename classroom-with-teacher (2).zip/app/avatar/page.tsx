'use client'

import { Header } from '@/components/header'
import { useGameStore, clothingItems } from '@/lib/game-store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { PlantGarden } from '@/components/plant-garden'
import { Check, User, Shirt, Lock } from 'lucide-react'
import { cn } from '@/lib/utils'
import Link from 'next/link'

export default function AvatarPage() {
  const { profile, ownedClothing, equipClothing, coins, totalCoinsEarned } = useGameStore()

  if (!profile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p>Profil bulunamadi</p>
      </div>
    )
  }

  const filteredClothing = clothingItems.filter(
    item => item.forGender === 'all' || item.forGender === profile.gender
  )

  const headItems = filteredClothing.filter(i => i.type === 'head')
  const bodyItems = filteredClothing.filter(i => i.type === 'body')
  const accessoryItems = filteredClothing.filter(i => i.type === 'accessory')

  const equippedHead = clothingItems.find(i => i.id === profile.avatar.head)
  const equippedBody = clothingItems.find(i => i.id === profile.avatar.body)
  const equippedAccessory = clothingItems.find(i => i.id === profile.avatar.accessory)

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold mb-8 flex items-center gap-3">
            <User className="w-8 h-8 text-primary" />
            Profilim
          </h1>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Avatar Görünümü */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Karakterim</CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  {/* Avatar Display */}
                  <div className="relative inline-block">
                    <div className="w-48 h-48 mx-auto rounded-full bg-gradient-to-br from-primary/20 to-accent flex items-center justify-center relative">
                      {/* Base Avatar */}
                      <span className="text-8xl">{profile.avatar.skinTone}</span>
                      
                      {/* Head item */}
                      {equippedHead && (
                        <span className="absolute top-0 left-1/2 -translate-x-1/2 text-4xl">
                          {equippedHead.icon}
                        </span>
                      )}
                      
                      {/* Accessory */}
                      {equippedAccessory && (
                        <span className="absolute bottom-4 right-4 text-3xl">
                          {equippedAccessory.icon}
                        </span>
                      )}
                    </div>
                    
                    {/* Body costume overlay */}
                    {equippedBody && (
                      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 text-5xl">
                        {equippedBody.icon}
                      </div>
                    )}
                  </div>
                  
                  <h2 className="text-2xl font-bold mt-4">{profile.name}</h2>
                  <p className="text-muted-foreground">
                    {profile.gender === 'male' ? 'Erkek' : 'Kiz'}
                  </p>

                  {/* Equipped Items */}
                  <div className="flex justify-center gap-2 mt-4">
                    {equippedHead && (
                      <Badge variant="secondary" className="gap-1">
                        {equippedHead.icon} {equippedHead.name}
                      </Badge>
                    )}
                    {equippedBody && (
                      <Badge variant="secondary" className="gap-1">
                        {equippedBody.icon} {equippedBody.name}
                      </Badge>
                    )}
                    {equippedAccessory && (
                      <Badge variant="secondary" className="gap-1">
                        {equippedAccessory.icon} {equippedAccessory.name}
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* İstatistikler */}
              <Card>
                <CardHeader>
                  <CardTitle>Istatistikler</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Mevcut Puan</span>
                    <span className="font-bold text-yellow-600">{coins} altin</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Toplam Kazanilan</span>
                    <span className="font-bold">{totalCoinsEarned} altin</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground">Sahip Olunan Kiyafet</span>
                    <span className="font-bold">{ownedClothing.length} adet</span>
                  </div>
                </CardContent>
              </Card>

              {/* Fidan Bahçesi */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <span>🌱</span> Fidan Bahcem
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <PlantGarden />
                </CardContent>
              </Card>
            </div>

            {/* Kıyafet Seçimi */}
            <div>
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Shirt className="w-5 h-5" />
                      Kiyafetlerim
                    </CardTitle>
                    <Link href="/market">
                      <Button variant="outline" size="sm">Markete Git</Button>
                    </Link>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="head">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="head">Sapka</TabsTrigger>
                      <TabsTrigger value="body">Kiyafet</TabsTrigger>
                      <TabsTrigger value="accessory">Aksesuar</TabsTrigger>
                    </TabsList>

                    {/* Şapkalar */}
                    <TabsContent value="head" className="mt-4">
                      <div className="grid grid-cols-3 gap-3">
                        {/* Boş seçenek */}
                        <button
                          onClick={() => equipClothing('head', undefined)}
                          className={cn(
                            "p-4 rounded-lg border-2 transition-all",
                            !profile.avatar.head
                              ? "border-primary bg-primary/10"
                              : "border-border hover:border-primary/50"
                          )}
                        >
                          <div className="text-2xl text-center mb-1">❌</div>
                          <div className="text-xs text-center">Yok</div>
                        </button>
                        
                        {headItems.map((item) => {
                          const owned = ownedClothing.includes(item.id)
                          const equipped = profile.avatar.head === item.id
                          
                          return (
                            <button
                              key={item.id}
                              onClick={() => owned && equipClothing('head', item.id)}
                              disabled={!owned}
                              className={cn(
                                "p-4 rounded-lg border-2 transition-all relative",
                                equipped && "border-primary bg-primary/10",
                                !equipped && owned && "border-border hover:border-primary/50",
                                !owned && "border-border opacity-50 cursor-not-allowed"
                              )}
                            >
                              {!owned && (
                                <Lock className="w-3 h-3 absolute top-1 right-1 text-muted-foreground" />
                              )}
                              {equipped && (
                                <Check className="w-3 h-3 absolute top-1 right-1 text-primary" />
                              )}
                              <div className="text-2xl text-center mb-1">{item.icon}</div>
                              <div className="text-xs text-center truncate">{item.name}</div>
                            </button>
                          )
                        })}
                      </div>
                    </TabsContent>

                    {/* Kıyafetler */}
                    <TabsContent value="body" className="mt-4">
                      <div className="grid grid-cols-3 gap-3">
                        <button
                          onClick={() => equipClothing('body', undefined)}
                          className={cn(
                            "p-4 rounded-lg border-2 transition-all",
                            !profile.avatar.body
                              ? "border-primary bg-primary/10"
                              : "border-border hover:border-primary/50"
                          )}
                        >
                          <div className="text-2xl text-center mb-1">❌</div>
                          <div className="text-xs text-center">Yok</div>
                        </button>
                        
                        {bodyItems.map((item) => {
                          const owned = ownedClothing.includes(item.id)
                          const equipped = profile.avatar.body === item.id
                          
                          return (
                            <button
                              key={item.id}
                              onClick={() => owned && equipClothing('body', item.id)}
                              disabled={!owned}
                              className={cn(
                                "p-4 rounded-lg border-2 transition-all relative",
                                equipped && "border-primary bg-primary/10",
                                !equipped && owned && "border-border hover:border-primary/50",
                                !owned && "border-border opacity-50 cursor-not-allowed"
                              )}
                            >
                              {!owned && (
                                <Lock className="w-3 h-3 absolute top-1 right-1 text-muted-foreground" />
                              )}
                              {equipped && (
                                <Check className="w-3 h-3 absolute top-1 right-1 text-primary" />
                              )}
                              <div className="text-2xl text-center mb-1">{item.icon}</div>
                              <div className="text-xs text-center truncate">{item.name}</div>
                            </button>
                          )
                        })}
                      </div>
                    </TabsContent>

                    {/* Aksesuarlar */}
                    <TabsContent value="accessory" className="mt-4">
                      <div className="grid grid-cols-3 gap-3">
                        <button
                          onClick={() => equipClothing('accessory', undefined)}
                          className={cn(
                            "p-4 rounded-lg border-2 transition-all",
                            !profile.avatar.accessory
                              ? "border-primary bg-primary/10"
                              : "border-border hover:border-primary/50"
                          )}
                        >
                          <div className="text-2xl text-center mb-1">❌</div>
                          <div className="text-xs text-center">Yok</div>
                        </button>
                        
                        {accessoryItems.map((item) => {
                          const owned = ownedClothing.includes(item.id)
                          const equipped = profile.avatar.accessory === item.id
                          
                          return (
                            <button
                              key={item.id}
                              onClick={() => owned && equipClothing('accessory', item.id)}
                              disabled={!owned}
                              className={cn(
                                "p-4 rounded-lg border-2 transition-all relative",
                                equipped && "border-primary bg-primary/10",
                                !equipped && owned && "border-border hover:border-primary/50",
                                !owned && "border-border opacity-50 cursor-not-allowed"
                              )}
                            >
                              {!owned && (
                                <Lock className="w-3 h-3 absolute top-1 right-1 text-muted-foreground" />
                              )}
                              {equipped && (
                                <Check className="w-3 h-3 absolute top-1 right-1 text-primary" />
                              )}
                              <div className="text-2xl text-center mb-1">{item.icon}</div>
                              <div className="text-xs text-center truncate">{item.name}</div>
                            </button>
                          )
                        })}
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
