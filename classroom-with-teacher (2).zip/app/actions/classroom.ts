'use server'

import { db } from '@/lib/db'
import { classrooms, classroomStudents, exams, examQuestions, studentAnswers, userInventory } from '@/lib/db/schema'
import { eq, and, desc } from 'drizzle-orm'
import { revalidatePath } from 'next/cache'

// 5 haneli rastgele kod olustur
function generateClassCode(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
  let code = ''
  for (let i = 0; i < 5; i++) {
    code += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return code
}

// ==================== SINIF ISLEMLERI ====================

// Sinif olustur
export async function createClassroom(teacherId: string, name: string) {
  let code = generateClassCode()
  
  // Benzersiz kod kontrolu
  let existing = await db.select().from(classrooms).where(eq(classrooms.code, code))
  while (existing.length > 0) {
    code = generateClassCode()
    existing = await db.select().from(classrooms).where(eq(classrooms.code, code))
  }
  
  const result = await db.insert(classrooms).values({
    code,
    name,
    teacherId,
  }).returning()
  
  revalidatePath('/ogretmen')
  return result[0]
}

// Ogretmenin siniflarini getir
export async function getTeacherClassrooms(teacherId: string) {
  return db.select().from(classrooms).where(eq(classrooms.teacherId, teacherId)).orderBy(desc(classrooms.createdAt))
}

// Sinifi kod ile bul
export async function findClassroomByCode(code: string) {
  const result = await db.select().from(classrooms).where(eq(classrooms.code, code.toUpperCase()))
  return result[0] || null
}

// Sinif detaylarini getir
export async function getClassroomDetails(classroomId: number) {
  const classroom = await db.select().from(classrooms).where(eq(classrooms.id, classroomId))
  if (!classroom[0]) return null
  
  const students = await db.select().from(classroomStudents).where(eq(classroomStudents.classroomId, classroomId)).orderBy(desc(classroomStudents.points))
  const examList = await db.select().from(exams).where(eq(exams.classroomId, classroomId)).orderBy(desc(exams.createdAt))
  
  return {
    ...classroom[0],
    students,
    exams: examList
  }
}

// ==================== OGRENCI ISLEMLERI ====================

// Sinifa katil
export async function joinClassroom(code: string, studentName: string, studentId?: string) {
  const classroom = await findClassroomByCode(code)
  if (!classroom) {
    return { error: 'Sinif bulunamadi' }
  }
  
  // Zaten katilmis mi kontrolu
  const existing = await db.select().from(classroomStudents)
    .where(and(
      eq(classroomStudents.classroomId, classroom.id),
      eq(classroomStudents.studentName, studentName)
    ))
  
  if (existing.length > 0) {
    return { error: 'Bu isimle zaten kayitlisiniz', student: existing[0], classroom }
  }
  
  const result = await db.insert(classroomStudents).values({
    classroomId: classroom.id,
    studentName,
    studentId,
    points: 0,
  }).returning()
  
  return { student: result[0], classroom }
}

// Ogrencinin siniflarini getir
export async function getStudentClassrooms(studentName: string) {
  const studentRecords = await db.select().from(classroomStudents).where(eq(classroomStudents.studentName, studentName))
  
  const classroomsData = await Promise.all(
    studentRecords.map(async (record) => {
      const classroom = await db.select().from(classrooms).where(eq(classrooms.id, record.classroomId))
      return {
        ...record,
        classroom: classroom[0]
      }
    })
  )
  
  return classroomsData
}

// Ogrenci puani guncelle
export async function updateStudentPoints(studentId: number, pointsToAdd: number) {
  const student = await db.select().from(classroomStudents).where(eq(classroomStudents.id, studentId))
  if (!student[0]) return null
  
  const newPoints = (student[0].points || 0) + pointsToAdd
  
  await db.update(classroomStudents)
    .set({ points: newPoints })
    .where(eq(classroomStudents.id, studentId))
  
  return newPoints
}

// ==================== SINAV ISLEMLERI ====================

// Sinav olustur
export async function createExam(classroomId: number, title: string, description?: string) {
  const result = await db.insert(exams).values({
    classroomId,
    title,
    description,
    isActive: true,
  }).returning()
  
  revalidatePath('/ogretmen')
  return result[0]
}

// Sinava soru ekle
export async function addQuestionToExam(
  examId: number, 
  question: string, 
  optionA: string, 
  optionB: string, 
  optionC: string, 
  optionD: string, 
  correctAnswer: string,
  points: number = 10
) {
  const result = await db.insert(examQuestions).values({
    examId,
    question,
    optionA,
    optionB,
    optionC,
    optionD,
    correctAnswer: correctAnswer.toUpperCase(),
    points,
  }).returning()
  
  return result[0]
}

// Sinavin sorularini getir
export async function getExamQuestions(examId: number) {
  return db.select().from(examQuestions).where(eq(examQuestions.examId, examId))
}

// Sinavi getir
export async function getExam(examId: number) {
  const exam = await db.select().from(exams).where(eq(exams.id, examId))
  if (!exam[0]) return null
  
  const questions = await getExamQuestions(examId)
  const classroom = await db.select().from(classrooms).where(eq(classrooms.id, exam[0].classroomId))
  
  return {
    ...exam[0],
    questions,
    classroom: classroom[0]
  }
}

// Ogrenci sinav cevabi kaydet
export async function submitExamAnswer(examId: number, studentId: number, questionId: number, answer: string) {
  // Dogru cevabi kontrol et
  const question = await db.select().from(examQuestions).where(eq(examQuestions.id, questionId))
  if (!question[0]) return { error: 'Soru bulunamadi' }
  
  const isCorrect = question[0].correctAnswer === answer.toUpperCase()
  
  // Daha once cevaplamis mi kontrol et
  const existing = await db.select().from(studentAnswers)
    .where(and(
      eq(studentAnswers.examId, examId),
      eq(studentAnswers.studentId, studentId),
      eq(studentAnswers.questionId, questionId)
    ))
  
  if (existing.length > 0) {
    return { error: 'Bu soruyu zaten cevapladin', alreadyAnswered: true }
  }
  
  await db.insert(studentAnswers).values({
    examId,
    studentId,
    questionId,
    answer: answer.toUpperCase(),
    isCorrect,
  })
  
  // Dogru ise puan ekle
  if (isCorrect) {
    await updateStudentPoints(studentId, question[0].points || 10)
  }
  
  return { isCorrect, points: isCorrect ? question[0].points : 0 }
}

// Ogrencinin sinav sonuclarini getir
export async function getStudentExamResults(examId: number, studentId: number) {
  const answers = await db.select().from(studentAnswers)
    .where(and(
      eq(studentAnswers.examId, examId),
      eq(studentAnswers.studentId, studentId)
    ))
  
  const questions = await getExamQuestions(examId)
  
  const totalQuestions = questions.length
  const answeredQuestions = answers.length
  const correctAnswers = answers.filter(a => a.isCorrect).length
  const totalPoints = answers.reduce((sum, a) => {
    if (a.isCorrect) {
      const q = questions.find(q => q.id === a.questionId)
      return sum + (q?.points || 10)
    }
    return sum
  }, 0)
  
  return {
    answers,
    totalQuestions,
    answeredQuestions,
    correctAnswers,
    totalPoints,
    completed: answeredQuestions === totalQuestions
  }
}

// ==================== ENVANTER ISLEMLERI ====================

// Envantere esya ekle
export async function addToInventory(userIdentifier: string, itemId: string, itemType: string, quantity: number = 1) {
  // Zaten var mi kontrol et
  const existing = await db.select().from(userInventory)
    .where(and(
      eq(userInventory.userIdentifier, userIdentifier),
      eq(userInventory.itemId, itemId)
    ))
  
  if (existing.length > 0) {
    // Miktar guncelle
    await db.update(userInventory)
      .set({ quantity: (existing[0].quantity || 0) + quantity })
      .where(eq(userInventory.id, existing[0].id))
    return existing[0]
  }
  
  // Yeni ekle
  const result = await db.insert(userInventory).values({
    userIdentifier,
    itemId,
    itemType,
    quantity,
  }).returning()
  
  return result[0]
}

// Kullanicinin envanterini getir
export async function getUserInventory(userIdentifier: string) {
  return db.select().from(userInventory).where(eq(userInventory.userIdentifier, userIdentifier))
}

// Envanterden esya cikar
export async function removeFromInventory(userIdentifier: string, itemId: string, quantity: number = 1) {
  const existing = await db.select().from(userInventory)
    .where(and(
      eq(userInventory.userIdentifier, userIdentifier),
      eq(userInventory.itemId, itemId)
    ))
  
  if (existing.length === 0) return false
  
  const newQuantity = (existing[0].quantity || 0) - quantity
  
  if (newQuantity <= 0) {
    await db.delete(userInventory).where(eq(userInventory.id, existing[0].id))
  } else {
    await db.update(userInventory)
      .set({ quantity: newQuantity })
      .where(eq(userInventory.id, existing[0].id))
  }
  
  return true
}
