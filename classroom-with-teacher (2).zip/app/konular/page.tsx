'use client'

import { Header } from '@/components/header'
import { TopicCard } from '@/components/topic-card'
import { topics } from '@/lib/math-data'

export default function TopicsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Tum Konular</h1>
          <p className="text-muted-foreground">
            7. sinif matematik mufredatindaki tum konulari incele ve ogren
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {topics.map((topic) => (
            <TopicCard key={topic.id} topic={topic} />
          ))}
        </div>
      </main>
    </div>
  )
}
