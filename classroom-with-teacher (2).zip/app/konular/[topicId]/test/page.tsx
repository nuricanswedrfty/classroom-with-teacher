'use client'

import { use } from 'react'
import { useSearchParams } from 'next/navigation'
import { Header } from '@/components/header'
import { Quiz } from '@/components/quiz'
import { topics } from '@/lib/math-data'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft } from 'lucide-react'

export default function TestPage({ params }: { params: Promise<{ topicId: string }> }) {
  const { topicId } = use(params)
  const searchParams = useSearchParams()
  const topic = topics.find(t => t.id === topicId)
  
  if (!topic) {
    notFound()
  }

  const difficulty = (searchParams.get('difficulty') as 'kolay' | 'orta' | 'zor' | 'karisik') || 'karisik'
  const count = parseInt(searchParams.get('count') || '10', 10)

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8 max-w-2xl">
        {/* Back Button */}
        <Link 
          href={`/konular/${topicId}`}
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          {topic.name} Konusuna Don
        </Link>

        {/* Test Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-3xl">{topic.icon}</span>
            <div>
              <h1 className="text-2xl font-bold">{topic.name} Testi</h1>
              <p className="text-muted-foreground">
                {count} soru | {difficulty === 'karisik' ? 'Karisik zorluk' : `${difficulty.charAt(0).toUpperCase() + difficulty.slice(1)} seviye`}
              </p>
            </div>
          </div>
        </div>

        {/* Quiz Component */}
        <Quiz 
          topicId={topicId} 
          topicName={topic.name}
          questionCount={count}
          difficulty={difficulty}
        />
      </main>
    </div>
  )
}
