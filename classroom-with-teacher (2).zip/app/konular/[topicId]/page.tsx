'use client'

import { use } from 'react'
import { Header } from '@/components/header'
import { LessonCard } from '@/components/lesson-card'
import { topics } from '@/lib/math-data'
import { useProgressStore } from '@/lib/progress-store'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Play, BookOpen, Target, Trophy } from 'lucide-react'
import { cn } from '@/lib/utils'

export default function TopicDetailPage({ params }: { params: Promise<{ topicId: string }> }) {
  const { topicId } = use(params)
  const topic = topics.find(t => t.id === topicId)
  const { getTopicProgress } = useProgressStore()
  
  if (!topic) {
    notFound()
  }

  const progress = getTopicProgress(topicId)
  const completedLessons = progress.lessonsCompleted.length
  const totalLessons = topic.lessons.length
  const progressPercent = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0
  const accuracy = progress.totalQuestions > 0 
    ? Math.round((progress.totalCorrect / progress.totalQuestions) * 100) 
    : 0

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8">
        {/* Back Button */}
        <Link 
          href="/konular" 
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6"
        >
          <ArrowLeft className="w-4 h-4" />
          Tum Konular
        </Link>

        {/* Topic Header */}
        <div className={cn(
          "rounded-2xl p-6 md:p-8 mb-8 border",
          topic.color === 'blue' && "bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800",
          topic.color === 'green' && "bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-800",
          topic.color === 'purple' && "bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800",
          topic.color === 'orange' && "bg-orange-50 dark:bg-orange-950/30 border-orange-200 dark:border-orange-800",
          topic.color === 'pink' && "bg-pink-50 dark:bg-pink-950/30 border-pink-200 dark:border-pink-800",
          topic.color === 'cyan' && "bg-cyan-50 dark:bg-cyan-950/30 border-cyan-200 dark:border-cyan-800",
        )}>
          <div className="flex flex-col md:flex-row md:items-center gap-6">
            <div className="text-5xl">{topic.icon}</div>
            <div className="flex-1">
              <h1 className="text-2xl md:text-3xl font-bold mb-2">{topic.name}</h1>
              <p className="text-muted-foreground mb-4">{topic.description}</p>
              
              {/* Progress Bar */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-sm mb-2">
                  <span>{completedLessons} / {totalLessons} ders tamamlandi</span>
                  <span className="font-medium">%{progressPercent}</span>
                </div>
                <div className="h-2 w-full rounded-full bg-background/50">
                  <div
                    className={cn(
                      "h-2 rounded-full transition-all",
                      topic.color === 'blue' && "bg-blue-500",
                      topic.color === 'green' && "bg-green-500",
                      topic.color === 'purple' && "bg-purple-500",
                      topic.color === 'orange' && "bg-orange-500",
                      topic.color === 'pink' && "bg-pink-500",
                      topic.color === 'cyan' && "bg-cyan-500",
                    )}
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>

              {/* Stats */}
              <div className="flex flex-wrap gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-muted-foreground" />
                  <span>{totalLessons} ders</span>
                </div>
                <div className="flex items-center gap-2">
                  <Target className="w-4 h-4 text-muted-foreground" />
                  <span>{progress.testsCompleted} test cozuldu</span>
                </div>
                {progress.bestScore > 0 && (
                  <div className="flex items-center gap-2">
                    <Trophy className="w-4 h-4 text-muted-foreground" />
                    <span>En iyi: %{progress.bestScore}</span>
                  </div>
                )}
                {accuracy > 0 && (
                  <div className="flex items-center gap-2">
                    <span className="text-green-600">✓</span>
                    <span>Basari: %{accuracy}</span>
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex flex-col gap-2">
              <Link href={`/konular/${topicId}/test`}>
                <Button size="lg" className="w-full gap-2">
                  <Play className="w-4 h-4" />
                  Test Coz
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Lessons */}
        <section>
          <h2 className="text-xl font-bold mb-4">Dersler</h2>
          <div className="space-y-3">
            {topic.lessons.map((lesson, index) => (
              <LessonCard 
                key={lesson.id} 
                lesson={lesson} 
                topicId={topicId}
                index={index}
              />
            ))}
          </div>
        </section>

        {/* Quick Test Options */}
        <section className="mt-8">
          <h2 className="text-xl font-bold mb-4">Hizli Test</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Link href={`/konular/${topicId}/test?difficulty=kolay`}>
              <div className="rounded-xl border border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-950/30 p-4 text-center hover:shadow-md transition-all">
                <div className="text-2xl mb-2">🟢</div>
                <h3 className="font-medium">Kolay</h3>
                <p className="text-xs text-muted-foreground">Temel sorular</p>
              </div>
            </Link>
            <Link href={`/konular/${topicId}/test?difficulty=orta`}>
              <div className="rounded-xl border border-yellow-200 dark:border-yellow-800 bg-yellow-50 dark:bg-yellow-950/30 p-4 text-center hover:shadow-md transition-all">
                <div className="text-2xl mb-2">🟡</div>
                <h3 className="font-medium">Orta</h3>
                <p className="text-xs text-muted-foreground">Standart sorular</p>
              </div>
            </Link>
            <Link href={`/konular/${topicId}/test?difficulty=zor`}>
              <div className="rounded-xl border border-red-200 dark:border-red-800 bg-red-50 dark:bg-red-950/30 p-4 text-center hover:shadow-md transition-all">
                <div className="text-2xl mb-2">🔴</div>
                <h3 className="font-medium">Zor</h3>
                <p className="text-xs text-muted-foreground">Ileri duzey</p>
              </div>
            </Link>
            <Link href={`/konular/${topicId}/test?count=20`}>
              <div className="rounded-xl border border-purple-200 dark:border-purple-800 bg-purple-50 dark:bg-purple-950/30 p-4 text-center hover:shadow-md transition-all">
                <div className="text-2xl mb-2">📝</div>
                <h3 className="font-medium">Maraton</h3>
                <p className="text-xs text-muted-foreground">20 soru</p>
              </div>
            </Link>
          </div>
        </section>
      </main>
    </div>
  )
}
