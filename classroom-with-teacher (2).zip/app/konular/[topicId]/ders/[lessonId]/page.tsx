'use client'

import { use, useState, useRef } from 'react'
import { Header } from '@/components/header'
import { topics } from '@/lib/math-data'
import { useProgressStore } from '@/lib/progress-store'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ArrowLeft, CheckCircle, ArrowRight, FileText, Printer, X } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function LessonPage({ 
  params 
}: { 
  params: Promise<{ topicId: string; lessonId: string }> 
}) {
  const { topicId, lessonId } = use(params)
  const topic = topics.find(t => t.id === topicId)
  const lesson = topic?.lessons.find(l => l.id === lessonId)
  const { completeLesson, getTopicProgress } = useProgressStore()
  const [showSummary, setShowSummary] = useState(false)
  const summaryRef = useRef<HTMLDivElement>(null)
  
  if (!topic || !lesson) {
    notFound()
  }

  const progress = getTopicProgress(topicId)
  const isCompleted = progress.lessonsCompleted.includes(lessonId)
  const lessonIndex = topic.lessons.findIndex(l => l.id === lessonId)
  const nextLesson = topic.lessons[lessonIndex + 1]
  const prevLesson = topic.lessons[lessonIndex - 1]

  const handleComplete = () => {
    completeLesson(topicId, lessonId)
  }

  // Özet çıkarma fonksiyonu
  const generateSummary = () => {
    const lines = lesson.content.split('\n')
    const keyPoints: string[] = []
    
    lines.forEach(line => {
      const trimmed = line.trim()
      // Formülleri ve önemli noktaları bul
      if (trimmed.includes('=') && trimmed.length < 80) {
        keyPoints.push(trimmed)
      } else if (trimmed.startsWith('•') || trimmed.startsWith('-')) {
        keyPoints.push(trimmed.replace(/^[•-]\s*/, ''))
      } else if (trimmed.includes(':') && trimmed.length < 60) {
        keyPoints.push(trimmed)
      }
    })
    
    return keyPoints.slice(0, 10) // En fazla 10 madde
  }

  const handlePrintSummary = () => {
    const printContent = `
      <html>
        <head>
          <title>${lesson.title} - Ozet</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
            h1 { color: #333; border-bottom: 2px solid #333; padding-bottom: 10px; }
            h2 { color: #666; margin-top: 20px; }
            ul { line-height: 1.8; }
            li { margin-bottom: 8px; }
            .header { display: flex; justify-content: space-between; margin-bottom: 30px; }
            .date { color: #999; }
            .examples { background: #f5f5f5; padding: 15px; border-radius: 8px; margin-top: 20px; }
            .example-item { margin-bottom: 10px; font-family: monospace; }
          </style>
        </head>
        <body>
          <div class="header">
            <span>${topic.icon} ${topic.name}</span>
            <span class="date">${new Date().toLocaleDateString('tr-TR')}</span>
          </div>
          <h1>${lesson.title} - Ozet</h1>
          
          <h2>Onemli Noktalar</h2>
          <ul>
            ${generateSummary().map(point => `<li>${point}</li>`).join('')}
          </ul>
          
          ${lesson.examples && lesson.examples.length > 0 ? `
            <div class="examples">
              <h2>Ornekler</h2>
              ${lesson.examples.map((ex, i) => `<div class="example-item">${i + 1}. ${ex}</div>`).join('')}
            </div>
          ` : ''}
          
          <p style="margin-top: 40px; color: #999; font-size: 12px;">
            7. Sinif Matematik - ${topic.name}
          </p>
        </body>
      </html>
    `
    
    const printWindow = window.open('', '_blank')
    if (printWindow) {
      printWindow.document.write(printContent)
      printWindow.document.close()
      printWindow.print()
    }
  }

  // Parse content for better display
  const contentSections = lesson.content.split('\n\n').map((section, i) => {
    // Check if it's a formula (contains mathematical notation)
    if (section.includes('=') && section.length < 100) {
      return (
        <div key={i} className="my-4 p-4 rounded-lg bg-primary/5 border border-primary/20 font-mono text-center text-lg">
          {section}
        </div>
      )
    }
    
    // Check if it's a list
    if (section.includes('•') || section.includes('-')) {
      const items = section.split(/[•\-]/).filter(Boolean)
      return (
        <ul key={i} className="my-4 space-y-2">
          {items.map((item, j) => (
            <li key={j} className="flex items-start gap-2">
              <span className="text-primary mt-1">•</span>
              <span>{item.trim()}</span>
            </li>
          ))}
        </ul>
      )
    }
    
    // Check if it's a header/title (short and no period)
    if (section.length < 50 && !section.includes('.')) {
      return (
        <h3 key={i} className="text-lg font-semibold mt-6 mb-3">
          {section}
        </h3>
      )
    }
    
    return (
      <p key={i} className="my-4 leading-relaxed text-muted-foreground">
        {section}
      </p>
    )
  })

  const summaryPoints = generateSummary()

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8 max-w-3xl">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link href="/konular" className="hover:text-foreground">Konular</Link>
          <span>/</span>
          <Link href={`/konular/${topicId}`} className="hover:text-foreground">{topic.name}</Link>
          <span>/</span>
          <span className="text-foreground">{lesson.title}</span>
        </div>

        {/* Lesson Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <span className="text-2xl">{topic.icon}</span>
              <span className="text-sm text-muted-foreground">Ders {lessonIndex + 1} / {topic.lessons.length}</span>
            </div>
            
            {/* Özet ve Yazdır Butonları */}
            <div className="flex gap-2">
              <Dialog open={showSummary} onOpenChange={setShowSummary}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" className="gap-2">
                    <FileText className="w-4 h-4" />
                    Ozet Cikar
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2">
                      <FileText className="w-5 h-5" />
                      {lesson.title} - Ozet
                    </DialogTitle>
                    <DialogDescription>
                      Dersin onemli noktalari
                    </DialogDescription>
                  </DialogHeader>
                  <div ref={summaryRef} className="space-y-4 max-h-96 overflow-y-auto">
                    <Card>
                      <CardHeader className="pb-2">
                        <CardTitle className="text-sm">Onemli Noktalar</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-2">
                          {summaryPoints.map((point, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm">
                              <span className="text-primary font-bold">{i + 1}.</span>
                              <span>{point}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                    
                    {lesson.examples && lesson.examples.length > 0 && (
                      <Card>
                        <CardHeader className="pb-2">
                          <CardTitle className="text-sm">Ornekler</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-2">
                            {lesson.examples.map((ex, i) => (
                              <li key={i} className="text-sm font-mono bg-accent p-2 rounded">
                                {ex}
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                  <div className="flex justify-end gap-2 pt-4 border-t">
                    <Button variant="outline" onClick={() => setShowSummary(false)}>
                      Kapat
                    </Button>
                    <Button onClick={handlePrintSummary} className="gap-2">
                      <Printer className="w-4 h-4" />
                      Yazdir
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
              
              <Button variant="outline" size="sm" className="gap-2" onClick={handlePrintSummary}>
                <Printer className="w-4 h-4" />
                Yazdir
              </Button>
            </div>
          </div>
          
          <h1 className="text-2xl md:text-3xl font-bold mb-2">{lesson.title}</h1>
          {isCompleted && (
            <div className="flex items-center gap-2 text-green-600">
              <CheckCircle className="w-4 h-4" />
              <span className="text-sm">Bu dersi tamamladiniz</span>
            </div>
          )}
        </div>

        {/* Lesson Content */}
        <article className="prose prose-neutral dark:prose-invert max-w-none">
          <div className="rounded-xl border border-border bg-card p-6 md:p-8">
            {contentSections}

            {/* Examples Section */}
            {lesson.examples && lesson.examples.length > 0 && (
              <div className="mt-8 pt-6 border-t">
                <h3 className="text-lg font-semibold mb-4">Ornekler</h3>
                <div className="space-y-4">
                  {lesson.examples.map((example, i) => (
                    <div key={i} className="p-4 rounded-lg bg-accent/50">
                      <div className="font-medium mb-2">Ornek {i + 1}:</div>
                      <div className="font-mono">{example}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </article>

        {/* Actions */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex gap-2">
            {prevLesson && (
              <Link href={`/konular/${topicId}/ders/${prevLesson.id}`}>
                <Button variant="outline" className="gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Onceki Ders
                </Button>
              </Link>
            )}
          </div>
          
          <div className="flex gap-2">
            {!isCompleted && (
              <Button onClick={handleComplete} variant="outline" className="gap-2">
                <CheckCircle className="w-4 h-4" />
                Tamamlandi
              </Button>
            )}
            
            {nextLesson ? (
              <Link href={`/konular/${topicId}/ders/${nextLesson.id}`}>
                <Button className="gap-2" onClick={handleComplete}>
                  Sonraki Ders
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            ) : (
              <Link href={`/konular/${topicId}/test`}>
                <Button className="gap-2" onClick={handleComplete}>
                  Test Coz
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            )}
          </div>
        </div>

        {/* Quick Navigation */}
        <div className="mt-8 p-4 rounded-xl border border-border bg-card">
          <h4 className="font-medium mb-3">Bu Konudaki Dersler</h4>
          <div className="flex flex-wrap gap-2">
            {topic.lessons.map((l, i) => {
              const isCurrentLesson = l.id === lessonId
              const isLessonCompleted = progress.lessonsCompleted.includes(l.id)
              
              return (
                <Link key={l.id} href={`/konular/${topicId}/ders/${l.id}`}>
                  <div className={`
                    flex items-center justify-center w-8 h-8 rounded-lg text-sm font-medium transition-all
                    ${isCurrentLesson 
                      ? 'bg-primary text-primary-foreground' 
                      : isLessonCompleted 
                        ? 'bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-300' 
                        : 'bg-accent hover:bg-accent/80'
                    }
                  `}>
                    {isLessonCompleted && !isCurrentLesson ? '✓' : i + 1}
                  </div>
                </Link>
              )
            })}
          </div>
        </div>
      </main>
    </div>
  )
}
