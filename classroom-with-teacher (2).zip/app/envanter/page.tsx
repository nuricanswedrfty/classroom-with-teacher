'use client'

import { Header } from '@/components/header'
import { useGameStore, clothingItems, plantTypes } from '@/lib/game-store'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { PlantGarden } from '@/components/plant-garden'
import { Check, Package, Shirt, Leaf, Lightbulb, Zap, Lock, Coins } from 'lucide-react'
import { cn } from '@/lib/utils'
import Link from 'next/link'

export default function EnvanterPage() {
  const { 
    profile, 
    ownedClothing, 
    equipClothing, 
    coins, 
    totalCoinsEarned,
    hintCount,
    growthBoosters,
    plants
  } = useGameStore()

  if (!profile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p>Profil bulunamadi</p>
      </div>
    )
  }

  const filteredClothing = clothingItems.filter(
    item => item.forGender === 'all' || item.forGender === profile.gender
  )

  const headItems = filteredClothing.filter(i => i.type === 'head')
  const bodyItems = filteredClothing.filter(i => i.type === 'body')
  const accessoryItems = filteredClothing.filter(i => i.type === 'accessory')

  // Sahip olunan esyalar
  const ownedHeadItems = headItems.filter(i => ownedClothing.includes(i.id))
  const ownedBodyItems = bodyItems.filter(i => ownedClothing.includes(i.id))
  const ownedAccessoryItems = accessoryItems.filter(i => ownedClothing.includes(i.id))

  const equippedHead = clothingItems.find(i => i.id === profile.avatar.head)
  const equippedBody = clothingItems.find(i => i.id === profile.avatar.body)
  const equippedAccessory = clothingItems.find(i => i.id === profile.avatar.accessory)

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-3">
                <Package className="w-8 h-8 text-primary" />
                Envanter
              </h1>
              <p className="text-muted-foreground">Sahip oldugun tum esyalar</p>
            </div>
            <div className="flex items-center gap-2 bg-yellow-100 dark:bg-yellow-950 text-yellow-700 dark:text-yellow-300 px-4 py-2 rounded-full">
              <Coins className="w-5 h-5" />
              <span className="font-bold text-lg">{coins}</span>
            </div>
          </div>

          {/* Istatistik Kartlari */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950 dark:to-purple-900 border-purple-200">
              <CardContent className="py-4 text-center">
                <div className="text-3xl mb-2">
                  <Shirt className="w-8 h-8 mx-auto text-purple-600" />
                </div>
                <div className="text-2xl font-bold text-purple-700 dark:text-purple-300">{ownedClothing.length}</div>
                <div className="text-xs text-purple-600 dark:text-purple-400">Kiyafet</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950 dark:to-green-900 border-green-200">
              <CardContent className="py-4 text-center">
                <div className="text-3xl mb-2">
                  <Leaf className="w-8 h-8 mx-auto text-green-600" />
                </div>
                <div className="text-2xl font-bold text-green-700 dark:text-green-300">{plants.length}</div>
                <div className="text-xs text-green-600 dark:text-green-400">Fidan</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 dark:from-yellow-950 dark:to-yellow-900 border-yellow-200">
              <CardContent className="py-4 text-center">
                <div className="text-3xl mb-2">
                  <Lightbulb className="w-8 h-8 mx-auto text-yellow-600" />
                </div>
                <div className="text-2xl font-bold text-yellow-700 dark:text-yellow-300">{hintCount}</div>
                <div className="text-xs text-yellow-600 dark:text-yellow-400">Ipucu</div>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950 dark:to-blue-900 border-blue-200">
              <CardContent className="py-4 text-center">
                <div className="text-3xl mb-2">
                  <Zap className="w-8 h-8 mx-auto text-blue-600" />
                </div>
                <div className="text-2xl font-bold text-blue-700 dark:text-blue-300">{growthBoosters}</div>
                <div className="text-xs text-blue-600 dark:text-blue-400">Hizlandirici</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Avatar Goruntuleme */}
            <Card>
              <CardHeader>
                <CardTitle>Karakterim</CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className="relative inline-block">
                  <div className="w-48 h-48 mx-auto rounded-full bg-gradient-to-br from-primary/20 to-accent flex items-center justify-center relative">
                    <span className="text-8xl">{profile.avatar.skinTone}</span>
                    
                    {equippedHead && (
                      <span className="absolute top-0 left-1/2 -translate-x-1/2 text-4xl">
                        {equippedHead.icon}
                      </span>
                    )}
                    
                    {equippedAccessory && (
                      <span className="absolute bottom-4 right-4 text-3xl">
                        {equippedAccessory.icon}
                      </span>
                    )}
                  </div>
                  
                  {equippedBody && (
                    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 text-5xl">
                      {equippedBody.icon}
                    </div>
                  )}
                </div>
                
                <h2 className="text-2xl font-bold mt-4">{profile.name}</h2>
                <p className="text-muted-foreground">
                  {profile.gender === 'male' ? 'Erkek' : 'Kiz'}
                </p>

                <div className="flex justify-center gap-2 mt-4 flex-wrap">
                  {equippedHead && (
                    <Badge variant="secondary" className="gap-1">
                      {equippedHead.icon} {equippedHead.name}
                    </Badge>
                  )}
                  {equippedBody && (
                    <Badge variant="secondary" className="gap-1">
                      {equippedBody.icon} {equippedBody.name}
                    </Badge>
                  )}
                  {equippedAccessory && (
                    <Badge variant="secondary" className="gap-1">
                      {equippedAccessory.icon} {equippedAccessory.name}
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Fidan Bahcesi */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Leaf className="w-5 h-5 text-green-600" />
                  Fidan Bahcem
                </CardTitle>
              </CardHeader>
              <CardContent>
                <PlantGarden />
              </CardContent>
            </Card>
          </div>

          {/* Kiyafet Envanteri */}
          <Card className="mt-8">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Shirt className="w-5 h-5" />
                  Kiyafetlerim
                </CardTitle>
                <Link href="/market">
                  <Button variant="outline" size="sm">Markete Git</Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="head">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="head">Sapka ({ownedHeadItems.length})</TabsTrigger>
                  <TabsTrigger value="body">Kiyafet ({ownedBodyItems.length})</TabsTrigger>
                  <TabsTrigger value="accessory">Aksesuar ({ownedAccessoryItems.length})</TabsTrigger>
                </TabsList>

                {/* Sapkalar */}
                <TabsContent value="head" className="mt-4">
                  {ownedHeadItems.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Lock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Henuz sapkan yok</p>
                      <Link href="/market">
                        <Button variant="link">Marketten satin al</Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
                      <button
                        onClick={() => equipClothing('head', undefined)}
                        className={cn(
                          "p-4 rounded-lg border-2 transition-all",
                          !profile.avatar.head
                            ? "border-primary bg-primary/10"
                            : "border-border hover:border-primary/50"
                        )}
                      >
                        <div className="text-2xl text-center mb-1">-</div>
                        <div className="text-xs text-center">Yok</div>
                      </button>
                      
                      {ownedHeadItems.map((item) => {
                        const equipped = profile.avatar.head === item.id
                        return (
                          <button
                            key={item.id}
                            onClick={() => equipClothing('head', item.id)}
                            className={cn(
                              "p-4 rounded-lg border-2 transition-all relative",
                              equipped && "border-primary bg-primary/10",
                              !equipped && "border-border hover:border-primary/50"
                            )}
                          >
                            {equipped && (
                              <Check className="w-3 h-3 absolute top-1 right-1 text-primary" />
                            )}
                            <div className="text-2xl text-center mb-1">{item.icon}</div>
                            <div className="text-xs text-center truncate">{item.name}</div>
                          </button>
                        )
                      })}
                    </div>
                  )}
                </TabsContent>

                {/* Kiyafetler */}
                <TabsContent value="body" className="mt-4">
                  {ownedBodyItems.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Lock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Henuz kiyafetin yok</p>
                      <Link href="/market">
                        <Button variant="link">Marketten satin al</Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
                      <button
                        onClick={() => equipClothing('body', undefined)}
                        className={cn(
                          "p-4 rounded-lg border-2 transition-all",
                          !profile.avatar.body
                            ? "border-primary bg-primary/10"
                            : "border-border hover:border-primary/50"
                        )}
                      >
                        <div className="text-2xl text-center mb-1">-</div>
                        <div className="text-xs text-center">Yok</div>
                      </button>
                      
                      {ownedBodyItems.map((item) => {
                        const equipped = profile.avatar.body === item.id
                        return (
                          <button
                            key={item.id}
                            onClick={() => equipClothing('body', item.id)}
                            className={cn(
                              "p-4 rounded-lg border-2 transition-all relative",
                              equipped && "border-primary bg-primary/10",
                              !equipped && "border-border hover:border-primary/50"
                            )}
                          >
                            {equipped && (
                              <Check className="w-3 h-3 absolute top-1 right-1 text-primary" />
                            )}
                            <div className="text-2xl text-center mb-1">{item.icon}</div>
                            <div className="text-xs text-center truncate">{item.name}</div>
                          </button>
                        )
                      })}
                    </div>
                  )}
                </TabsContent>

                {/* Aksesuarlar */}
                <TabsContent value="accessory" className="mt-4">
                  {ownedAccessoryItems.length === 0 ? (
                    <div className="text-center py-8 text-muted-foreground">
                      <Lock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Henuz aksesuarin yok</p>
                      <Link href="/market">
                        <Button variant="link">Marketten satin al</Button>
                      </Link>
                    </div>
                  ) : (
                    <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
                      <button
                        onClick={() => equipClothing('accessory', undefined)}
                        className={cn(
                          "p-4 rounded-lg border-2 transition-all",
                          !profile.avatar.accessory
                            ? "border-primary bg-primary/10"
                            : "border-border hover:border-primary/50"
                        )}
                      >
                        <div className="text-2xl text-center mb-1">-</div>
                        <div className="text-xs text-center">Yok</div>
                      </button>
                      
                      {ownedAccessoryItems.map((item) => {
                        const equipped = profile.avatar.accessory === item.id
                        return (
                          <button
                            key={item.id}
                            onClick={() => equipClothing('accessory', item.id)}
                            className={cn(
                              "p-4 rounded-lg border-2 transition-all relative",
                              equipped && "border-primary bg-primary/10",
                              !equipped && "border-border hover:border-primary/50"
                            )}
                          >
                            {equipped && (
                              <Check className="w-3 h-3 absolute top-1 right-1 text-primary" />
                            )}
                            <div className="text-2xl text-center mb-1">{item.icon}</div>
                            <div className="text-xs text-center truncate">{item.name}</div>
                          </button>
                        )
                      })}
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
