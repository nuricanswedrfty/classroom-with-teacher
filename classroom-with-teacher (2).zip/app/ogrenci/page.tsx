'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Progress } from '@/components/ui/progress'
import { 
  User, 
  BookOpen, 
  Trophy, 
  CheckCircle, 
  XCircle,
  Clock,
  ArrowRight,
  Sparkles
} from 'lucide-react'
import { 
  joinClassroom, 
  getStudentClassrooms,
  getClassroomDetails,
  getExam,
  submitExamAnswer,
  getStudentExamResults
} from '@/app/actions/classroom'
import { useGameStore } from '@/lib/game-store'
import { cn } from '@/lib/utils'

interface StudentClassroom {
  id: number
  classroomId: number
  studentName: string
  points: number | null
  classroom: {
    id: number
    code: string
    name: string
  }
}

interface ExamQuestion {
  id: number
  question: string
  optionA: string
  optionB: string
  optionC: string
  optionD: string
  correctAnswer: string
  points: number | null
}

interface ExamData {
  id: number
  title: string
  description: string | null
  questions: ExamQuestion[]
  classroom: any
}

export default function OgrenciPage() {
  const { profile, addCoins } = useGameStore()
  const [studentName, setStudentName] = useState('')
  const [classCode, setClassCode] = useState('')
  const [joining, setJoining] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  
  const [myClassrooms, setMyClassrooms] = useState<StudentClassroom[]>([])
  const [selectedClassroom, setSelectedClassroom] = useState<any>(null)
  const [loading, setLoading] = useState(false)
  
  // Sinav state
  const [currentExam, setCurrentExam] = useState<ExamData | null>(null)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null)
  const [answerResult, setAnswerResult] = useState<{isCorrect: boolean, points: number} | null>(null)
  const [examResults, setExamResults] = useState<any>(null)
  const [studentId, setStudentId] = useState<number | null>(null)
  const [showExamDialog, setShowExamDialog] = useState(false)

  const currentStudent = profile?.name || studentName

  useEffect(() => {
    if (currentStudent) {
      loadMyClassrooms()
    }
  }, [currentStudent])

  const loadMyClassrooms = async () => {
    if (!currentStudent) return
    setLoading(true)
    const data = await getStudentClassrooms(currentStudent)
    setMyClassrooms(data)
    setLoading(false)
  }

  const handleJoinClass = async () => {
    if (!classCode.trim() || !currentStudent) {
      setError('Lutfen sinif kodunu girin')
      return
    }
    
    setJoining(true)
    setError('')
    
    const result = await joinClassroom(classCode.toUpperCase(), currentStudent)
    
    if (result.error) {
      if (result.student) {
        // Zaten kayitli
        setStudentId(result.student.id)
        setSuccess(`${result.classroom?.name} sinifina zaten kayitlisiniz!`)
      } else {
        setError(result.error)
      }
    } else {
      setStudentId(result.student?.id || null)
      setSuccess(`${result.classroom?.name} sinifina katildiniz!`)
      loadMyClassrooms()
    }
    
    setJoining(false)
    setClassCode('')
  }

  const handleSelectClassroom = async (classroom: StudentClassroom) => {
    const details = await getClassroomDetails(classroom.classroomId)
    setSelectedClassroom(details)
    setStudentId(classroom.id)
  }

  const startExam = async (examId: number) => {
    const exam = await getExam(examId)
    if (exam && studentId) {
      const results = await getStudentExamResults(examId, studentId)
      if (results.completed) {
        setExamResults(results)
      } else {
        setCurrentExam(exam)
        setCurrentQuestionIndex(results.answeredQuestions)
      }
      setShowExamDialog(true)
    }
  }

  const handleSubmitAnswer = async () => {
    if (!currentExam || !selectedAnswer || !studentId) return
    
    const question = currentExam.questions[currentQuestionIndex]
    const result = await submitExamAnswer(currentExam.id, studentId, question.id, selectedAnswer)
    
    if ('error' in result && result.error) {
      if (result.alreadyAnswered) {
        // Sonraki soruya gec
        if (currentQuestionIndex < currentExam.questions.length - 1) {
          setCurrentQuestionIndex(currentQuestionIndex + 1)
          setSelectedAnswer(null)
        } else {
          // Sinav bitti
          const finalResults = await getStudentExamResults(currentExam.id, studentId)
          setExamResults(finalResults)
          setCurrentExam(null)
        }
      }
      return
    }
    
    setAnswerResult(result as {isCorrect: boolean, points: number})
    
    // Dogru ise puan ekle
    if (result.isCorrect && result.points) {
      addCoins(result.points)
    }
    
    // 1.5 saniye sonra sonraki soruya gec
    setTimeout(async () => {
      setAnswerResult(null)
      setSelectedAnswer(null)
      
      if (currentQuestionIndex < currentExam.questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1)
      } else {
        // Sinav bitti
        const finalResults = await getStudentExamResults(currentExam.id, studentId)
        setExamResults(finalResults)
        setCurrentExam(null)
      }
    }, 1500)
  }

  const closeExamDialog = () => {
    setShowExamDialog(false)
    setCurrentExam(null)
    setExamResults(null)
    setCurrentQuestionIndex(0)
    setSelectedAnswer(null)
    setAnswerResult(null)
    
    // Sinifi yeniden yukle
    if (selectedClassroom) {
      handleSelectClassroom(myClassrooms.find(c => c.classroomId === selectedClassroom.id)!)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-3">
                <User className="w-8 h-8 text-primary" />
                Ogrenci Paneli
              </h1>
              <p className="text-muted-foreground">Siniflarini ve sinavlarini gor</p>
            </div>
            {currentStudent && (
              <Badge variant="secondary" className="text-lg px-4 py-2">
                {currentStudent}
              </Badge>
            )}
          </div>

          {/* Sinifa Katil */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Sinifa Katil</CardTitle>
              <CardDescription>
                Ogretmeninin verdigi 5 haneli sinif kodunu gir
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 items-end">
                {!profile && (
                  <div className="space-y-2 flex-1">
                    <Label>Adin</Label>
                    <Input
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      placeholder="Adini yaz..."
                    />
                  </div>
                )}
                <div className="space-y-2 flex-1">
                  <Label>Sinif Kodu</Label>
                  <Input
                    value={classCode}
                    onChange={(e) => setClassCode(e.target.value.toUpperCase())}
                    placeholder="XXXXX"
                    maxLength={5}
                    className="font-mono text-lg tracking-widest"
                  />
                </div>
                <Button 
                  onClick={handleJoinClass}
                  disabled={joining || !classCode.trim() || (!profile && !studentName.trim())}
                  className="gap-2"
                >
                  Katil
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
              
              {error && (
                <p className="text-destructive text-sm mt-2">{error}</p>
              )}
              {success && (
                <p className="text-green-600 text-sm mt-2">{success}</p>
              )}
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Sol - Siniflarim */}
            <div>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Siniflarim</CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="text-center py-4 text-muted-foreground">
                      Yukleniyor...
                    </div>
                  ) : myClassrooms.length === 0 ? (
                    <div className="text-center py-4 text-muted-foreground">
                      <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>Henuz bir sinifa katilmadiniz</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {myClassrooms.map((classroom) => (
                        <button
                          key={classroom.id}
                          onClick={() => handleSelectClassroom(classroom)}
                          className={`w-full p-3 rounded-lg border text-left transition-all ${
                            selectedClassroom?.id === classroom.classroomId
                              ? 'border-primary bg-primary/5'
                              : 'border-border hover:border-primary/50'
                          }`}
                        >
                          <div className="font-medium">{classroom.classroom.name}</div>
                          <div className="flex items-center justify-between mt-1">
                            <Badge variant="outline" className="font-mono text-xs">
                              {classroom.classroom.code}
                            </Badge>
                            <Badge variant="secondary" className="gap-1">
                              <Trophy className="w-3 h-3" />
                              {classroom.points || 0}
                            </Badge>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sag - Sinif Detaylari */}
            <div className="md:col-span-2">
              {selectedClassroom ? (
                <Card>
                  <CardHeader>
                    <CardTitle>{selectedClassroom.name}</CardTitle>
                    <CardDescription>
                      Sinavlari coz ve puan kazan!
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <h3 className="font-semibold mb-4">Sinavlar</h3>
                    
                    {!selectedClassroom.exams || selectedClassroom.exams.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                        <p>Henuz sinav yok</p>
                        <p className="text-sm mt-2">Ogretmenin sinav olusturmasini bekle</p>
                      </div>
                    ) : (
                      <div className="grid gap-3">
                        {selectedClassroom.exams
                          .filter((e: any) => e.isActive)
                          .map((exam: any) => (
                          <Card key={exam.id} className="border-2 hover:border-primary/50 transition-all">
                            <CardContent className="p-4">
                              <div className="flex items-center justify-between">
                                <div>
                                  <h4 className="font-semibold">{exam.title}</h4>
                                  {exam.description && (
                                    <p className="text-sm text-muted-foreground">{exam.description}</p>
                                  )}
                                </div>
                                <Button onClick={() => startExam(exam.id)} className="gap-2">
                                  <Sparkles className="w-4 h-4" />
                                  Sinava Basla
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="py-12 text-center">
                    <BookOpen className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">Sinif Sec</h3>
                    <p className="text-muted-foreground">
                      Sol taraftan bir sinif secin veya yeni sinifa katil
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Sinav Dialog */}
          <Dialog open={showExamDialog} onOpenChange={(open) => !open && closeExamDialog()}>
            <DialogContent className="max-w-2xl">
              {examResults ? (
                // Sonuc Ekrani
                <>
                  <DialogHeader>
                    <DialogTitle className="text-center">Sinav Tamamlandi!</DialogTitle>
                  </DialogHeader>
                  <div className="py-8 text-center">
                    <div className={`w-24 h-24 mx-auto rounded-full flex items-center justify-center mb-4 ${
                      examResults.correctAnswers >= examResults.totalQuestions / 2
                        ? 'bg-green-100 text-green-600'
                        : 'bg-orange-100 text-orange-600'
                    }`}>
                      {examResults.correctAnswers >= examResults.totalQuestions / 2 ? (
                        <Trophy className="w-12 h-12" />
                      ) : (
                        <BookOpen className="w-12 h-12" />
                      )}
                    </div>
                    
                    <h3 className="text-2xl font-bold mb-2">
                      {examResults.correctAnswers} / {examResults.totalQuestions} Dogru
                    </h3>
                    
                    <Badge variant="secondary" className="text-lg px-4 py-2 mb-4">
                      Toplam: {examResults.totalPoints} puan
                    </Badge>
                    
                    <Progress 
                      value={(examResults.correctAnswers / examResults.totalQuestions) * 100} 
                      className="h-3 mb-4"
                    />
                    
                    <p className="text-muted-foreground">
                      {examResults.correctAnswers >= examResults.totalQuestions / 2
                        ? 'Harika is cikarttin! Boyle devam!'
                        : 'Daha cok calisarak gelisebilirsin!'}
                    </p>
                    
                    <Button onClick={closeExamDialog} className="mt-6">
                      Kapat
                    </Button>
                  </div>
                </>
              ) : currentExam ? (
                // Soru Ekrani
                <>
                  <DialogHeader>
                    <DialogTitle>{currentExam.title}</DialogTitle>
                    <DialogDescription>
                      Soru {currentQuestionIndex + 1} / {currentExam.questions.length}
                    </DialogDescription>
                  </DialogHeader>
                  
                  <Progress 
                    value={((currentQuestionIndex + 1) / currentExam.questions.length) * 100} 
                    className="h-2 mb-4"
                  />
                  
                  {currentExam.questions[currentQuestionIndex] && (
                    <div className="py-4">
                      <div className="text-lg font-medium mb-6 p-4 bg-accent rounded-lg">
                        {currentExam.questions[currentQuestionIndex].question}
                      </div>
                      
                      <div className="grid gap-3">
                        {['A', 'B', 'C', 'D'].map((option) => {
                          const optionKey = `option${option}` as 'optionA' | 'optionB' | 'optionC' | 'optionD'
                          const optionText = currentExam.questions[currentQuestionIndex][optionKey]
                          const isSelected = selectedAnswer === option
                          const isCorrect = answerResult && currentExam.questions[currentQuestionIndex].correctAnswer === option
                          const isWrong = answerResult && isSelected && !answerResult.isCorrect
                          
                          return (
                            <button
                              key={option}
                              onClick={() => !answerResult && setSelectedAnswer(option)}
                              disabled={!!answerResult}
                              className={cn(
                                "w-full p-4 rounded-lg border-2 text-left transition-all flex items-center gap-3",
                                isSelected && !answerResult && "border-primary bg-primary/5",
                                isCorrect && "border-green-500 bg-green-50",
                                isWrong && "border-red-500 bg-red-50",
                                !isSelected && !answerResult && "border-border hover:border-primary/50"
                              )}
                            >
                              <span className={cn(
                                "w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold",
                                isSelected && !answerResult && "bg-primary text-primary-foreground",
                                isCorrect && "bg-green-500 text-white",
                                isWrong && "bg-red-500 text-white",
                                !isSelected && !answerResult && "bg-accent"
                              )}>
                                {isCorrect ? <CheckCircle className="w-5 h-5" /> : 
                                 isWrong ? <XCircle className="w-5 h-5" /> : option}
                              </span>
                              <span>{optionText}</span>
                            </button>
                          )
                        })}
                      </div>
                      
                      {answerResult && (
                        <div className={`mt-4 p-4 rounded-lg text-center ${
                          answerResult.isCorrect ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                        }`}>
                          {answerResult.isCorrect ? (
                            <>
                              <CheckCircle className="w-8 h-8 mx-auto mb-2" />
                              <p className="font-bold">Dogru! +{answerResult.points} puan</p>
                            </>
                          ) : (
                            <>
                              <XCircle className="w-8 h-8 mx-auto mb-2" />
                              <p className="font-bold">Yanlis!</p>
                            </>
                          )}
                        </div>
                      )}
                      
                      {!answerResult && (
                        <Button 
                          onClick={handleSubmitAnswer}
                          disabled={!selectedAnswer}
                          className="w-full mt-6"
                        >
                          Cevabi Gonder
                        </Button>
                      )}
                    </div>
                  )}
                </>
              ) : null}
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  )
}
