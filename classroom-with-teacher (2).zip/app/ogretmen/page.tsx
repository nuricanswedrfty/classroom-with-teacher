'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/header'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  GraduationCap, 
  Plus, 
  Users, 
  FileText, 
  Trophy, 
  Copy, 
  Check,
  BookOpen,
  Trash2
} from 'lucide-react'
import { 
  createClassroom, 
  getTeacherClassrooms, 
  getClassroomDetails,
  createExam,
  addQuestionToExam,
  getExamQuestions
} from '@/app/actions/classroom'
import { useGameStore } from '@/lib/game-store'

interface Classroom {
  id: number
  code: string
  name: string
  teacherId: string
  createdAt: Date | null
  students?: any[]
  exams?: any[]
}

interface Question {
  question: string
  optionA: string
  optionB: string
  optionC: string
  optionD: string
  correctAnswer: string
  points: number
}

export default function OgretmenPage() {
  const { profile } = useGameStore()
  const [classrooms, setClassrooms] = useState<Classroom[]>([])
  const [selectedClassroom, setSelectedClassroom] = useState<Classroom | null>(null)
  const [loading, setLoading] = useState(true)
  const [copiedCode, setCopiedCode] = useState<string | null>(null)
  
  // Sinif olusturma
  const [newClassName, setNewClassName] = useState('')
  const [creatingClass, setCreatingClass] = useState(false)
  
  // Sinav olusturma
  const [examTitle, setExamTitle] = useState('')
  const [examDescription, setExamDescription] = useState('')
  const [currentExamId, setCurrentExamId] = useState<number | null>(null)
  const [questions, setQuestions] = useState<Question[]>([])
  const [currentQuestion, setCurrentQuestion] = useState<Question>({
    question: '',
    optionA: '',
    optionB: '',
    optionC: '',
    optionD: '',
    correctAnswer: 'A',
    points: 10
  })
  const [examDialogOpen, setExamDialogOpen] = useState(false)
  const [questionDialogOpen, setQuestionDialogOpen] = useState(false)

  const teacherId = profile?.name || 'ogretmen'

  useEffect(() => {
    loadClassrooms()
  }, [teacherId])

  const loadClassrooms = async () => {
    setLoading(true)
    const data = await getTeacherClassrooms(teacherId)
    setClassrooms(data)
    setLoading(false)
  }

  const handleCreateClass = async () => {
    if (!newClassName.trim()) return
    setCreatingClass(true)
    
    const newClass = await createClassroom(teacherId, newClassName)
    setClassrooms([newClass, ...classrooms])
    setNewClassName('')
    setCreatingClass(false)
  }

  const handleSelectClassroom = async (classroom: Classroom) => {
    const details = await getClassroomDetails(classroom.id)
    setSelectedClassroom(details)
  }

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code)
    setCopiedCode(code)
    setTimeout(() => setCopiedCode(null), 2000)
  }

  const handleCreateExam = async () => {
    if (!selectedClassroom || !examTitle.trim()) return
    
    const exam = await createExam(selectedClassroom.id, examTitle, examDescription)
    setCurrentExamId(exam.id)
    setExamDialogOpen(false)
    setQuestionDialogOpen(true)
    setExamTitle('')
    setExamDescription('')
  }

  const handleAddQuestion = async () => {
    if (!currentExamId) return
    
    await addQuestionToExam(
      currentExamId,
      currentQuestion.question,
      currentQuestion.optionA,
      currentQuestion.optionB,
      currentQuestion.optionC,
      currentQuestion.optionD,
      currentQuestion.correctAnswer,
      currentQuestion.points
    )
    
    setQuestions([...questions, currentQuestion])
    setCurrentQuestion({
      question: '',
      optionA: '',
      optionB: '',
      optionC: '',
      optionD: '',
      correctAnswer: 'A',
      points: 10
    })
  }

  const finishExam = async () => {
    setQuestionDialogOpen(false)
    setQuestions([])
    setCurrentExamId(null)
    
    // Sinifi yeniden yukle
    if (selectedClassroom) {
      const details = await getClassroomDetails(selectedClassroom.id)
      setSelectedClassroom(details)
    }
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="py-8 text-center">
            <GraduationCap className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-xl font-bold mb-2">Ogretmen Paneli</h2>
            <p className="text-muted-foreground">Lutfen once giris yapin</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-3">
                <GraduationCap className="w-8 h-8 text-primary" />
                Ogretmen Paneli
              </h1>
              <p className="text-muted-foreground">Siniflarini ve sinavlarini yonet</p>
            </div>
            <Badge variant="secondary" className="text-lg px-4 py-2">
              {profile.name}
            </Badge>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {/* Sol Panel - Sinif Listesi */}
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">Siniflarim</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Yeni Sinif Olustur */}
                  <div className="flex gap-2">
                    <Input
                      placeholder="Sinif adi..."
                      value={newClassName}
                      onChange={(e) => setNewClassName(e.target.value)}
                      onKeyDown={(e) => e.key === 'Enter' && handleCreateClass()}
                    />
                    <Button 
                      size="icon" 
                      onClick={handleCreateClass}
                      disabled={creatingClass || !newClassName.trim()}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* Sinif Listesi */}
                  {loading ? (
                    <div className="text-center py-4 text-muted-foreground">
                      Yukleniyor...
                    </div>
                  ) : classrooms.length === 0 ? (
                    <div className="text-center py-4 text-muted-foreground">
                      Henuz sinif yok
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {classrooms.map((classroom) => (
                        <div
                          key={classroom.id}
                          onClick={() => handleSelectClassroom(classroom)}
                          className={`w-full p-3 rounded-lg border text-left transition-all cursor-pointer ${
                            selectedClassroom?.id === classroom.id
                              ? 'border-primary bg-primary/5'
                              : 'border-border hover:border-primary/50'
                          }`}
                        >
                          <div className="font-medium">{classroom.name}</div>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="font-mono text-xs">
                              {classroom.code}
                            </Badge>
                            <span
                              onClick={(e) => {
                                e.stopPropagation()
                                copyCode(classroom.code)
                              }}
                              className="text-muted-foreground hover:text-primary cursor-pointer"
                            >
                              {copiedCode === classroom.code ? (
                                <Check className="w-3 h-3" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Sag Panel - Sinif Detaylari */}
            <div className="md:col-span-2">
              {selectedClassroom ? (
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle>{selectedClassroom.name}</CardTitle>
                        <CardDescription className="flex items-center gap-2 mt-1">
                          Sinif Kodu: 
                          <Badge variant="secondary" className="font-mono">
                            {selectedClassroom.code}
                          </Badge>
                          <button
                            onClick={() => copyCode(selectedClassroom.code)}
                            className="text-muted-foreground hover:text-primary"
                          >
                            {copiedCode === selectedClassroom.code ? (
                              <Check className="w-4 h-4" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </button>
                        </CardDescription>
                      </div>
                      <Dialog open={examDialogOpen} onOpenChange={setExamDialogOpen}>
                        <DialogTrigger asChild>
                          <Button className="gap-2">
                            <Plus className="w-4 h-4" />
                            Sinav Olustur
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Yeni Sinav Olustur</DialogTitle>
                            <DialogDescription>
                              Sinav bilgilerini girin, ardindan sorulari ekleyeceksiniz.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 py-4">
                            <div className="space-y-2">
                              <Label>Sinav Adi</Label>
                              <Input
                                value={examTitle}
                                onChange={(e) => setExamTitle(e.target.value)}
                                placeholder="ornegin: Matematik Quiz 1"
                              />
                            </div>
                            <div className="space-y-2">
                              <Label>Aciklama (Opsiyonel)</Label>
                              <Textarea
                                value={examDescription}
                                onChange={(e) => setExamDescription(e.target.value)}
                                placeholder="Sinav hakkinda kisa bilgi..."
                              />
                            </div>
                            <Button 
                              className="w-full" 
                              onClick={handleCreateExam}
                              disabled={!examTitle.trim()}
                            >
                              Sinavi Olustur ve Soru Ekle
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="students">
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="students" className="gap-2">
                          <Users className="w-4 h-4" />
                          Ogrenciler ({selectedClassroom.students?.length || 0})
                        </TabsTrigger>
                        <TabsTrigger value="exams" className="gap-2">
                          <FileText className="w-4 h-4" />
                          Sinavlar ({selectedClassroom.exams?.length || 0})
                        </TabsTrigger>
                      </TabsList>

                      <TabsContent value="students" className="mt-4">
                        {!selectedClassroom.students || selectedClassroom.students.length === 0 ? (
                          <div className="text-center py-8 text-muted-foreground">
                            <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
                            <p>Henuz ogrenci katilmamis</p>
                            <p className="text-sm mt-2">
                              Sinif kodunu paylasin: <span className="font-mono font-bold">{selectedClassroom.code}</span>
                            </p>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {selectedClassroom.students
                              .sort((a: any, b: any) => (b.points || 0) - (a.points || 0))
                              .map((student: any, index: number) => (
                              <div
                                key={student.id}
                                className="flex items-center justify-between p-3 rounded-lg border"
                              >
                                <div className="flex items-center gap-3">
                                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                                    index === 0 ? 'bg-yellow-100 text-yellow-700' :
                                    index === 1 ? 'bg-gray-100 text-gray-700' :
                                    index === 2 ? 'bg-orange-100 text-orange-700' :
                                    'bg-accent text-accent-foreground'
                                  }`}>
                                    {index + 1}
                                  </div>
                                  <span className="font-medium">{student.studentName}</span>
                                </div>
                                <Badge variant="secondary" className="gap-1">
                                  <Trophy className="w-3 h-3" />
                                  {student.points || 0} puan
                                </Badge>
                              </div>
                            ))}
                          </div>
                        )}
                      </TabsContent>

                      <TabsContent value="exams" className="mt-4">
                        {!selectedClassroom.exams || selectedClassroom.exams.length === 0 ? (
                          <div className="text-center py-8 text-muted-foreground">
                            <FileText className="w-12 h-12 mx-auto mb-3 opacity-50" />
                            <p>Henuz sinav yok</p>
                            <p className="text-sm mt-2">Yeni sinav olusturmak icin butona basin</p>
                          </div>
                        ) : (
                          <div className="space-y-2">
                            {selectedClassroom.exams.map((exam: any) => (
                              <div
                                key={exam.id}
                                className="flex items-center justify-between p-3 rounded-lg border"
                              >
                                <div>
                                  <div className="font-medium">{exam.title}</div>
                                  {exam.description && (
                                    <div className="text-sm text-muted-foreground">{exam.description}</div>
                                  )}
                                </div>
                                <Badge variant={exam.isActive ? 'default' : 'secondary'}>
                                  {exam.isActive ? 'Aktif' : 'Kapali'}
                                </Badge>
                              </div>
                            ))}
                          </div>
                        )}
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="py-12 text-center">
                    <BookOpen className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <h3 className="text-lg font-medium mb-2">Sinif Sec</h3>
                    <p className="text-muted-foreground">
                      Sol taraftan bir sinif secin veya yeni sinif olusturun
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>

          {/* Soru Ekleme Dialog */}
          <Dialog open={questionDialogOpen} onOpenChange={setQuestionDialogOpen}>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Sorulari Ekle</DialogTitle>
                <DialogDescription>
                  Sinava soru ekleyin. Tamamladiginizda "Sinavi Bitir" butonuna basin.
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                {/* Eklenen Sorular */}
                {questions.length > 0 && (
                  <div className="space-y-2 mb-4">
                    <Label>Eklenen Sorular ({questions.length})</Label>
                    {questions.map((q, i) => (
                      <div key={i} className="p-2 rounded border bg-accent/50 text-sm">
                        <span className="font-medium">{i + 1}.</span> {q.question.substring(0, 50)}...
                      </div>
                    ))}
                  </div>
                )}

                {/* Yeni Soru Formu */}
                <div className="space-y-4 border-t pt-4">
                  <div className="space-y-2">
                    <Label>Soru</Label>
                    <Textarea
                      value={currentQuestion.question}
                      onChange={(e) => setCurrentQuestion({...currentQuestion, question: e.target.value})}
                      placeholder="Soruyu yazin..."
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>A Sikki</Label>
                      <Input
                        value={currentQuestion.optionA}
                        onChange={(e) => setCurrentQuestion({...currentQuestion, optionA: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>B Sikki</Label>
                      <Input
                        value={currentQuestion.optionB}
                        onChange={(e) => setCurrentQuestion({...currentQuestion, optionB: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>C Sikki</Label>
                      <Input
                        value={currentQuestion.optionC}
                        onChange={(e) => setCurrentQuestion({...currentQuestion, optionC: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>D Sikki</Label>
                      <Input
                        value={currentQuestion.optionD}
                        onChange={(e) => setCurrentQuestion({...currentQuestion, optionD: e.target.value})}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Dogru Cevap</Label>
                      <Select
                        value={currentQuestion.correctAnswer}
                        onValueChange={(v) => setCurrentQuestion({...currentQuestion, correctAnswer: v})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="A">A</SelectItem>
                          <SelectItem value="B">B</SelectItem>
                          <SelectItem value="C">C</SelectItem>
                          <SelectItem value="D">D</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Puan</Label>
                      <Input
                        type="number"
                        value={currentQuestion.points}
                        onChange={(e) => setCurrentQuestion({...currentQuestion, points: parseInt(e.target.value) || 10})}
                      />
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button 
                      onClick={handleAddQuestion}
                      disabled={!currentQuestion.question || !currentQuestion.optionA || !currentQuestion.optionB || !currentQuestion.optionC || !currentQuestion.optionD}
                      className="flex-1"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Soru Ekle
                    </Button>
                    <Button 
                      variant="secondary"
                      onClick={finishExam}
                      disabled={questions.length === 0}
                    >
                      <Check className="w-4 h-4 mr-2" />
                      Sinavi Bitir
                    </Button>
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  )
}
